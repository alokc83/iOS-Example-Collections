#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

#define BUTTON_TAG		9999

@interface HelloController : UIViewController
@end

@implementation HelloController

- (id) init
{
	if (self = [super init]) self.title = @"Audio Player";
	return self;
}

-(void)myMovieFinishedCallback:(NSNotification*)aNotification
{
    MPMoviePlayerController* theMovie=[aNotification object];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:theMovie];
    [theMovie release];
	[[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationPortrait animated:YES];
}

- (void) startPlayback : (id) sender
{
	NSString *path = [[NSBundle mainBundle] pathForResource:@"dream" ofType:@"m4a"];
	MPMoviePlayerController* theMovie=[[[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:path]] retain];
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(myMovieFinishedCallback:)
												 name:MPMoviePlayerPlaybackDidFinishNotification
											   object:theMovie];
	[theMovie play];
}

- (void) setUpForPlay: (NSNotification *) notification
{
	UIButton *button = (UIButton *)[self.view viewWithTag:BUTTON_TAG];
	
	// Prepare button for re-starting
	[button setTitle:@"Start" forState:UIControlStateNormal];
	[button setTitle:@"Start" forState:UIControlStateHighlighted];
	[button setBackgroundImage:[[UIImage imageNamed:@"green.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateNormal];
	[button setBackgroundImage:[[UIImage imageNamed:@"green2.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateHighlighted];
	[button removeTarget:self action:@selector(stopPlayback:) forControlEvents:UIControlEventTouchUpInside];
	[button addTarget:self action:@selector(startPlayback:) forControlEvents: UIControlEventTouchUpInside];
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	UIImageView *contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluelined.png"]];
	[contentView setUserInteractionEnabled:YES];
	self.view = contentView;
	[contentView release];
	
	// Create a start/stop button
	UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 219.0f, 233.0f)];
	button.tag = BUTTON_TAG;
	button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
	[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
	[button setFont:[UIFont boldSystemFontOfSize:24.0f]];
	[button setCenter:CGPointMake(160.0f, 200.0f)];
	[self.view addSubview: button];

	// Initialize the button to start playback
	[self setUpForPlay:NULL];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
