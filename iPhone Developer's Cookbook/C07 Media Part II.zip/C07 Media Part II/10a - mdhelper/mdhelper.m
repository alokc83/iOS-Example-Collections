#import <Foundation/Foundation.h>
#include <unistd.h>

//
// Usage
//

void usage()
{
	printf("Usage: mdhelper options\n");
	printf("-h        Print this message and exit\n");
	printf("-d        Show the backup directory\n");
	printf("-l        List contents for each platform\n");
	printf("-L        List the summary for each platform\n");
	printf("-f        List all files and mdbackup names for each platform\n");
	printf("-m        Extract all available manifests\n");
	printf("-X phrase Extract all files where the device name starts with the match phrase\n");
	printf("-C phrase Extract all files containing the phrase in the original filename\n");
	printf("-M phrase Extract all mdbackups whose name contains the match phrase\n");
	printf("-x files  Extract each mdbackup file listed by path\n");
}


// 
// Desktop Recovery Folder Routines
// 
id recoveryFolderPath()
{
	return [[NSHomeDirectory() stringByAppendingPathComponent:@"Desktop"]
			stringByAppendingPathComponent:@"Recovered iPhone Files"];
}

void createRecoveryFolder ()
{
	[[NSFileManager defaultManager] createDirectoryAtPath:recoveryFolderPath() attributes:NULL];
}

// 
// Backup Folder Routines
//

id backupDirPath()
{
	return [[[[NSHomeDirectory() stringByAppendingPathComponent:@"Library"]
			  stringByAppendingPathComponent:@"Application Support"]
			 stringByAppendingPathComponent:@"MobileSync"]
			stringByAppendingPathComponent:@"Backup"];
}

id backupFolders()
{
	return [[NSFileManager defaultManager] directoryContentsAtPath:backupDirPath()];
}

void getManifests()
{
	
	createRecoveryFolder();
	for (NSString *path in backupFolders())
	{
		NSString *fullPath = [backupDirPath() stringByAppendingPathComponent:path];
		NSString *manifestPath = [fullPath stringByAppendingPathComponent:@"Manifest.plist"];
		NSString *infoPath = [fullPath stringByAppendingPathComponent:@"Info.plist"];
		NSDictionary *manifestDict = [NSDictionary dictionaryWithContentsOfFile:manifestPath];
		NSDictionary *infoDict = [NSDictionary dictionaryWithContentsOfFile:infoPath];

		NSString *deviceName = [infoDict objectForKey:@"Device Name"];
		NSData *data = [manifestDict objectForKey:@"Data"];
		
		NSString *outfile = [[recoveryFolderPath() stringByAppendingPathComponent:deviceName] stringByAppendingString:@"-Manifest.plist"];
		if (data) printf("Extracting manifest for device %s\n", [deviceName UTF8String]);
		[data writeToFile:outfile atomically:YES];
	}
	
	printf("\nManifests are stored in %s\n", [recoveryFolderPath() UTF8String]);
}

#define NOTEST		0
#define DEVICETEST	1
#define FNAMETEST	2
#define MDTEST		4

void extract(char *matchPhrase, int option)
{
	NSString *matchString = [[NSString stringWithCString:matchPhrase encoding:1] uppercaseString];
	createRecoveryFolder();

	for (NSString *path in backupFolders())
	{
		NSString *fullPath = [backupDirPath() stringByAppendingPathComponent:path];
		NSString *infoPath = [fullPath stringByAppendingPathComponent:@"Info.plist"];
		NSDictionary *infoDict = [NSDictionary dictionaryWithContentsOfFile:infoPath];
		NSString *deviceName = [infoDict objectForKey:@"Device Name"];
		int count = 0;
		
		if (option & DEVICETEST)
			if (![[deviceName uppercaseString] hasPrefix:matchString]) continue;
		
		BOOL isDir;
		[[NSFileManager defaultManager] fileExistsAtPath:fullPath isDirectory: &isDir];
		if (!isDir) continue;
		
		printf("Directory: %s\n", [path UTF8String]);
		printf("Device: %s\n", [deviceName UTF8String]);
		
		NSArray *mdArray = [[[NSFileManager defaultManager] directoryContentsAtPath:fullPath] pathsMatchingExtensions:[NSArray arrayWithObject:@"mdbackup"]];
		// printf("About to check %d files\n", [mdArray count]);
		
		for (NSString *eachFile in mdArray)
		{
			NSString *mdpath = [fullPath stringByAppendingPathComponent:eachFile];
			NSDictionary *mddict = [NSDictionary dictionaryWithContentsOfFile: mdpath];	
			NSData *data = [mddict objectForKey:@"Data"];
			NSString *origPath = [mddict objectForKey:@"Path"];
			
			NSString *ext = [origPath pathExtension];
			if (!ext) ext = @"";
			
			NSString *baseName = [[origPath lastPathComponent] stringByDeletingPathExtension];
			if (!baseName) continue;
			
			if (option & FNAMETEST) {
				NSRange foundRange = [[origPath uppercaseString] rangeOfString:matchString];
				if (foundRange.location == NSNotFound) continue;
			}
			
			if (option & MDTEST) {
				NSRange foundRange = [[mdpath uppercaseString] rangeOfString:matchString];
				if (foundRange.location == NSNotFound) continue;
			}

			int i = 0;
			NSString *testPath = [[recoveryFolderPath() stringByAppendingPathComponent:baseName] stringByAppendingPathExtension:ext];
			
			while ([[NSFileManager defaultManager] fileExistsAtPath:testPath])
			{
				testPath = [NSString stringWithFormat:@"%@/%@-%d.%@", 
							recoveryFolderPath(),
							baseName,
							++i,
							ext];
			}
			
			[data writeToFile:testPath atomically:YES];
			count++;
		}
		printf("Extracted %d files from %s\n\n", count, [deviceName UTF8String]);
	}
}

#define SUMMARY		0
#define SHOWFILES	1
#define SHOWMDS		2

void listPlatformContents(int option)
{
	for (NSString *path in backupFolders())
	{
		NSString *fullPath = [backupDirPath() stringByAppendingPathComponent:path];
		NSString *infoPath = [fullPath stringByAppendingPathComponent:@"Info.plist"];
		NSDictionary *infoDict = [NSDictionary dictionaryWithContentsOfFile:infoPath];
		NSString *deviceName = [infoDict objectForKey:@"Device Name"];
		
		BOOL isDir;
		[[NSFileManager defaultManager] fileExistsAtPath:fullPath isDirectory: &isDir];
		if (!isDir) continue;
		
		printf("Directory: %s\n", [path UTF8String]);
		printf("Device: %s\n", [deviceName UTF8String]);
		
		NSArray *mdArray = [[[NSFileManager defaultManager] directoryContentsAtPath:fullPath] pathsMatchingExtensions:[NSArray arrayWithObject:@"mdbackup"]];
		printf("Files Found: %d backup files\n", [mdArray count]);
		
		if (option & SHOWFILES) {
			for (NSString *eachFile in mdArray)
			{
				NSString *mdpath = [fullPath stringByAppendingPathComponent:eachFile];
				NSDictionary *mddict = [NSDictionary dictionaryWithContentsOfFile: mdpath];	
				printf("  %s\n", [[mddict objectForKey:@"Path"] UTF8String]);
				if (option & SHOWMDS) printf("%s\n", [mdpath UTF8String]);
			}
			printf("\n");
		}
	}
}


int main (int argc, const char * argv[]) {
	opterr = 0;
	BOOL doExtract = NO;
	int c;

    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
	if (argc == 1) 
	{
		usage();
		exit(0);
	}
	
	// nDel = atoi(optarg);
	while ((c = getopt (argc, argv, "hmlLdfX:C:M:x")) != -1)
		switch (c)
	{
		case 'h': 
			usage();
			exit(0);
		case 'm': 
			getManifests();
			exit(0);
		case 'l':
			listPlatformContents(SHOWFILES);
			exit(0);
		case 'f':
			listPlatformContents(SHOWFILES | SHOWMDS);
			exit(0);
		case 'L':
			listPlatformContents(SUMMARY);
			exit(0);
		case 'd':
			printf("Backup directory is %s\n", [backupDirPath() UTF8String]);
			exit(0);
		case 'X':
			extract(optarg, DEVICETEST);
			exit(0);
		case 'C':
			extract(optarg, FNAMETEST);
			exit(0);
		case 'M':
			extract(optarg, MDTEST);
			exit(0);
		case 'x':
			doExtract = YES;
			break;
		case '?':
			if (isprint (optopt))
				fprintf (stderr, "Unknown option `-%c'.\n", optopt);
			else
				fprintf (stderr,
						 "Unknown option character `\\x%x'.\n",
						 optopt);
			return 1;
			default:
			return 0;
	}
	
	if (!doExtract) {
		exit(0);
	}
	
	int index = optind;
	
	createRecoveryFolder();
	
    for (int i = index; i < argc; i++)
	{
		printf("Extracting %s\n", argv[i]);
		NSMutableString *arg = [NSMutableString stringWithCString:argv[i] encoding:1];
		NSString *ext = [arg pathExtension];
		if (![[ext uppercaseString] isEqualToString:@"MDBACKUP"]) [arg appendString:@".mdbackup"];
		
		if (![[NSFileManager defaultManager] fileExistsAtPath:arg])
		{
			fprintf(stderr, "File %s does not exist\n", argv[i]);
			continue;
		}
		
		id mddict = [NSMutableDictionary dictionaryWithContentsOfFile:arg];
		if (!mddict)
		{
			fprintf(stderr, "Error: Could not load mdbackup dictionary from file\n");
			continue;
		}
		
		NSString *origPath = [mddict objectForKey:@"Path"];
		
		ext = [origPath pathExtension];
		if (!ext) ext = @"";
		
		NSString *baseName = [[origPath lastPathComponent] stringByDeletingPathExtension];
		if (!baseName) continue;
		
		int i = 0;
		NSString *testPath = [[recoveryFolderPath() stringByAppendingPathComponent:baseName] stringByAppendingPathExtension:ext];
		
		while ([[NSFileManager defaultManager] fileExistsAtPath:testPath])
		{
			testPath = [NSString stringWithFormat:@"%@/%@-%d.%@", 
						recoveryFolderPath(),
						baseName,
						++i,
						ext];
		}
		
		NSData *data = [mddict valueForKey:@"Data"];
		
		printf("Extracting %s to\n  %s...\n", [origPath UTF8String], [testPath UTF8String]);
		[data writeToFile:testPath atomically:YES];
	}

    [pool drain];
    return 0;
}
