#import <UIKit/UIKit.h>
#include <unistd.h>

@interface HelloController : UIImagePickerController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@end

@implementation HelloController

#define SOURCETYPE UIImagePickerControllerSourceTypeSavedPhotosAlbum
// #define SOURCETYPE UIImagePickerControllerSourceTypePhotoLibrary
#define DOCSFOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

- (id) init
{
	if (!(self = [super init])) return self;
	
	// Set up to use the photo roll aka "Saved Photos"
	if ([UIImagePickerController isSourceTypeAvailable:SOURCETYPE])	self.sourceType = SOURCETYPE;
	self.allowsImageEditing = YES;
	self.delegate = self;
	
	return self;
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
	// Find a unique path name so files are not over-written
	int i = 0;
	NSString *uniquePath = [DOCSFOLDER stringByAppendingPathComponent:@"selectedImage.png"];
	while ([[NSFileManager defaultManager] fileExistsAtPath:uniquePath])
		uniquePath = [NSString stringWithFormat:@"%@/%@-%d.%@", DOCSFOLDER, @"selectedImage", ++i, @"png"];
	
	printf("Writing selected image to Documents folder\n");
	[UIImagePNGRepresentation(image)  writeToFile: uniquePath atomically:YES];

	// Show the editing changes
	printf("Dictionary: %s\n", [[editingInfo description] UTF8String]);
	
	// Pop after saving the edited file
	[[self parentViewController] dismissModalViewControllerAnimated:YES];
	[picker release];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	[[self parentViewController] dismissModalViewControllerAnimated:YES];
	[picker release];
}
@end

@interface PrimaryController : UIViewController
@end

@implementation PrimaryController
- (void) snap
{
	[self presentModalViewController:[[HelloController alloc] init] animated:YES];
}

- (void) loadView
{
	[super loadView];
	
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor whiteColor];
	self.view = contentView;
	[contentView release];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											 initWithTitle:@"Select" 
											 style:UIBarButtonItemStylePlain 
											 target:self 
											 action:@selector(snap)] autorelease];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[PrimaryController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
