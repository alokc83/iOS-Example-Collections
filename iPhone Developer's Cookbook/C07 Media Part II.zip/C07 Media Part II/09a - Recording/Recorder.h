#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioQueue.h>
#import <AudioToolbox/AudioFile.h>

#define NUM_BUFFERS 3
#define kAudioConverterPropertyMaximumOutputPacketSize		'xops'
#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

typedef struct
	{
		AudioFileID                 audioFile;
		AudioStreamBasicDescription dataFormat;
		AudioQueueRef               queue;
		AudioQueueBufferRef         buffers[NUM_BUFFERS];
		UInt32                      bufferByteSize; 
		SInt64                      currentPacket;
		BOOL                        recording;
	} RecordState;

@interface Recorder : NSObject {
	RecordState recordState;
	CFURLRef fileURL;
}

- (BOOL)	isRecording;

// Automatically generate a dated file in Documents
- (void)	toggleRecording;

// Manual recording
- (void)	startRecording: (NSString *) filePath;
- (void)	stopRecording;

@end
