#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import "Recorder.h"
#import "Playback.h"

@interface NSFileManager (extended)
- removeFileAtPath:(NSString *)filepath handler:(id) handler;
@end

@interface NotesController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
	UIImageView			*bgView;
	UITableView			*tableView;
	NSMutableArray		*fileList;
	AVController		*avc;
}

@end

@implementation NotesController
- (id) init
{
	if (self = [super init]) self.title = @"Notes Library";
	fileList = [[NSMutableArray arrayWithArray:[[[NSFileManager defaultManager] directoryContentsAtPath:DOCUMENTS_FOLDER] 
				pathsMatchingExtensions:[NSArray arrayWithObject:@"aiff"]]] retain];
	return self;
}

- (void) viewWillDisappear:(BOOL) animated
{
	// Pause playback before leaving this view
	if (avc) [avc pause];
	[super viewWillDisappear: animated];
}

- (void) viewWillAppear: (BOOL) animated
{
	// Update the table to display any new items
	[tableView reloadData];
	if ([tableView indexPathForSelectedRow]) 
		[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
	[super viewWillAppear: animated];
}

// utility
- (void) deselect
{	
	[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}

// Respond to user selection by playing the audio
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath // fromIndexPath:(NSIndexPath *)oldIndexPath 
{
	NSString *path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[fileList objectAtIndex:[newIndexPath row]]];
	
	// Finish any previous playback
	if (avc) [avc pause];
	if (!avc) avc = [[MPAVController sharedInstance] avController];
	
	// Start new playback
	id feeder = [[MPArrayQueueFeeder alloc] initWithPaths:[NSArray arrayWithObject:path]];
	[avc setQueueFeeder:feeder];
	[avc play:nil];
	[feeder release];
}


// Editing
-(void)enterEditMode
{
	if ([tableView indexPathForSelectedRow]) [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Done" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(leaveEditMode)] autorelease];
	
	[tableView setEditing:YES animated:YES];
	[tableView beginUpdates];
}

-(void)leaveEditMode
{
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Edit" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(enterEditMode)] autorelease];
	[tableView endUpdates];
	[tableView setEditing:NO animated:YES];
}

// Delete the selected file
- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle 
forRowAtIndexPath:(NSIndexPath *)indexPath 
{
	NSString *path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[fileList objectAtIndex:[indexPath row]]];
	[fileList removeObjectAtIndex:[indexPath row]];
	[[NSFileManager defaultManager] removeFileAtPath:path handler:nil];
	[aTableView reloadData];
}

// Data Source Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [fileList count];
}

- (UITableViewCell *)tableView:(UITableView *)tView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
		[cell addSubview:[[UILabel alloc] initWithFrame:CGRectMake(10.0f, 50.0f, 300.0f, 15.0f)]];
		[[[cell subviews] lastObject] setTag:738];
	}

	cell.text = [fileList objectAtIndex:[indexPath row]];
	cell.font = [UIFont systemFontOfSize:18.0f];
	cell.selectionStyle = UITableViewCellSelectionStyleGray;
	
	return cell;
}

// View initialization
- (void) loadView
{
	[super loadView];
	
	bgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BG.png"]];
	bgView.userInteractionEnabled = YES;
	self.view = bgView;
	
	// Add the table
	tableView = [[UITableView alloc] initWithFrame: CGRectMake(10.0f, 32.0f, 300.0f, 340.0f)];
	tableView.rowHeight = 72;
	tableView.delegate = self;
	tableView.dataSource = self;
	[bgView addSubview:tableView];

	// Add the edit button
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Edit" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(enterEditMode)] autorelease];
}

- (void) dealloc
{
	[fileList release];
	[tableView release];
	[bgView release];
	[super dealloc];
}

@end


@interface HelloController : UIViewController
{
	UIImageView				*bgView;
	UIButton				*button;
	BOOL					isRecording;
	Recorder				*myRecorder;
}
@end

@implementation HelloController

- (id) init
{
	if (self = [super init]) self.title = @"Record a Note";
	return self;
}

- (void) move_to_notes
{
	// Stop recording if one is ongoing
	if (isRecording) 
	{
		[button setBackgroundImage:[UIImage imageNamed:@"green.png"] forState:UIControlStateNormal];
		[button setBackgroundImage:[UIImage imageNamed:@"green2.png"] forState:UIControlStateHighlighted];
		[myRecorder toggleRecording];
		isRecording = !isRecording;
	}
	[[self navigationController] pushViewController:[[NotesController alloc] init]  animated:YES];
}

- (void) record_button_pushed
{
	// Toggle the recording mode
	if (!myRecorder) myRecorder = [[Recorder alloc] init];
	
	[myRecorder toggleRecording];
	isRecording = !isRecording;
	
	if (isRecording)
	{
		[button setBackgroundImage:[UIImage imageNamed:@"red.png"] forState:UIControlStateNormal];
		[button setBackgroundImage:[UIImage imageNamed:@"red2.png"] forState:UIControlStateHighlighted];
	} else {
		[button setBackgroundImage:[UIImage imageNamed:@"green.png"] forState:UIControlStateNormal];
		[button setBackgroundImage:[UIImage imageNamed:@"green2.png"] forState:UIControlStateHighlighted];
	}
}

- (void) loadView
{
	[super loadView];
	
	bgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BG.png"]];
	bgView.userInteractionEnabled = YES;
	self.view = bgView;
	[bgView release];
	
	// Add Notes Button
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Library" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(move_to_notes)] autorelease];
	
	// Add the record button
	button = [[UIButton alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 219.0f, 233.0f)];
	button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
	[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
	[button setFont:[UIFont boldSystemFontOfSize:24.0f]];
	[button setCenter:CGPointMake(160.0f, 200.0f)];
	
	// Prepare button for going
	[button setBackgroundImage:[[UIImage imageNamed:@"green.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateNormal];
	[button setBackgroundImage:[[UIImage imageNamed:@"green2.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateHighlighted];
	[button addTarget:self action:@selector(record_button_pushed) forControlEvents:UIControlEventTouchUpInside];
	
	isRecording = NO;
	myRecorder = NULL;

	[bgView addSubview:button];
	[button release];
}

@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
