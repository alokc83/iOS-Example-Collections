#import <UIKit/UIKit.h>
#include <unistd.h>

@interface UIApplication (expanded)
- (void) terminate;
@end

@interface HelloController : UIImagePickerController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@end

@implementation HelloController

#define SOURCETYPE UIImagePickerControllerSourceTypePhotoLibrary
#define DOCSFOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

- (id) init
{
	if (!(self = [super init])) return self;
	
	// Attempt to use a Photo Library browser
	if ([UIImagePickerController isSourceTypeAvailable:SOURCETYPE])	self.sourceType = SOURCETYPE;
	self.delegate = self;
	return self;
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
	// Find a unique path name so files are not over-written
	int i = 0;
	NSString *uniquePath = [DOCSFOLDER stringByAppendingPathComponent:@"selectedImage.png"];
	while ([[NSFileManager defaultManager] fileExistsAtPath:uniquePath])
		uniquePath = [NSString stringWithFormat:@"%@/%@-%d.%@", DOCSFOLDER, @"selectedImage", ++i, @"png"];
	
	printf("Writing selected image to Documents folder\n");
	[UIImagePNGRepresentation(image)  writeToFile: uniquePath atomically:YES];
	[self popToRootViewControllerAnimated:YES];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	printf("User cancelled\n");
	[self popToRootViewControllerAnimated:YES];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	HelloController *hello = [[HelloController alloc] init];
	[window addSubview:hello.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
