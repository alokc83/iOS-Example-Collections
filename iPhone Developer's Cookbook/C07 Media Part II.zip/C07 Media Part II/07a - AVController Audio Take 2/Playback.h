#import <MediaPlayer/MediaPlayer.h>

@interface AVItem : NSObject
@end

@interface MPItem : AVItem
- (id)initWithPath:(NSString *)path error:(id *)anError;
@end

@interface MPAVController : NSObject
+ (id) sharedInstance;
- (id) avController;
@end

@interface AVController : NSObject
- (void) play: (id *) whatever;
- (void) pause;
- (void) setQueueFeeder:(id)fp8;
@end

@interface AVQueueFeeder : NSObject
@end

@interface AVArrayQueueFeeder : AVQueueFeeder
@end

@interface MPQueueFeeder : AVQueueFeeder
@end

@interface MPArrayQueueFeeder : MPQueueFeeder
- (id) initWithPaths:(id)fp8;
@end
