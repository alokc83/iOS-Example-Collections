#import <UIKit/UIKit.h>
#import "Playback.h"

@interface HelloController : UIViewController
{
	UIButton		*button;
	AVController	*avc;
}
@end

@implementation HelloController

- (id) init
{
	if (self = [super init]) self.title = @"Audio Player";
	return self;
}

- (void) startPlayback : (id) sender
{
	avc = [[MPAVController sharedInstance] avController];
	NSString *path = [[NSBundle mainBundle] pathForResource:@"dream" ofType:@"m4a"];

	id feeder = [[MPArrayQueueFeeder alloc] initWithPaths:[NSArray arrayWithObject:path]];
	[avc setQueueFeeder:feeder];
	[avc play:nil];
	[feeder release];

	// Prepare button for stopping
	[button setTitle:@"Stop" forState:UIControlStateNormal];
	[button setTitle:@"Stop" forState:UIControlStateHighlighted];
	[button setBackgroundImage:[[UIImage imageNamed:@"red.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateNormal];
	[button setBackgroundImage:[[UIImage imageNamed:@"red2.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateHighlighted];
	[button removeTarget:self action:@selector(startPlayback:) forControlEvents:UIControlEventTouchUpInside];
	[button addTarget:self action:@selector(stopPlayback:) forControlEvents: UIControlEventTouchUpInside];	
}

- (void) setUpForPlay: (NSNotification *) notification
{
	// Prepare button for re-starting
	[button setTitle:@"Start" forState:UIControlStateNormal];
	[button setTitle:@"Start" forState:UIControlStateHighlighted];
	[button setBackgroundImage:[[UIImage imageNamed:@"green.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateNormal];
	[button setBackgroundImage:[[UIImage imageNamed:@"green2.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateHighlighted];
	[button removeTarget:self action:@selector(stopPlayback:) forControlEvents:UIControlEventTouchUpInside];
	[button addTarget:self action:@selector(startPlayback:) forControlEvents: UIControlEventTouchUpInside];
}

- (void ) stopPlayback : (id) sender
{
	[avc pause];
	[self setUpForPlay:NULL];
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	UIImageView *contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluelined.png"]];
	[contentView setUserInteractionEnabled:YES];
	self.view = contentView;
	[contentView release];
	
	// Create a start/stop button
	button = [UIButton buttonWithType:UIButtonTypeCustom];
	[button setFrame:CGRectMake(0.0f, 0.0f, 219.0f, 233.0f)];
	button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
	
	[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
	[button setFont:[UIFont boldSystemFontOfSize:24.0f]];
	[button setCenter:CGPointMake(160.0f, 200.0f)];
	[self setUpForPlay:NULL];
	
	[self.view addSubview: button]; // no release for buttonWithType

	// Prepare for playback end notification
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(setUpForPlay:)
												 name:@"AVController_ItemPlaybackDidEnd" 
											   object:nil];
}

-(void) dealloc
{
	if (avc) [avc release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> {
}
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}

- (void)applicationWillTerminate:(UIApplication *)application  {
}

- (void)dealloc {
	[super dealloc];
}

@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
