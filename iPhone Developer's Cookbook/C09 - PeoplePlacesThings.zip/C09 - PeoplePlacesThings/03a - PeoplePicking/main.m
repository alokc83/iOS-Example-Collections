#import <UIKit/UIKit.h>
#import <AddressBookUI/AddressBookUI.h>

@interface HelloController : UIViewController <ABPeoplePickerNavigationControllerDelegate>
{
	UIImageView *contentView;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"People Picker";
	return self;
}

- (NSString *) getName: (ABRecordRef) person
{
	NSString *firstName = [(NSString *)ABRecordCopyValue(person, kABPersonFirstNameProperty) autorelease];
	NSString *lastName = [(NSString *)ABRecordCopyValue(person, kABPersonLastNameProperty) autorelease];
	NSString *biz = [(NSString *)ABRecordCopyValue(person, kABPersonOrganizationProperty) autorelease];
	
	if ((!firstName) && !(lastName)) 
	{
		if (biz) return biz;
		return @"[No name supplied]";
	}
	
	if (!lastName) lastName = @"";
	if (!firstName) firstName = @"";
	
	return [[NSString stringWithFormat:@"%@ %@", firstName, lastName] autorelease];
}

- (BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person
{
	self.title = [self getName:person];
	return YES;
}


- (BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
{
	id theProperty = (id)ABRecordCopyValue(person, property);
	int propertyType = ABPersonGetTypeOfProperty(property);
	
	 if (propertyType == kABStringPropertyType)	 {
		 printf("%s\n", [theProperty UTF8String]);
	 } else if (propertyType == kABIntegerPropertyType)	 {
		 printf("%d\n", [theProperty integerValue]);
	 } else if (propertyType == kABRealPropertyType)	 {
		 printf("%d\n", [theProperty floatValue]);
	 } else if (propertyType == kABDateTimePropertyType)	 {
		 printf("%s\n", [[theProperty description] UTF8String]);
	 } else if (propertyType == kABMultiStringPropertyType)	 {
		 printf("%s\n",
				[[(NSArray *)ABMultiValueCopyArrayOfAllValues(theProperty) objectAtIndex:identifier] UTF8String]);
	 } else if (propertyType == kABMultiIntegerPropertyType)	 {
		 printf("%d\n",	[[(NSArray *)ABMultiValueCopyArrayOfAllValues(theProperty) objectAtIndex:identifier] integerValue]);
	 } else if (propertyType == kABMultiRealPropertyType)	 {
		 printf("%f\n",	[[(NSArray *)ABMultiValueCopyArrayOfAllValues(theProperty) objectAtIndex:identifier] floatValue]);

	 } else if (propertyType == kABMultiDateTimePropertyType)	 {
		 printf("%s\n",	[[[(NSArray *)ABMultiValueCopyArrayOfAllValues(theProperty) objectAtIndex:identifier] description] UTF8String]);

	 } else if (propertyType == kABMultiDictionaryPropertyType)	 {
		 printf("%s\n",	[[[(NSArray *)ABMultiValueCopyArrayOfAllValues(theProperty) objectAtIndex:identifier] description] UTF8String]);
	 }
	

	[self dismissModalViewControllerAnimated:YES];
	CFRelease(theProperty);
	[peoplePicker release];

	return NO;
}

- (void) peoplePickerNavigationControllerDidCancel: (ABPeoplePickerNavigationController *)peoplePicker
{
	[self dismissModalViewControllerAnimated:YES];
	[peoplePicker release];
}

- (void) presentSheet
{
	ABPeoplePickerNavigationController *ab = [[ABPeoplePickerNavigationController alloc] init];
	[ab setPeoplePickerDelegate:self];
	[self presentModalViewController:ab animated:YES];
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]] autorelease];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	self.view = contentView;
	
	// Add an action button
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Pick" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(presentSheet)] autorelease];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
