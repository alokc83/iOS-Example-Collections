#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreLocation/CLLocationManagerDelegate.h>


@interface XMLParser : NSObject
{
	NSString		*current;
	NSMutableString	*outstring;
}

+(XMLParser *) sharedInstance;
@end

@implementation XMLParser

static XMLParser *sharedInstance = nil;

+(XMLParser *) sharedInstance 
{
    if(!sharedInstance) {
		sharedInstance = [[self alloc] init];
    }
    return sharedInstance;
}

- (NSString *)parseXMLFile: (NSURL *) url
{	
	outstring = [[NSMutableString alloc] init];
	
    NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:url];
    [parser setDelegate:self];
	[parser parse];
    [parser release];
	
	return [outstring autorelease];
}

- (NSString *)parseXMLData: (NSData *) data
{	
	outstring = [[NSMutableString alloc] init];
	
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser parse];
    [parser release];
	
	return [outstring autorelease];
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	CFShow(elementName);
    if (qName) elementName = qName;
	if (elementName) 
		current = [NSString stringWithString:elementName];
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
	if (current) [current release];
	current = NULL;
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if (!current) return;
	if ([current isEqualToString:@"country"] ||
		[current isEqualToString:@"state"] ||
		[current isEqualToString:@"zipcode"] ||
		[current isEqualToString:@"neighbourhood"])
		[outstring appendFormat:@"%@: %@\n", current, string];
}

- (void) dealloc
{
	[current release];
	[outstring release];
	[super dealloc];
}

@end

@interface HelloController : UIViewController <CLLocationManagerDelegate>
{
	UITextView				*contentView;
	CLLocationManager		*locmanager;
	BOOL					isLocating;
	BOOL					wasFound;
}
@end

@implementation HelloController 

- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Location";
	return self;
}

- (void) doIt
{
	if (isLocating)
	{
		[contentView setText:@"Scanning ended by request."];
		[locmanager stopUpdatingLocation];
		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
												  initWithTitle:@"Find Me" 
												  style:UIBarButtonItemStylePlain 
												  target:self 
												  action:@selector(doIt)] autorelease];
	} else {
		wasFound = NO;
		
		[contentView setText:@"Scanning for location..."];
		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
												  initWithTitle:@"Stop" 
												  style:UIBarButtonItemStylePlain 
												  target:self 
												  action:@selector(doIt)] autorelease];
		[locmanager startUpdatingLocation];
	}
	isLocating = !isLocating;
}

#define APPTOKEN @"YOUR TOKEN HERE"

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
	if (wasFound) return;
	wasFound = YES;
	isLocating = NO;
	self.navigationItem.rightBarButtonItem = NULL;
	
	CLLocationCoordinate2D loc = [newLocation coordinate];
	[contentView setText:@"Location found. Looking up information via Yahoo."];

	if ([APPTOKEN isEqualToString:@"YOUR TOKEN HERE"]) 
	{
		[contentView setText:@"Error: you need to use your Yahoo App Token\n"];
		return;
	}
	
	// Contact Yahoo and make a local info request
	NSString *requestString = [NSString stringWithFormat:@"http://zonetag.research.yahooapis.com/services/rest/V1/suggestedTags.php?apptoken=%@&latitude=%f&longitude=%f&output=xml",
							  APPTOKEN, // Please use your own apptoken
							  loc.latitude, loc.longitude];
	NSURL *url = [NSURL URLWithString:requestString];
	NSString *string = [[[NSString stringWithContentsOfURL:url] substringFromIndex:[APPTOKEN length]] autorelease];
	[contentView setText:[[XMLParser sharedInstance] parseXMLData:[string dataUsingEncoding:NSUTF8StringEncoding]]];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Find Me" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doIt)] autorelease];
	[contentView setText:@"Location search failed"];
	isLocating = NO;
}


- (void)loadView
{
	contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setEditable:NO];
	self.view = contentView;
	[contentView release];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Find Me" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doIt)] autorelease];
	
	locmanager = [[CLLocationManager alloc] init];
	[locmanager setDelegate:self];
	[locmanager setDesiredAccuracy:kCLLocationAccuracyBest];
	
	isLocating = NO;
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
