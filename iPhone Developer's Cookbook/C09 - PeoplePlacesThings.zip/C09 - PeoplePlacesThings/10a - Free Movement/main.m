#import <UIKit/UIKit.h>
#import <math.h>

@interface HelloController : UIViewController <UIAccelerometerDelegate>
{
	UIImageView *contentView;
	UIImageView *butterfly;
	float xaccel, yaccel, xvelocity, yvelocity;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Accelerometer";
	return self;
}

- (void) tick
{
	// Move the butterfly according to the current velocity vector
	CGRect rect = [butterfly frame];
	rect.origin.x += xvelocity;
	rect.origin.y += yvelocity;
	
	// Check for boundary conditions so the butterfly stays on-screen
	if (rect.origin.x > 260.0f) rect.origin.x = 260.0f;
	if (rect.origin.x < 0.0f) rect.origin.x = 0.0f;
	if (rect.origin.y > 356.0f)  rect.origin.y = 356.0f;
	if (rect.origin.y < 0.0f) rect.origin.y = 0.0f;
	
	[butterfly setFrame:rect];
}

#define SIGN(x)	((x < 0.0f) ? -1.0f : 1.0f)

- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
	// extract the acceleration components
	float xx = -[acceleration x];
	float yy = [acceleration y];

	// Has the direction changed?
	float accelDirX = SIGN(xvelocity) * -1.0f; 
	float newDirX = SIGN(xx);
	float accelDirY = SIGN(yvelocity) * -1.0f;
	float newDirY = SIGN(yy);
	
	// Accelerate. To increase viscosity lower the values below 1.0f
	if (accelDirX == newDirX) 
		xaccel = (abs(xaccel) + 0.85f) * SIGN(xaccel);
	if (accelDirY == newDirY) 
		yaccel = (abs(yaccel) + 0.85f) * SIGN(yaccel);

	// Apply acceleration changes to the current velocity
	xvelocity = -xaccel * xx;
	yvelocity = -yaccel * yy;
}

- (void)loadView
{
	contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	self.view = contentView;
	[contentView release];

	// Create the butterfly
	butterfly = [[UIImageView alloc] initWithFrame:CGRectMake(40.0f, 300.0f, 60.0f, 60.0f)];
	[contentView addSubview:butterfly];
	[butterfly release];
	
	// Load the animation cells
	NSMutableArray *bflies = [[NSMutableArray alloc] init];
	for (int i = 1; i <= 17; i++) {
		NSString *cname = [NSString stringWithFormat:@"bf_%d.png", i];
		UIImage *img = [UIImage imageNamed:cname];
		if (img) [bflies addObject:img];
		[cname release];
	}
	
	// Begin the animation
	[butterfly setAnimationImages:bflies];
	butterfly.animationDuration = 0.75f;
	[butterfly startAnimating];
	[bflies release];
	
	// Center the butterfly
	[butterfly setCenter:CGPointMake(160.0f, 208.0f)];
	
	// Set the butterfly's initial speed and acceleration
	xaccel = 2.0f;
	yaccel = 2.0f;
	xvelocity = 0.0f;
	yvelocity = 0.0f;
	
	// Activate the accelerometer
	[[UIAccelerometer sharedAccelerometer] setDelegate:self];
	
	// Start the physics timer
    [NSTimer scheduledTimerWithTimeInterval: 0.03f
									 target: self
								   selector: @selector(tick)
								   userInfo: nil
									repeats: YES];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
