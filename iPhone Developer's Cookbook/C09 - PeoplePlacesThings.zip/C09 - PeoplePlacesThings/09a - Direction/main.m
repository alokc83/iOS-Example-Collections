#import <UIKit/UIKit.h>
#import <math.h>

@interface HelloController : UIViewController <UIAccelerometerDelegate>
{
	UIImageView *contentView;
	UIImageView *arrowView;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Accelerometer";
	return self;
}

- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
	float xx = -[acceleration x];
	float yy = [acceleration y];
	float angle = atan2(yy, xx);
	
	[arrowView setTransform:CGAffineTransformMakeRotation(angle)];
}

- (void)loadView
{
	contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	[contentView setUserInteractionEnabled:YES];
	self.view = contentView;
	[contentView release];

	arrowView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"arrow.png"]];
	[arrowView setCenter:CGPointMake(160.0f, 208.0f)];
	[contentView addSubview:arrowView];
	[arrowView release];
	
	[[UIAccelerometer sharedAccelerometer] setDelegate:self];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
