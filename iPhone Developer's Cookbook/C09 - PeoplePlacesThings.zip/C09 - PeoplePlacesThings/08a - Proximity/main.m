#import <UIKit/UIKit.h>
#include <unistd.h>

@interface HelloController : UIViewController
{
	UIView *contentView;
}
@end

@implementation HelloController
- (void) enable
{
	[[UIApplication sharedApplication] setProximitySensingEnabled:YES];
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Disable Proximity" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(disable)] autorelease];
}

- (void) disable
{
	[[UIApplication sharedApplication] setProximitySensingEnabled:NO];
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Enable Proximity" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(enable)] autorelease];
}

- (void)loadView
{
	contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	contentView.backgroundColor = [UIColor whiteColor];
    [contentView release];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Enable Proximity" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(enable)] autorelease];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
