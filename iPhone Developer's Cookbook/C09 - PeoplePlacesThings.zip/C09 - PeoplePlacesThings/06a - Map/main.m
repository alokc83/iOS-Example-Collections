#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreLocation/CLLocationManagerDelegate.h>


@interface HelloController : UIViewController <CLLocationManagerDelegate, UIScrollViewDelegate>
{
	UITextView			*contentView;
	CLLocationManager	*locmanager;
	BOOL				isLocating;
	UIImageView			*imgView;
	BOOL				wasFound;
}
@end

@implementation HelloController 

- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Location";
	return self;
}

- (void) doIt
{
	if (isLocating)
	{
		[contentView setText:@"Scanning ended by request."];
		[locmanager stopUpdatingLocation];
		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
												  initWithTitle:@"Find Me" 
												  style:UIBarButtonItemStylePlain 
												  target:self 
												  action:@selector(doIt)] autorelease];
	} else {
		wasFound = NO;
		[contentView setText:@"Scanning for location..."];
		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
												  initWithTitle:@"Stop" 
												  style:UIBarButtonItemStylePlain 
												  target:self 
												  action:@selector(doIt)] autorelease];
		[locmanager startUpdatingLocation];
	}
	isLocating = !isLocating;
}

- (UIView *)scrollViewWillBeginZooming:(UIScrollView *)scrollView
{
	return imgView;
}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(float)scale
{
}

#define APPTOKEN @"YOUR TOKEN HERE"

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
	if (wasFound) return;
	wasFound = YES;
	self.navigationItem.rightBarButtonItem = NULL;
	
	CLLocationCoordinate2D loc = [newLocation coordinate];
	[contentView setText:@"Location found. Looking up information via Yahoo."];
	
	if ([APPTOKEN isEqualToString:@"YOUR TOKEN HERE"]) 
	{
		[contentView setText:@"You need to supply an application token to use Yahoo services"];
		return;
	}
	
	// Contact Yahoo and make a local info request
	NSString *requestString = [NSString stringWithFormat:@"http://local.yahooapis.com/MapsService/V1/mapImage?appid=%@&latitude=%f&longitude=%f",
							  APPTOKEN, // Please use your own apptoken
							  loc.latitude, loc.longitude];
	printf("%s\n", [requestString UTF8String]);

	// Retrieve the direct map location from the request URL
	NSURL *url = [NSURL URLWithString:requestString];
	NSString *directLocation = [NSString stringWithContentsOfURL:url];
	
	// Scan through XML for the map URL
	NSMutableString *mapURLString;
	NSScanner *scanner = [NSScanner scannerWithString:directLocation];
	[scanner scanUpToString:@">http://" intoString:NULL]; // first
	[scanner scanUpToString:@"http://" intoString:NULL]; // second
	[scanner scanUpToString:@"<" intoString:&mapURLString];

	// Retrieve the image
	url = [NSURL URLWithString:mapURLString];
	UIImage *img = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
	NSData *imgData = UIImageJPEGRepresentation(img, 1.0f);
	
	UIWebView *wv = [[UIWebView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView addSubview:wv];
	[wv loadData:imgData MIMEType:@"image/jpeg" textEncodingName:NULL baseURL:NULL];
	[wv setScalesPageToFit:YES];
	self.view = wv;
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Find Me" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doIt)] autorelease];
	[contentView setText:@"Location search failed"];
	isLocating = NO;
}


- (void)loadView
{
	contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setEditable:NO];
	self.view = contentView;
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Find Me" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doIt)] autorelease];
	
	locmanager = [[CLLocationManager alloc] init];
	[locmanager setDelegate:self];
	[locmanager setDesiredAccuracy:kCLLocationAccuracyBest];
	
	isLocating = NO;
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
