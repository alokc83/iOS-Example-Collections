#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreLocation/CLLocationManagerDelegate.h>

@interface HelloController : UIViewController <CLLocationManagerDelegate>
{
	UITextView *contentView;
	CLLocationManager *locmanager;
	BOOL	isLocating;
}
@end

@implementation HelloController 

- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Location";
	return self;
}

- (void) doIt
{
	if (isLocating)
	{
		[contentView setText:@"Scanning ended by request."];
		[locmanager stopUpdatingLocation];
		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
												  initWithTitle:@"Find Me" 
												  style:UIBarButtonItemStylePlain 
												  target:self 
												  action:@selector(doIt)] autorelease];
	} else {
		[contentView setText:@"Scanning for location..."];
		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
												  initWithTitle:@"Stop" 
												  style:UIBarButtonItemStylePlain 
												  target:self 
												  action:@selector(doIt)] autorelease];
		[locmanager startUpdatingLocation];
	}
	isLocating = !isLocating;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
	// Log the kind of accuracy we got from this
	NSLog(@"%f %f", [newLocation horizontalAccuracy], [newLocation verticalAccuracy]);
	
	// Location has been found. Create GMap URL
	CLLocationCoordinate2D loc = [newLocation coordinate];

	NSString *mapString = [NSString stringWithFormat: @"http://maps.google.com/maps?q=%f,%f", loc.latitude, loc.longitude];
	NSURL *url = [NSURL URLWithString:mapString];
	
	// Switch to Safari and display that map
	[[UIApplication sharedApplication] openURL:url];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Find Me" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doIt)] autorelease];
	[contentView setText:@"Location search failed"];
	isLocating = NO;
}


- (void)loadView
{
	contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setEditable:NO];
	self.view = contentView;
	[contentView release];
	
	locmanager = [[CLLocationManager alloc] init];
	[locmanager setDelegate:self];
	[locmanager setDesiredAccuracy:kCLLocationAccuracyBest];
	if (![locmanager locationServicesEnabled])
	{
		[contentView setText:@"Location Services Are Not Enabled"];
		return;
	}

	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Find Me" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doIt)] autorelease];
	isLocating = NO;
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
