#import <UIKit/UIKit.h>

@interface HelloController : UIViewController
{
	UITextView			*contentView;
	NSMutableString		*results;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Device Info";
	return self;
}

- (void) doit
{
	results = [[NSMutableString alloc] init];
	
	[results appendFormat:@"Identifier:\n %@\n", [[UIDevice currentDevice] uniqueIdentifier]];
	[results appendFormat:@"Model: %@\n", [[UIDevice currentDevice] model]];
	[results appendFormat:@"Localized Model: %@\n", [[UIDevice currentDevice] localizedModel]];
	[results appendFormat:@"Name: %@\n", [[UIDevice currentDevice] name]];
	[results appendFormat:@"System Name: %@\n", [[UIDevice currentDevice] systemName]];
	[results appendFormat:@"System Version: %@\n", [[UIDevice currentDevice] systemVersion]];
	
	[contentView setText:results];
}

- (void)loadView
{
	contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setEditable:NO];
	self.view = contentView;
	[contentView release];

	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doit)] autorelease];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
