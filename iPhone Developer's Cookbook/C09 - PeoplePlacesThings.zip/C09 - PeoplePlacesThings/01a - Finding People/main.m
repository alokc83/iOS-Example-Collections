#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>
#import <AddressBook/ABPerson.h>
#import <AddressBook/ABRecord.h>

@interface HelloController : UITableViewController <UISearchBarDelegate>
{
	NSMutableArray *peopleArray;
	NSMutableArray *searchArray;
	UISearchBar *search;
}
@end

// MyCreateBitmapContext: Source based on Apple Sample Code
CGContextRef MyCreateBitmapContext (int pixelsWide,
									int pixelsHigh)
{
    CGContextRef    context = NULL;
    CGColorSpaceRef colorSpace;
    void *          bitmapData;
    int             bitmapByteCount;
    int             bitmapBytesPerRow;
	
    bitmapBytesPerRow   = (pixelsWide * 4);
    bitmapByteCount     = (bitmapBytesPerRow * pixelsHigh);
	
    colorSpace = CGColorSpaceCreateDeviceRGB();
    bitmapData = malloc( bitmapByteCount );
    if (bitmapData == NULL)
    {
        fprintf (stderr, "Memory not allocated!");
        return NULL;
    }
    context = CGBitmapContextCreate (bitmapData,
									 pixelsWide,
									 pixelsHigh,
									 8,
									 bitmapBytesPerRow,
									 colorSpace,
									 kCGImageAlphaPremultipliedLast);
    if (context== NULL)
    {
        free (bitmapData);
        fprintf (stderr, "Context not created!");
        return NULL;
    }
    CGColorSpaceRelease( colorSpace );
	
    return context;
}

#define IMG_SIZE	60

id createImage(CGImageRef image)
{
	CGRect aRect = CGRectMake(0.0f, 0.0f, IMG_SIZE, IMG_SIZE);
	CGContextRef context = MyCreateBitmapContext(IMG_SIZE, IMG_SIZE);
	CGContextClearRect(context, aRect);
	CGContextDrawImage(context, aRect, image);
	
	CGImageRef myRef = CGBitmapContextCreateImage (context);
	free(CGBitmapContextGetData(context));
	CGContextRelease(context);
	
	return [UIImage imageWithCGImage:myRef];
}

@implementation HelloController
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [searchArray count];
}

- (NSString *) getName: (ABRecordRef) person
{
	NSString *firstName = [(NSString *)ABRecordCopyValue(person, kABPersonFirstNameProperty) autorelease];
	NSString *lastName = [(NSString *)ABRecordCopyValue(person, kABPersonLastNameProperty) autorelease];
	NSString *biz = [(NSString *)ABRecordCopyValue(person, kABPersonOrganizationProperty) autorelease];
	
	
	if ((!firstName) && !(lastName)) 
	{
		if (biz) return biz;
		return @"[No name supplied]";
	}
	
	if (!lastName) lastName = @"";
	if (!firstName) firstName = @"";
	
	return [NSString stringWithFormat:@"%@ %@", firstName, lastName];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSInteger row = [indexPath row];
	UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (cell == nil) 
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
	
	id person = [searchArray objectAtIndex:row];
	cell.text = [self getName:person];
	
	 if (ABPersonHasImageData(person))
	 {
		 UIImage *img = createImage([[UIImage imageWithData:(NSData *)ABPersonCopyImageData(person)] CGImage]);
		 [cell setImage:img];
	 }
	 else 
		 [cell setImage:NULL];
	
	return cell;
}

- (void) deselect
{	
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	// [self performSelector:@selector(deselect) withObject:NULL afterDelay:0.5];
}

- (void) buildSearchArrayFrom: (NSString *) matchString
{
	NSString *upString = [matchString uppercaseString];
	if (searchArray) [searchArray release];
	
	searchArray = [[NSMutableArray alloc] init];
	for (NSString *person in peopleArray)
	{
		// Add everyone when there's nothing to match to
		if ([matchString length] == 0)
		{
			[searchArray addObject:person];
			continue;
		}
		
		// Add the person if the string matches
		NSRange range = [[[self getName:person] uppercaseString] rangeOfString:upString];
		if (range.location != NSNotFound) [searchArray addObject:person];
	}
	
	[self.tableView reloadData];
}

// When the search text changes, update the array
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
	[self buildSearchArrayFrom:searchText];
}

// When the search button (i.e. "Done") is clicked, hide the keyboard
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
	[searchBar resignFirstResponder];
}

// Prepare the Table View
- (void)loadView
{
	[super loadView];
	self.tableView.rowHeight = 80;
	
	peopleArray = (NSMutableArray *)ABAddressBookCopyArrayOfAllPeople(ABAddressBookCreate());
	[self buildSearchArrayFrom:@""];
	
	search = [[UISearchBar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 280.0f, 44.0f)];
	search.delegate = self;
	search.placeholder = @"name match text";
	search.autocorrectionType = UITextAutocorrectionTypeNo;
	search.autocapitalizationType = UITextAutocapitalizationTypeNone;
	self.navigationItem.titleView = search;
	[search release];

	// "Search" is the wrong key usage here. Replacing it with "Done"
	UITextField *searchField = [[search subviews] lastObject];
	[searchField setReturnKeyType:UIReturnKeyDone];
}

// Clean up
-(void) dealloc
{
	[peopleArray release];
	[searchArray release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
