#import <UIKit/UIKit.h>
#import "CoverFlowView.h"
#import "CoverViewController.h"

#define CVC_VIEW_TAG		999

@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {

	// Hide the status bar
	[[UIApplication sharedApplication] setStatusBarHidden:YES];
	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	CoverViewController *cvc = [[CoverViewController alloc] init];
	cvc.view.tag = CVC_VIEW_TAG;
	[window addSubview:cvc.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
