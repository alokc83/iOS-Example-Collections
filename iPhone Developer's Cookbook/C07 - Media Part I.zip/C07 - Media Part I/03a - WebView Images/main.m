#import <UIKit/UIKit.h>

#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

//
//
// NOTE: The initial sizing issues mentioned in the book seem to have resolved in the 2.1 SDK
//
//

@interface WebController : UIViewController
{
	UIWebView *webView;
}
@property (nonatomic, retain)	UIWebView *webView;
@end

@implementation WebController
@synthesize webView;

// This initialize function allows the view to load in advance of "loadView"
- (id)initWithFile: filename
{
	// Create a web view
	NSString *path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:filename];
	self.webView = [[UIWebView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[self.webView setScalesPageToFit:YES];
	
	// Load the web view from the supplied file URL
	NSURL *fileURL = [[NSURL alloc] initFileURLWithPath:path];
	NSURLRequest *req = [NSURLRequest requestWithURL:fileURL];
	[self.webView loadRequest:req];
	return self;
}

- (void)loadView
{
	self.view = self.webView;
	[self.webView release];
}

-(void) dealloc
{
	[self.webView release];
	[super dealloc];
}
@end


@interface HelloController : UITableViewController 
{
	NSMutableArray *fileList;
}
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Images";
	fileList = (NSMutableArray *) [[[[NSFileManager defaultManager] directoryContentsAtPath:DOCUMENTS_FOLDER]
									pathsMatchingExtensions:[NSArray arrayWithObjects:@"png", @"JPG", @"tiff", @"pdf", nil]] retain];
	return self;
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

- (void) loadView
{
	[super loadView];

	// Reveal the documents folder -- so you can fill it for the simulator
	printf("Documents folder is %s\n", [DOCUMENTS_FOLDER UTF8String]);
	
	// Provide support for auto-rotation and resizing
	self.tableView.autoresizesSubviews = YES;
	self.tableView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
	
}

// Only one section in this table
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

// Return how many rows in the table
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [fileList count];
}

// Return a cell for the ith row
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (cell == nil) {
		cell = [[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"];
	}
	// Set up the cell
	cell.text = [fileList objectAtIndex:[indexPath row]];
	return cell;
}

// Respond to user selection
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	WebController *wc = [[WebController alloc] initWithFile:[fileList objectAtIndex:[newIndexPath row]]];
	[[self navigationController] pushViewController:wc animated:YES];
}

-(void) dealloc
{
	[fileList release];
	[super dealloc];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
