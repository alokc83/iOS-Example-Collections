#import <UIKit/UIKit.h>

#define IMAGE_VIEW_TAG	999

@interface HelloController : UIViewController <UIScrollViewDelegate>
@end

@implementation HelloController
- (id)init
{
	if (self = [super init])
	{
		self.title = @"Weather Map";
	}
	return self;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
	return [self.view viewWithTag:IMAGE_VIEW_TAG];
}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(float)scale
{
}

- (void)loadView
{
	// Download the weather map and load it into the image view
	NSURL *url = [NSURL URLWithString:@"http://image.weather.com/images/maps/current/curwx_600x405.jpg"];
	UIImage *img = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
	UIImageView *imgView = [[UIImageView alloc] initWithImage:img];
	imgView.tag = IMAGE_VIEW_TAG;
	imgView.userInteractionEnabled = NO;

	// Set up the main scroller as our content
	UIScrollView *contentView = [[UIScrollView alloc] initWithFrame: [[UIScreen mainScreen] applicationFrame]];
	[contentView setScrollEnabled:YES];
	[contentView setContentSize:[img size]];
	[contentView setMaximumZoomScale: 2.0f];
	[contentView setMinimumZoomScale: 0.5f];
	[contentView setDelegate:self];

	[contentView addSubview:imgView];
	[imgView release];

	self.view = contentView;
    [contentView release];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
