#import <UIKit/UIKit.h>

@interface PleaseWaitView : UIImageView
@end
@implementation PleaseWaitView

- (PleaseWaitView *) initWithFrame: (CGRect) rect
{
	self = [super initWithFrame:rect];
	[self setImage:[UIImage imageNamed:@"PlsWait.png"]];
	
	UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(40.0f, 300.0f, 60.0f, 60.0f)];
	[self addSubview:imgView];
	[imgView release];
	
	// load in the animtion cells for the butterfly
	NSMutableArray *bflies = [[NSMutableArray alloc] init];
	for (int i = 1; i <= 17; i++) {
		NSString *cname = [NSString stringWithFormat:@"bf_%d.png", i];
		UIImage *img = [UIImage imageNamed:cname];
		if (img) [bflies addObject:img];
		[cname release];
	}
	
	// begin the animation
	[imgView setAnimationImages:bflies];
	imgView.animationDuration = 0.75f;
	[imgView startAnimating];
	[bflies release];
	
	return self;
}

- (void)touchesBegan: (NSSet *) touches withEvent:(UIEvent *)event 
{
	// fade away the overlay
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:1.0];
	
	[self setAlpha:0.0f];
	
	// Complete the animation
	[UIView commitAnimations];
}

@end

#define WAIT_VIEW	999

@interface HelloController : UIViewController
@end

@implementation HelloController 

CGPoint randomPoint() { return CGPointMake(random() % 256, random() % 256); }

- (void) moveButterfly: (NSTimer *) timer
{
	if ([[self.view viewWithTag:WAIT_VIEW] alpha] == 0.0f) {[timer invalidate]; return;}
	
	// Create an animation block around moving the butterfly to a new origin
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:1.0];
	
	// Move the butterfly
	UIImageView *iv = [[[self.view viewWithTag:WAIT_VIEW] subviews] objectAtIndex:0];
	CGRect frame = [iv frame];
	frame.origin = randomPoint();
	[iv setFrame:frame];
	
	// Complete the animation
	[UIView commitAnimations];
}


- (void) presentSheet
{
	if ([[self.view viewWithTag:WAIT_VIEW] alpha] != 0.0f) return;
	
	// Create an animation block around fading in the overlay
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:1.0];
	
	[[self.view viewWithTag:WAIT_VIEW] setAlpha:1.0f];

	// Complete the animation
	[UIView commitAnimations];
	[[self.view viewWithTag:WAIT_VIEW] setUserInteractionEnabled:YES];

	// Give life to the butterfly
	[NSTimer scheduledTimerWithTimeInterval: 4.0f target: self selector: @selector(moveButterfly:)
								   userInfo: nil repeats: YES];	
	
}

- (id) init
{
	if (self = [super init]) self.title = @"Hello World";
	return self;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor whiteColor];
	self.view = contentView;
    [contentView release];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(presentSheet)] autorelease];
	
	PleaseWaitView *pleaseWait = [[[PleaseWaitView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]] autorelease];
	pleaseWait.tag = WAIT_VIEW;
	pleaseWait.alpha = 0.0f;
	[contentView addSubview:pleaseWait];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
