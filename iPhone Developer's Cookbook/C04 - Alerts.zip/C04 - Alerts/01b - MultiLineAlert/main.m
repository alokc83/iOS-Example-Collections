#import <UIKit/UIKit.h>

@interface UIAlertView (extended)
- (void) setNumberOfRows: (int) number;
@end

@interface HelloController : UIViewController <UIAlertViewDelegate>
@end

@implementation HelloController 

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	printf("User Pressed Button %d\n", buttonIndex + 1);
	[alertView release];
}


- (void) presentSheet
{
	UIAlertView *baseAlert = [[UIAlertView alloc] 
							  initWithTitle:@"Alert" message:@"Please select a button" 
							  delegate:self cancelButtonTitle:nil
							  otherButtonTitles:@"One", @"Two", @"Three", nil];
	[baseAlert setNumberOfRows:3];
	[baseAlert show];
}

- (id) init
{
	if (self = [super init]) self.title = @"Hello World";
	return self;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	contentView.backgroundColor = [UIColor whiteColor];
    [contentView release]; 
	
	// Add an action button
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(presentSheet)] autorelease];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
