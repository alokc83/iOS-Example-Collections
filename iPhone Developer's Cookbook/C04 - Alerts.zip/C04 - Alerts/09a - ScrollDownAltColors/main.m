#import <UIKit/UIKit.h>

UIColor *sysBlueColor(float percent) {
	float red = percent * 255.0f;
	float green = (red + 20.0f) / 255.0f;
	float blue = (red + 45.0f) / 255.0f;
	if (green > 1.0) green = 1.0f;
	if (blue > 1.0f) blue = 1.0f;
	
	return [UIColor colorWithRed:percent green:green blue:blue alpha:1.0f];
}

#define	TITLE_TAG	999
#define	MESSAGE_TAG	998

@interface TopAlert : UIView
- (void) setTitle: (NSString *)titleText;
- (void) setMessage: (NSString *)messageText;
@end

@implementation TopAlert
- (void) setTitle: (NSString *)titleText
{
	[(UILabel *)[self viewWithTag:TITLE_TAG] setText:titleText];
}
 
- (void) setMessage: (NSString *)messageText
{
	[(UILabel *)[self viewWithTag:MESSAGE_TAG] setText:messageText];
}

- (TopAlert *) initWithFrame: (CGRect) rect
{
	rect.origin.y = 20.0f - rect.size.height; // Place above status bar
	self = [super initWithFrame:rect];
	
	[self setAlpha:0.9];
	[self setBackgroundColor: sysBlueColor(0.4f)];
	
	// Add button
	UIButton *button = [[UIButton buttonWithType:UIButtonTypeCustom] initWithFrame:CGRectMake(220.0f, 200.0f, 80.0f, 32.0f)];
	[button setBackgroundImage:[UIImage imageNamed:@"whiteButton.png"] forState:UIControlStateNormal];
	[button setTitle:@"Okay" forState: UIControlStateHighlighted];
	[button setTitle:@"Okay" forState: UIControlStateNormal];	
	[button setFont:[UIFont boldSystemFontOfSize:14.0f]];
	[button addTarget:self action:@selector(removeView) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:button];
	
	// Add title
	UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 8.0f, 320.0f, 32.0f)];
	title.text = @"Declaration of Independence";
	title.textAlignment = UITextAlignmentCenter;
	title.textColor = [UIColor whiteColor];
	title.backgroundColor = [UIColor clearColor];
	title.font = [UIFont boldSystemFontOfSize:20.0f];
	[self addSubview:title];
	[title release];
	
	// Add message
	UILabel *message = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 40.0f, 280.0f, 200.0f - 48.0f)];
	message.text = @"When in the Course of human events, it becomes necessary for one people to dissolve the political bands which have connected them with another, and to assume among the powers of the earth, the separate and equal station to which the Laws of Nature and of Nature's God entitle them, a decent respect to the opinions of mankind requires that they should declare the causes which impel them to the separation.";
	message.textAlignment = UITextAlignmentCenter;
	message.numberOfLines = 999;
	message.textColor = [UIColor whiteColor];
	message.backgroundColor = [UIColor clearColor];
	message.lineBreakMode = UILineBreakModeWordWrap;
	message.font = [UIFont systemFontOfSize:[UIFont smallSystemFontSize]];
	[self addSubview:message];
	[message release];	

	return self;
}

- (void) removeView
{
	// Scroll away the overlay
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:0.5];
	
	CGRect rect = [self frame];
	rect.origin.y = -10.0f - rect.size.height;
	[self setFrame:rect];
	
	// Complete the animation
	[UIView commitAnimations];
}

- (void) presentView
{
	// Scroll in the overlay
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:0.5];
	
	CGRect rect = [self frame];
	rect.origin.y = 0.0f;
	[self setFrame:rect];
	
	// Complete the animation
	[UIView commitAnimations];
}
@end


@interface HelloController : UIViewController
{
	TopAlert *alertView;
}
@property (nonatomic, retain)	TopAlert *alertView;
@end

@implementation HelloController 
@synthesize alertView;

- (void) presentSheet
{
	if (self.alertView) [self.alertView presentView];
}

- (id) init
{
	if (self = [super init]) self.title = @"Hello World";
	return self;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	contentView.backgroundColor = [UIColor whiteColor];
    [contentView release]; 
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(presentSheet)] autorelease];
	
	// Create the alert view
	// Optional extras:
	// [alertView setTitle:@"Your Custom Title Here"];
	// [alertView setMessage:@"Your Custom Message Here"];

	self.alertView = [[TopAlert alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 240.0f)];
	[self.alertView setCenter:CGPointMake(160.0f, -140.0f)];
	[contentView addSubview:alertView];
	[self.alertView release];
	
	
}

-(void) dealloc
{
	[self.alertView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
