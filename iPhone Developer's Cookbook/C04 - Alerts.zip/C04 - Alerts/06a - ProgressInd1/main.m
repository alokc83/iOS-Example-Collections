#import <UIKit/UIKit.h>

#define INDICATOR_VIEW	999

@interface HelloController : UIViewController
{
	BOOL progressShowing;
}
@end

@implementation HelloController
- (void) performAction
{
	UIActivityIndicatorView *activityIndicator = (UIActivityIndicatorView *)[self.view viewWithTag:INDICATOR_VIEW];
	if (progressShowing) [activityIndicator stopAnimating]; else [activityIndicator startAnimating];
	progressShowing = !progressShowing;
}

- (id) init
{
	if (self = [super init]) self.title = @"Hello World";
	return self;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	contentView.backgroundColor = [UIColor whiteColor];
    [contentView release]; 
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											   initWithTitle:@"Do It" 
											   style:UIBarButtonItemStylePlain 
											   target:self 
											   action:@selector(performAction)] autorelease];
	
	// Add the progress indicator but do not start it
	progressShowing = NO;
    UIActivityIndicatorView *activityIndicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
	[activityIndicator setCenter:CGPointMake(160.0f, 208.0f)];
    [activityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
	activityIndicator.tag = INDICATOR_VIEW;
    [contentView addSubview:activityIndicator];
	[activityIndicator release];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
