#import <UIKit/UIKit.h>

@interface UIAlertView (extended)
- (void) dismiss;
@end

@interface HelloController : UIViewController <UIAlertViewDelegate>
{
	UIAlertView *baseAlert;
}
@end

@implementation HelloController 

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	printf("User Pressed Button %d\n", buttonIndex + 1);
	[alertView release];
}

- (void) performDismiss: (NSTimer *)timer
{
	[baseAlert dismissWithClickedButtonIndex:0 animated:NO];
	[baseAlert release];
	baseAlert = NULL;
}

- (void) presentSheet
{
	baseAlert = [[UIAlertView alloc] 
							  initWithTitle:@"Alert" message:@"\nMessage to user with asynchronous information" 
							  delegate:self cancelButtonTitle:nil
							  otherButtonTitles: nil];
	[NSTimer scheduledTimerWithTimeInterval:3.0f target:self selector: @selector(performDismiss:)
								   userInfo:nil repeats:NO];
	[baseAlert show];
}

- (id) init
{
	if (self = [super init]) self.title = @"Hello World";
	return self;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	contentView.backgroundColor = [UIColor whiteColor];
    [contentView release];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											   initWithTitle:@"Do It" 
											   style:UIBarButtonItemStylePlain 
											   target:self 
											   action:@selector(presentSheet)] autorelease];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
