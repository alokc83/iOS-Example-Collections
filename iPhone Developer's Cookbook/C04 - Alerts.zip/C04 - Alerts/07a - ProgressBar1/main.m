#import <UIKit/UIKit.h>


@interface UIActionSheet (extended)
- (void) setNumberOfRows: (NSInteger) rows;
- (void) setMessage: (NSString *)message;
@end

#define PROGRESS_BAR	999

@interface HelloController : UIViewController <UIActionSheetDelegate>
{
	float			amountDone;
	UIActionSheet	*baseSheet;
}
@property (nonatomic, retain)	UIActionSheet *baseSheet;
@end

@implementation HelloController 
@synthesize baseSheet;

- (void) incrementBar: (id) timer
{
    amountDone += 1.0f;
	UIProgressView *progbar = (UIProgressView *)[self.baseSheet viewWithTag:PROGRESS_BAR];
    [progbar setProgress: (amountDone / 20.0)];
    if (amountDone > 20.0) 
	{
		[self.baseSheet dismissWithClickedButtonIndex:0 animated:YES]; 
		[timer invalidate];
	}
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	printf("User Pressed Button %d\n", buttonIndex + 1);
	[actionSheet release];
}

- (void) presentSheet
{
	
	if (!self.baseSheet) {
		baseSheet = [[UIActionSheet alloc] 
					 initWithTitle:@"Please Wait"
					 delegate:self 
					 cancelButtonTitle:nil 
					 destructiveButtonTitle: nil
					 otherButtonTitles: nil];
		[baseSheet setNumberOfRows:5];
		[baseSheet setMessage:@"Updating Internal Databases"];
		
		UIProgressView *progbar = [[UIProgressView alloc] initWithFrame:CGRectMake(50.0f, 70.0f, 220.0f, 90.0f)];
		progbar.tag = PROGRESS_BAR;
		[progbar setProgressViewStyle: UIProgressViewStyleDefault];
		[baseSheet addSubview:progbar];
		[progbar release];
	}
	
	UIProgressView *progbar = (UIProgressView *)[self.view viewWithTag:PROGRESS_BAR];
	[progbar setProgress:(amountDone = 0.0f)];
    [NSTimer scheduledTimerWithTimeInterval: 0.5 target: self selector: @selector(incrementBar:) userInfo: nil repeats: YES];
	[baseSheet showInView:self.view];
}

- (id) init
{
	if (self = [super init]) self.title = @"Hello World";
	return self;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	contentView.backgroundColor = [UIColor whiteColor];
    [contentView release]; // reduce retain count by one
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											   action:@selector(presentSheet)] autorelease];
}

- (void) dealloc
{
	if (self.baseSheet) [self.baseSheet release];
	[super dealloc];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
