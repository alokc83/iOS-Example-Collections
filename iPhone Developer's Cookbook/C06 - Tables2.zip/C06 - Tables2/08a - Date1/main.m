#import <UIKit/UIKit.h>

@interface NSDate (extended)
-(NSDate *) dateWithCalendarFormat:(NSString *)format timeZone: (NSTimeZone *) timeZone;
@end

@interface HelloController : UIViewController
{
	UIDatePicker *pickerView;
	UILabel *resultsView;
}
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Date Picker";
	return self;
}

/*
 UIDatePickerModeTime,
 UIDatePickerModeDate,
 UIDatePickerModeDateAndTime,
 UIDatePickerModeCountDownTimer
*/

- (void) changedDate: (UIDatePicker *) picker
{
	NSString *caldate = [[[picker date] dateWithCalendarFormat:@"%B %d, %Y" timeZone:nil] description];
	[resultsView setText:caldate];
}

- (void)loadView
{
	self.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view.backgroundColor = [UIColor lightGrayColor];

	// Add the picker
	float height = 216.0f;
	pickerView = [[UIDatePicker alloc] initWithFrame:CGRectMake(0.0f, 416.0f - height, 320.0f, height)];
	pickerView.datePickerMode = UIDatePickerModeDate;
	[pickerView addTarget:self action:@selector(changedDate:) forControlEvents:UIControlEventValueChanged];
	[self.view addSubview:pickerView];
	[pickerView release];
	
	// Add a results label
	resultsView = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 170.0f, 320.0f, 32.0f)];
	[resultsView setBackgroundColor:[UIColor clearColor]];
	[resultsView setTextAlignment:UITextAlignmentCenter];
	[self.view addSubview:resultsView];
	[resultsView release];
}

-(void) dealloc
{
	[resultsView release];
	[pickerView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
