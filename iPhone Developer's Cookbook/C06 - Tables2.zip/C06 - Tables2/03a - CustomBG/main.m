#import <UIKit/UIKit.h>

@interface HelloController : UITableViewController 
{
	NSMutableArray *sectionArray;
	BOOL clearedIndex;
}
@end

@implementation HelloController
#define ALPHA @"ABCDEFGHIJKLMNOPQRSTUVWXYZ"

- (HelloController *) init
{
	if (self = [super initWithStyle:UITableViewStylePlain]) self.title = @"Crayon Colors";
	return self;
}

// One section for each alphabet member
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return [sectionArray count];
}

// Each row array object contains the members for that section
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [[sectionArray objectAtIndex:section] count];
}

#define ALPHA_ARRAY [NSArray arrayWithObjects: @"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K", @"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S", @"T", @"U", @"V", @"W", @"X", @"Y", @"Z", nil]

// This recipe adds a title for each section
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	return [NSString stringWithFormat:@"Crayon names starting with '%@'", 
			[ALPHA_ARRAY objectAtIndex:section]];
}

// Adding a section index here
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
	return ALPHA_ARRAY;
}

// Convert a 6-character hex color to a UIColor object
- (UIColor *) getColor: (NSString *) hexColor
{
	unsigned int red, green, blue;
	NSRange range;
	range.length = 2;
	
	range.location = 0; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&red];
	range.location = 2; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&green];
	range.location = 4; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&blue];	
	
	return [UIColor colorWithRed:(float)(red/255.0f) green:(float)(green/255.0f) blue:(float)(blue/255.0f) alpha:1.0f];
}

// Return a cell on demand
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	// if the Index background has not yet been cleared, clear it
	if (!clearedIndex) {
		for (UIView *view in [tableView subviews])
			if ([[[view class] description] isEqualToString:@"UITableViewIndex"]) {
				[view setBackgroundColor:[UIColor clearColor]];
				// [view setFont:[UIFont boldSystemFontOfSize:16]]; // WORKS
			}
		clearedIndex = YES;
	}
	
	// Recover section and row info
	NSInteger row = [indexPath row];
	NSInteger section = [indexPath section];
	
	// Pull the cell
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"any-cell"];
	
	// If there's a new cell needed, add a custom label
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleGray;
		
		// Tag the background view
		[[[cell subviews] objectAtIndex:0] setTag:111];
		
		// Add and tag the label view
		UILabel *labelView = [[UILabel alloc] initWithFrame: CGRectMake(0, 0, 300, 44)];
		[labelView setBackgroundColor:[UIColor clearColor]];
		[labelView setShadowColor:[UIColor whiteColor]];
		[labelView setFont:[UIFont boldSystemFontOfSize:20]];
		[labelView setTag:222];
		[cell addSubview:labelView];
		[labelView release];
	}
	
	// Set up the cell
	NSArray *crayon = [[[sectionArray objectAtIndex:section] objectAtIndex:row] componentsSeparatedByString:@"#"];

	// recover labelView from the cell
	UILabel *labelView = (UILabel *)[cell viewWithTag:222];
	[labelView setText:[crayon objectAtIndex:0]];
	
	// recover the background
	UIView *bgView = [cell viewWithTag:111];
	[bgView setBackgroundColor:[self getColor:[crayon objectAtIndex:1]]];
	
	return cell;
}


// Remove the current table row selection
- (void) deselect
{	
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

// Respond to user selection by coloring the navigation bar
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	// Retrieve named color
	int row = [newIndexPath row];
	int section = [newIndexPath section];
	NSArray *crayon = [[[sectionArray objectAtIndex:section] objectAtIndex:row] componentsSeparatedByString:@"#"];
	
	// Update the nav bar color
	self.navigationController.navigationBar.tintColor = [self getColor:[crayon objectAtIndex:1]];
	
	// Deselect
	[self performSelector:@selector(deselect) withObject:NULL afterDelay:0.5];
}

// Build a section/row list from the alphabetically ordered word list
- (void) createSectionList: (id) wordArray
{
	// Build an array with 26 sub-array sections
	sectionArray = [[NSMutableArray alloc] init];
	for (int i = 0; i < 26; i++) [sectionArray addObject:[[NSMutableArray alloc] init]];
	
	// Add each word to its alphabetical section
	for (NSString *word in wordArray)
	{
		if ([word length] == 0) continue;
		
		// determine which letter starts the name
		NSRange range = [ALPHA rangeOfString:[[word substringToIndex:1] uppercaseString]];
		
		// Add the name to the proper array
		[[sectionArray objectAtIndex:range.location] addObject:word];
	}
}

// Prepare the Table View
- (void)loadView
{
	[super loadView];

	// Set up the black background
	[self.tableView setBackgroundColor:[UIColor whiteColor]];
	clearedIndex = NO;

	// Retrieve the text and colors from file
	NSString *pathname = [[NSBundle mainBundle]  pathForResource:@"crayons" ofType:@"txt" inDirectory:@"/"];
	NSString *wordstring = [NSString stringWithContentsOfFile:pathname];
    NSArray *wordArray = [wordstring componentsSeparatedByString:@"\n"];
	
	// Build the sorted section array
    [self createSectionList:wordArray];
}

// Clean up
-(void) dealloc
{
	[sectionArray release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
