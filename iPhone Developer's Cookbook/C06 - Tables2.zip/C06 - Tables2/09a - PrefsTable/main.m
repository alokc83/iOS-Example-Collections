#import <UIKit/UIKit.h>

@interface HelloController : UITableViewController <UITextFieldDelegate>
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super initWithStyle:UITableViewStyleGrouped]) self.title = @"Complex Table";
	return self;
}

// Number of groups
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 2;
}

// Section Titles
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	switch (section) 
	{
		case 0:
			return @"Civics";
		case 1:
			return @"Checked Items";
		default:
			return @"";
	}
}

// Number of rows per section
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	switch (section) 
	{
		case 0:
			return 2;
		case 1:
			return 4;
		default:
			return 0;
	}
}

// Heights per row
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	int section = [indexPath section];
	int row = [indexPath row];
	
	switch (section) 
	{
		case 0:
			if (row == 0) return 80.0f;
			return 350.0f;
		case 1:
			return 44.0f;
		default:
			return 44.0f;
	}
}

// Produce cells
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSInteger row = [indexPath row];
	NSInteger section = [indexPath section];
	UITableViewCell *cell;
	
	switch (section) 
	{
		case 0:
			if (row == 0) {
				// Add a text field to the cell
				cell = [tableView dequeueReusableCellWithIdentifier:@"textCell"];
				if (!cell) {
					cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"textCell"] autorelease];

					UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 10.0f, 100.0f, 20.0f)];
					[label setText:@"Name:"];
					[cell addSubview:label];
					[label release];

					[cell addSubview:[[UITextField alloc] initWithFrame:CGRectMake(20.0f, 40.0f, 280.0f, 30.0f)]];
				}
				UITextField *tf = [[cell subviews] lastObject];
				tf.placeholder = @"Enter Your Name Here";
				tf.delegate = self;
				tf.borderStyle = UITextBorderStyleBezel;
				return cell;
			}				
			if (row == 1) {
				// Create a big word-wrapped UILabel
				cell = [tableView dequeueReusableCellWithIdentifier:@"libertyCell"];
				if (!cell) {
					cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"libertyCell"] autorelease];
					[cell addSubview:[[UILabel alloc] initWithFrame:CGRectMake(20.0f, 10.0f, 280.0f, 330.0f)]];
				}
				UILabel *sv = [[cell subviews] lastObject];
				sv.text =  @"When in the Course of human events, it becomes necessary for one people to dissolve the political bands which have connected them with another, and to assume among the powers of the earth, the separate and equal station to which the Laws of Nature and of Nature's God entitle them, a decent respect to the opinions of mankind requires that they should declare the causes which impel them to the separation.";
				sv.textAlignment = UITextAlignmentCenter;
				sv.lineBreakMode = UILineBreakModeWordWrap;
				sv.numberOfLines = 9999;
				return cell;
			}
			break;
			case 1:
			// Create cells with accessory checking
			cell = [tableView dequeueReusableCellWithIdentifier:@"checkCell"];
			if (!cell) {
				cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"checkCell"] autorelease];
				cell.accessoryType = UITableViewCellAccessoryNone;
			}
			cell.text = [NSString stringWithFormat:@"This is option #%d", row + 1];
			return cell;
			break;
		default:
			break;
	}
	
	// Return a generic cell if all else fails
	cell = [tableView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
	}
	
	return cell;
}

// utility functions
- (void) deselect
{	
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

- (void) notify: (NSString *) aMessage
{
	UIAlertView *baseAlert = [[UIAlertView alloc] 
							  initWithTitle:@"Alert" message:aMessage 
							  delegate:self cancelButtonTitle:nil
							  otherButtonTitles:@"Okay", nil];
	[baseAlert show];
}

// TextField delegate handles return events and dismisses keyboard
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	[self notify:[NSString stringWithFormat:@"Hello %@", [textField text]]];
	return YES;
}

// Respond to user selection based on the cell type
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	
	int section = [newIndexPath section];
	int row = [newIndexPath row];
	UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:newIndexPath];

	switch (section) 
	{
		case 0:
			if (row == 0)
			{
				[self notify:[NSString stringWithFormat:@"Hello %@", [[[cell subviews] lastObject] text]]];
			}
			case 1:
			if (cell.accessoryType == UITableViewCellAccessoryNone)
				cell.accessoryType = UITableViewCellAccessoryCheckmark;
			else
				cell.accessoryType = UITableViewCellAccessoryNone;
			break;
			break;
		default:
			break;
	}

	[self performSelector:@selector(deselect) withObject:NULL afterDelay:0.5];
}

@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
