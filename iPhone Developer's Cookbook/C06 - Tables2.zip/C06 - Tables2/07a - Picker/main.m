#import <UIKit/UIKit.h>

@interface UIPickerView (sounds)
- (void)setSoundsEnabled:(BOOL)yorn;
@end

@interface HelloController : UIViewController <UIPickerViewDelegate>
{
	UIPickerView *pickerView;
	UILabel *comboView;
}
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Combo Picker";
	return self;
}

// Number of wheels
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView { return 3; }

// Number of rows per wheel
- (NSInteger)pickerView: (UIPickerView *)pView numberOfRowsInComponent: (NSInteger) component  { return 30; }

// Return the title of each cell by row and component
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [NSString stringWithFormat:@"%@%d", (component != 1) ? @"Left " : @"Right ", row];
}


// Respond to user selection
- (void)pickerView:(UIPickerView *)aPickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	printf("User selected row %d for component %d\n", row, component);

	int first = [pickerView selectedRowInComponent:0];
	int second = [pickerView selectedRowInComponent:1];
	int third = [pickerView selectedRowInComponent:2];
	
	NSString *results = [NSString stringWithFormat:@"Left-%@%d  Right-%@%d  Left-%@%d",
						 (first  < 10) ? @"0" : @"",
						 first,
						 (second < 10) ? @"0" : @"",
						 second,
						 (third  < 10) ? @"0" : @"",
						 third];
	[comboView setText:results];
						 
}

// Allow the view to respond to iPhone Orientation changes
-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	self.view.backgroundColor = [UIColor lightGrayColor];
	[contentView release];

	// Add the picker
	float height = 216.0f;
	pickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, 416.0f - height, 320.0f, height)];
	pickerView.delegate = self;
	pickerView.showsSelectionIndicator = YES;
	// [pickerView setSoundsEnabled:NO];
	[self.view addSubview:pickerView];
	[pickerView release];
	
	// Add a results label
	comboView = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 170.0f, 320.0f, 32.0f)];
	[comboView setBackgroundColor:[UIColor clearColor]];
	[comboView setTextAlignment:UITextAlignmentCenter];
	[comboView setText:@"Left-00  Right-00  Left-00"];
	[self.view addSubview:comboView];
	[comboView release];
	
	// Manage re-sizing and rotation
	self.view.autoresizesSubviews = YES;
	self.view.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
}

-(void) dealloc
{
	[pickerView release];
	[comboView release];
	[super dealloc];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
