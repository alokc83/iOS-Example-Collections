#import <UIKit/UIKit.h>

@interface HelloController : UITableViewController 
{
	NSArray *sectionArray;
}
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super initWithStyle:UITableViewStylePlain]) self.title = @"Crayon Colors";
	return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

// Each row array object contains the members for that section
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [sectionArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	NSInteger row = [indexPath row];
	
	// Pull the cell
	UITableViewCell *cell = [tView dequeueReusableCellWithIdentifier:@"any-cell"];
	UILabel *labelView = NULL;
	
	// If there's a new cell needed, add a custom label
	if (cell == nil) {
		cell = [[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"];
		[[[cell subviews] objectAtIndex:0] setTag:111];
		cell.selectionStyle = UITableViewCellSelectionStyleGray;
		
		labelView = [[UILabel alloc] initWithFrame: CGRectMake(8, 0, 300, 44)];
		[labelView setBackgroundColor:[UIColor clearColor]];
		[labelView setFont:[UIFont boldSystemFontOfSize:20]];
		[cell addSubview:labelView];
		[labelView setTag:222];
		[labelView release];
	}
	
	UIView *cellView = [cell viewWithTag:111];
	if (row % 2) {
		[cellView setBackgroundColor:[UIColor whiteColor]]; 
	}
	else  {
		[cellView setBackgroundColor:[UIColor colorWithRed:0.90f green:0.95f blue:1.0f alpha:1.0f]];
	}
	
	// recover labelView from the cell
	[(UILabel *)[cell viewWithTag:222] setText:[[[sectionArray objectAtIndex:row] componentsSeparatedByString:@"#"] objectAtIndex:0]];
	
	return cell;
}

// Remove the current table row selection
- (void) deselect
{	
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

// Respond to user selection by coloring the navigation bar
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	// Deselect
	[self performSelector:@selector(deselect) withObject:NULL afterDelay:0.5];
}

// Prepare the Table View
- (void)loadView
{
	[super loadView];
	
	// Retrieve the text and colors from file. Forgive me Alex for I must retain else it dies
	NSString *pathname = [[NSBundle mainBundle]  pathForResource:@"crayons" ofType:@"txt" inDirectory:@"/"];
    sectionArray = [[[NSString stringWithContentsOfFile:pathname] componentsSeparatedByString:@"\n"] retain];
}

// Clean up
-(void) dealloc
{
	[sectionArray release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
