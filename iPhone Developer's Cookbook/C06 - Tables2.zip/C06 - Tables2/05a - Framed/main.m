#import <UIKit/UIKit.h>

@interface HelloController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
	NSArray *sectionArray;
	UITableView *tableView;
}
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Crayon Colors";
	return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [sectionArray count];
}

// Return a cell for the ith row
- (UITableViewCell *)tableView:(UITableView *)tView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSInteger row = [indexPath row];
	UITableViewCell *cell = [tView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (cell == nil) cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
	
	// Set up the cell
	cell.selectionStyle = UITableViewCellSelectionStyleGray;
	cell.indentationLevel = 1;
	NSArray *crayon = [[sectionArray objectAtIndex:row] componentsSeparatedByString:@"#"];
	cell.text = [crayon objectAtIndex:0];

	return cell;
}

- (void) deselect
{	
	[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	// Deselect
	[self performSelector:@selector(deselect) withObject:NULL afterDelay:0.5];
}

- (void)loadView
{
	// Add a background
	UIImageView *bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BG.png"]];
	bg.userInteractionEnabled = YES;
	self.view = bg;
	[bg release];

	CGRect frame = CGRectMake(10.0f, 20.0f, 300.0f, 440.0f);
	tableView = [[UITableView alloc] initWithFrame:frame style: UITableViewStylePlain];
	[tableView setDelegate:self];
	[tableView setDataSource:self];
	[bg addSubview:tableView];
	[tableView release];
	
	// Retrieve the text and colors from file. Forgive me Alex, as I forgive Objective C for making me retain
	NSString *pathname = [[NSBundle mainBundle]  pathForResource:@"crayons" ofType:@"txt" inDirectory:@"/"];
	sectionArray = [[[NSString stringWithContentsOfFile:pathname] componentsSeparatedByString:@"\n"] retain];

	UIImageView *fg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cutbg.png"]];
	fg.userInteractionEnabled = NO;
	[bg addSubview:fg];
	[fg release];
}

-(void) dealloc
{
	[tableView release];
	[sectionArray release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
