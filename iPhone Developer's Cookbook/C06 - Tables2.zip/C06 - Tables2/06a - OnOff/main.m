#import <UIKit/UIKit.h>

@interface HelloController : UITableViewController 
{
	NSMutableArray *sectionArray;
	NSMutableDictionary *boolDict;
}
@end

@implementation HelloController
#define ALPHA @"ABCDEFGHIJKLMNOPQRSTUVWXYZ"

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Crayon Colors";
	return self;
}

#pragma mark UITableViewDataSource Methods

// One section for each alphabet member
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 26;
}

// Each row array object contains the members for that section
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [[sectionArray objectAtIndex:section] count];
}

#define ALPHA_ARRAY [NSArray arrayWithObjects: @"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K", @"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S", @"T", @"U", @"V", @"W", @"X", @"Y", @"Z", nil]
// Adding a section index here
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
	return ALPHA_ARRAY;
}

- (UIColor *) getColor: (NSString *) hexColor
{
	unsigned int red, green, blue;
	NSRange range;
	range.length = 2;
	
	range.location = 0; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&red];
	range.location = 2; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&green];
	range.location = 4; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&blue];	
	
	return [UIColor colorWithRed:(float)(red/255.0f) green:(float)(green/255.0f) blue:(float)(blue/255.0f) alpha:1.0f];
}

- (void) switchEm: (UIControl *) sender
{
	UITableViewCell *cell = (UITableViewCell *)[sender superview];
	NSString *whichCell = [cell text];
	NSNumber *value = [boolDict objectForKey:whichCell];
	if (!value) // no value assigned, false
	{
		[boolDict setObject:[NSNumber numberWithBool:YES] forKey:whichCell]; // initialize
	} else {
		value = [NSNumber numberWithBool:(![value boolValue])]; // toggle
		[boolDict setObject:value forKey:whichCell];
	}
}

// Return a cell on demand
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	// Recover section and row info
	NSInteger row = [indexPath row];
	NSInteger section = [indexPath section];
	
	// Pull the cell
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"any-cell"];
	UISwitch *switchView = NULL;

	// If there's a new cell needed, add a custom switch
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleGray;
		cell.indentationLevel = 5;
		
		switchView = [[UISwitch alloc] initWithFrame: CGRectMake(4.0f, 16.0f, 100.0f, 28.0f)];
		[switchView setTag:997];
		[cell addSubview:switchView];
		[switchView release];
	}

	// recover switchView from the cell
	switchView = [cell viewWithTag:997];
	[switchView addTarget:self action:@selector(switchEm:) forControlEvents:UIControlEventValueChanged];

	// Set up the cell
	NSArray *crayon = [[[sectionArray objectAtIndex:section] objectAtIndex:row] componentsSeparatedByString:@"#"];
	[cell setText:[crayon objectAtIndex:0]];
	
	NSNumber *value = [boolDict objectForKey:[crayon objectAtIndex:0]];
	if (!value) value = [NSNumber numberWithBool:NO];
	[switchView setOn:[value boolValue] animated:NO];
	
	return cell;
}

#pragma mark UITableViewDelegateMethods
// utility
- (void) deselect
{	
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

// Respond to user selection
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	// Retrieve named color
	int row = [newIndexPath row];
	int section = [newIndexPath section];
	NSArray *crayon = [[[sectionArray objectAtIndex:section] objectAtIndex:row] componentsSeparatedByString:@"#"];
	
	// Update the nav bar color
	self.navigationController.navigationBar.tintColor = [self getColor:[crayon objectAtIndex:1]];
	
	// Deselect
	[self performSelector:@selector(deselect) withObject:NULL afterDelay:0.5];
}

- (void) createSectionArray: (id) fileArray
{
	// Build an array with 26 sub-arrays
	sectionArray = [[[NSMutableArray alloc] init] retain];
	for (int i = 0; i < 26; i++) [sectionArray addObject:[[[NSMutableArray alloc] init] retain]];
	
	for (NSString *line in fileArray)
	{
		if ([line length] == 0) continue;
		
		// determine which letter starts the name
		NSRange range = [ALPHA rangeOfString:[[line substringToIndex:1] uppercaseString]];
		
		// Add the name to the proper array
		[[sectionArray objectAtIndex:range.location] addObject:line];
	}
}


- (void)loadView
{
	[super loadView];
	self.tableView.rowHeight = 60;
	
	// Retrieve the text and colors from file
	NSString *pathname = [[NSBundle mainBundle]  pathForResource:@"crayons" ofType:@"txt" inDirectory:@"/"];
	NSString *wordstring = [NSString stringWithContentsOfFile:pathname];
    NSArray *wordArray = [[wordstring componentsSeparatedByString:@"\n"] retain];
	
	// Build the sorted section array
    [self createSectionArray:wordArray];
	
	// Initialize the boolean dictionary
	boolDict = [[NSMutableDictionary alloc] init];
}

-(void) dealloc
{
	[sectionArray release];
	[super dealloc];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
