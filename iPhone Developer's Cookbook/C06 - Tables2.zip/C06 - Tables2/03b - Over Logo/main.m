#import <UIKit/UIKit.h>

@interface HelloController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
	NSMutableArray *sectionArray;
	UITableView *tableView;
	BOOL clearedIndex;
}
@end

@implementation HelloController
#define ALPHA @"ABCDEFGHIJKLMNOPQRSTUVWXYZ"

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Crayon Colors";
	return self;
}

// One section for each alphabet member
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return [sectionArray count];
}

// Each row array object contains the members for that section
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [[sectionArray objectAtIndex:section] count];
}

#define ALPHA_ARRAY [NSArray arrayWithObjects: @"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K", @"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S", @"T", @"U", @"V", @"W", @"X", @"Y", @"Z", nil]

// Adding a section index here
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
	return ALPHA_ARRAY;
}

- (UIColor *) getColor: (NSString *) hexColor
{
	unsigned int red, green, blue;
	NSRange range;
	range.length = 2;
	
	range.location = 0; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&red];
	range.location = 2; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&green];
	range.location = 4; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&blue];	
	
	return [UIColor colorWithRed:(float)(red/255.0f) green:(float)(green/255.0f) blue:(float)(blue/255.0f) alpha:1.0f];
}

- (UIColor *) getDiffuseColor: (NSString *) hexColor
{
	unsigned int red, green, blue;
	NSRange range;
	range.length = 2;
	
	range.location = 0; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&red];
	range.location = 2; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&green];
	range.location = 4; 
	[[NSScanner scannerWithString:[hexColor substringWithRange:range]] scanHexInt:&blue];	
	
	return [UIColor colorWithRed:(float)(red/255.0f) green:(float)(green/255.0f) blue:(float)(blue/255.0f) alpha:0.35f];
}


// Return a cell on demand
- (UITableViewCell *)tableView:(UITableView *)tView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	// if the Index background has not yet been cleared, clear it
	if (!clearedIndex) {
		for (UIView *view in [tableView subviews])
			if ([[[view class] description] isEqualToString:@"UITableViewIndex"]) {
				[view setBackgroundColor:[UIColor clearColor]];
				// [view setFont:[UIFont boldSystemFontOfSize:16]]; // WORKS
			}
		clearedIndex = YES;
	}
	
	// Recover section and row info
	NSInteger row = [indexPath row];
	NSInteger section = [indexPath section];
	
	// Pull the cell
	UITableViewCell *cell = [tView dequeueReusableCellWithIdentifier:@"any-cell"];
	UILabel *labelView = NULL;
	
	// If there's a new cell needed, add a custom label
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleGray;
		[[[cell subviews] objectAtIndex:0] setBackgroundColor:[UIColor clearColor]];
		
		labelView = [[UILabel alloc] initWithFrame: CGRectMake(0, 0, 300, 44)];
		[labelView setBackgroundColor:[UIColor clearColor]];
		[labelView setFont:[UIFont boldSystemFontOfSize:20]];
		[cell addSubview:labelView];
		[labelView release];
	}
	
	// recover labelView from the cell
	for (UIView *subview in [cell subviews]) 
		if ([[[subview class] description] isEqualToString:@"UILabel"]) labelView = (UILabel *)subview;
	if (!labelView) printf("Error: Could not find the custom label!\n");
	
	// Set up the cell
	NSArray *crayon = [[[sectionArray objectAtIndex:section] objectAtIndex:row] componentsSeparatedByString:@"#"];
	[labelView setTextColor:[self getColor:[crayon objectAtIndex:1]]];
	[labelView setText:[crayon objectAtIndex:0]];
	
	return cell;
}

#pragma mark UITableViewDelegateMethods
// utility
- (void) deselect
{	
	[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}

// Respond to user selection
- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	// Retrieve named color
	int row = [newIndexPath row];
	int section = [newIndexPath section];
	NSArray *crayon = [[[sectionArray objectAtIndex:section] objectAtIndex:row] componentsSeparatedByString:@"#"];
	NSString *color = [crayon objectAtIndex:1];
	
	// Update the nav bar color and tint the table background
	self.navigationController.navigationBar.tintColor = [self getColor:color];
	[tableView setBackgroundColor:[self getDiffuseColor:color]];
	[tableView reloadData];
	
	// Deselect
	[self performSelector:@selector(deselect) withObject:NULL afterDelay:0.5];
}

- (void) createSectionList: (id) wordArray
{
	// Build an array with 26 sub-arrays
	sectionArray = [[NSMutableArray alloc] init];
	for (int i = 0; i < 26; i++) [sectionArray addObject:[[NSMutableArray alloc] init]];
	
	for (NSString *word in wordArray)
	{
		if ([word length] == 0) continue;
		
		// determine which letter starts the name
		NSRange range = [ALPHA rangeOfString:[[word substringToIndex:1] uppercaseString]];
		
		// Add the name to the proper array
		[[sectionArray objectAtIndex:range.location] addObject:word];
	}
}


- (void)loadView
{
	// Add a background
	CGRect frame = [[UIScreen mainScreen] applicationFrame];
	self.view = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg.png"]] autorelease];
	self.view.userInteractionEnabled = YES;
	[self.view setFrame:frame];

	// Set up the table -- allowing for some customizations
	frame = CGRectMake(30.0f, 40.0f, 260.0f, 300.0f);
	tableView = [[UITableView alloc] initWithFrame:frame style: UITableViewStylePlain];
	[tableView setDelegate:self];
	[tableView setDataSource:self];
	[tableView setBackgroundColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.35f]];
	[self.view addSubview:tableView];
	[tableView release];
		
	// Retrieve the text and colors from file
	NSString *pathname = [[NSBundle mainBundle]  pathForResource:@"crayons" ofType:@"txt" inDirectory:@"/"];
	NSString *wordstring = [NSString stringWithContentsOfFile:pathname];
    NSArray *wordArray = [wordstring componentsSeparatedByString:@"\n"];
	
	// Build the sorted section array
    [self createSectionList:wordArray];
	
	clearedIndex = NO;
}

-(void) dealloc
{
	[tableView release];
	[sectionArray release];
	[super dealloc];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
