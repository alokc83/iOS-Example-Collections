#import <UIKit/UIKit.h>

@interface HelloController : UITableViewController 
{
	NSMutableArray *sectionArray;
	int fullCount;
}
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super initWithStyle:UITableViewStylePlain]) self.title = @"Number Names";
	return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return [sectionArray count];
}

// Each row array object contains the members for that section
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [[sectionArray objectAtIndex:section] count];
}

#define TITLE_ARRAY [NSArray arrayWithObjects: @"Ones", @"Twos", @"Threes", @"Fours", @"Fives", @"Sixes", @"Sevens", @"Eights", @"Nines", @"Other",  nil]

// This recipe adds a title for each section
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	return [TITLE_ARRAY objectAtIndex:section];
}

// Adding a section index here
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
	return TITLE_ARRAY;
}

// Return a cell for the ith row
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSInteger row = [indexPath row];
	NSInteger section = [indexPath section];
	
	// Create a cell if one is not already available
	UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (cell == nil) 
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
	
	cell.text = [[sectionArray objectAtIndex:section] objectAtIndex:row];
	return cell;
}

// Remove the current table row selection
- (void) deselect
{	
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	// Deselect
	[self performSelector:@selector(deselect) withObject:NULL afterDelay:0.5];
}

// Divide each line into section items
- (void) createSectionList: (id) dataArray
{
	sectionArray = [[NSMutableArray alloc] init];
	for (NSString *line in dataArray)
		[sectionArray addObject:[line componentsSeparatedByString:@" "]];
}

// Prepare the Table View
- (void)loadView
{
	[super loadView];
	
	// Retrieve the text and colors from file
	NSString *pathname = [[NSBundle mainBundle]  pathForResource:@"numbers" ofType:@"txt" inDirectory:@"/"];
	NSString *wordstring = [NSString stringWithContentsOfFile:pathname];
    NSArray *wordArray = [wordstring componentsSeparatedByString:@"\n"];
	
	// Build the sorted section array
    [self createSectionList:wordArray];
}

// Clean up
-(void) dealloc
{
	[sectionArray release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
