#import <UIKit/UIKit.h>
#import <math.h>

// MyCreateBitmapContext: Source based on Apple Sample Code
CGContextRef MyCreateBitmapContext (int pixelsWide,
									int pixelsHigh)
{
    CGContextRef    context = NULL;
    CGColorSpaceRef colorSpace;
    void *          bitmapData;
    int             bitmapByteCount;
    int             bitmapBytesPerRow;
	
    bitmapBytesPerRow   = (pixelsWide * 4);
    bitmapByteCount     = (bitmapBytesPerRow * pixelsHigh);
	
    colorSpace = CGColorSpaceCreateDeviceRGB();
    bitmapData = malloc( bitmapByteCount );
    if (bitmapData == NULL)
    {
        fprintf (stderr, "Memory not allocated!");
        return NULL;
    }
    context = CGBitmapContextCreate (bitmapData,
									 pixelsWide,
									 pixelsHigh,
									 8,
									 bitmapBytesPerRow,
									 colorSpace,
									 kCGImageAlphaPremultipliedLast);
    if (context== NULL)
    {
        free (bitmapData);
        fprintf (stderr, "Context not created!");
        return NULL;
    }
    CGColorSpaceRelease( colorSpace );
	
    return context;
}

// Build a thumb image based on the grayscale percentage
id createImage(float percentage)
{
	CGRect aRect = CGRectMake(0.0f, 0.0f, 48.0f, 48.0f);
	CGContextRef context = MyCreateBitmapContext(48, 48);
	CGContextClearRect(context, aRect);
	
	// Outer gray circle
	CGContextSetFillColorWithColor(context, [[UIColor lightGrayColor] CGColor]);
	CGContextFillEllipseInRect(context, aRect);
	
	// Inner circle with feedback levels
	CGContextSetFillColorWithColor(context, [[UIColor colorWithRed:percentage green:0.0f blue:0.0f alpha:1.0f] CGColor]);
	CGContextFillEllipseInRect(context, CGRectInset(aRect, 4.0f, 4.0f));

	// Inner gray circle
	CGContextSetFillColorWithColor(context, [[UIColor lightGrayColor] CGColor]);
	CGContextFillEllipseInRect(context, CGRectInset(aRect, 16.0f, 16.0f));
	
	CGImageRef myRef = CGBitmapContextCreateImage (context);
	free(CGBitmapContextGetData(context));
	CGContextRelease(context);
	
	return [UIImage imageWithCGImage:myRef];
}


@interface HelloController : UIViewController
{
	UIImageView *contentView;
	UILabel *valueLabel;
	UIImage *knob;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Slider";
	return self;
}

- (void) updateValue: (UISlider *) slider
{
	[valueLabel setText:[NSString stringWithFormat:@"%3.1f", [slider value]]];
	
	CGImageRef oldknobref = [knob CGImage];
	knob = createImage([slider value] / 100.0f);
	[slider setThumbImage:knob forState:UIControlStateNormal];
	[slider setThumbImage:knob forState:UIControlStateHighlighted];
	CFRelease(oldknobref);
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	[contentView setUserInteractionEnabled:YES]; // Must allow for subviews to interact!
	self.view = contentView;
	
	// Add a text label to show the current slider scale
	valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(50.0f, 100.0f, 220.0f, 40.0f)];
	valueLabel.textAlignment = UITextAlignmentCenter;
	valueLabel.text = @"50.0";
	valueLabel.backgroundColor = [UIColor clearColor];
	[contentView addSubview:valueLabel];
	
	// Build the slider
	UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake(50.0f, 160.0f, 220.0f, 40.0f)];
	slider.backgroundColor = [UIColor clearColor];
	slider.minimumValue = 0.0f;
	slider.maximumValue = 100.0f;
	slider.continuous = YES;
	slider.value = 50.0f;
	
	// Add the custom knob
	knob = createImage(0.5);
	[slider setThumbImage:knob forState:UIControlStateNormal];
	[slider setThumbImage:knob forState:UIControlStateHighlighted];
	
	[slider addTarget:self action:@selector(updateValue:) forControlEvents:UIControlEventValueChanged];
	[contentView addSubview: slider];
	[slider release];
}

-(void) dealloc
{
	[valueLabel release];
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
