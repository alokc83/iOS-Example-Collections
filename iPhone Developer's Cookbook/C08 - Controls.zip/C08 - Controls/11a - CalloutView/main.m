#import <UIKit/UIKit.h>

@class UIImageView, UILabel, UIPushButton;
@interface UICalloutView : UIControl
- (UICalloutView *)initWithFrame:(struct CGRect)aFrame;
- (void)fadeOutWithDuration:(float)duration;
- (void)setTemporaryTitle:(NSString *)fp8;
- (NSString *)temporaryTitle;
- (void)setTitle:(NSString *)fp8;
- (NSString *)title;
- (void)setSubtitle:(NSString *)fp8;
- (NSString *)subtitle;
- (void)addTarget:(id)target action:(SEL)selector;
- (void)removeTarget:(id)target;
- (void)setDelegate:(id)delegate;
- (id)delegate;
- (void)setAnchorPoint:(struct CGPoint)aPoint boundaryRect:(struct CGRect)aRect animate:(BOOL)yorn;
@end


@interface TapView : UIImageView
@end

@implementation TapView
- (void) hideDisclosure: (UIPushButton *) calloutButton
{
	UICalloutView *callout = (UICalloutView *)[calloutButton superview];
	[callout fadeOutWithDuration:1.0f];
}

- (UICalloutView *) buildDisclosure
{
	UICalloutView *callout = [[[UICalloutView alloc] initWithFrame:CGRectZero] autorelease];
	callout.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	callout.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
	
	// You can easily customize the information and the target
	[callout setTemporaryTitle:@"You Tapped Here!"];
	[callout setTitle:@"More Info..."];
	[callout addTarget:self action:@selector(hideDisclosure:)];
	
	// Optional delegate methods are:
	// calloutView:willMoveToAnchorPoint:animated:
	// calloutView:didMoveToAnchorPoint:animated:
	// [callout setDelegate:self]; 
	
	return callout;
}

- (void) showDisclosureAt:(CGPoint) aPoint
{
	UICalloutView *callout = [self buildDisclosure];
	[self addSubview:callout];
	[callout setAnchorPoint:aPoint boundaryRect:CGRectMake(0.0f, 0.0f, 320.0f, 100.0f) animate:YES];
}

- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
	[self showDisclosureAt:[[touches anyObject] locationInView:self]];
}

@end


@interface HelloController : UIViewController
{
	TapView *contentView;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Callout Views";
	return self;
}

- (void)loadView
{
	contentView = [[TapView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	contentView.userInteractionEnabled = YES;
	self.view = contentView;
	[contentView release];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
