#import <UIKit/UIKit.h>
#include "time.h"

//
// Switch customization
//

@interface UISwitch (extended)
- (void) setAlternateColors:(BOOL) boolean;
@end

@interface _UISwitchSlider : UIView
@end

@interface UICustomSwitch : UISwitch
- (void) setLeftLabelText: (NSString *) labelText;
- (void) setRightLabelText: (NSString *) labelText;
@end

@implementation UICustomSwitch
- (_UISwitchSlider *) slider { 
	return [[self subviews] lastObject]; 
}
- (UIView *) textHolder { 
	return [[[self slider] subviews] objectAtIndex:2]; 
}
- (UILabel *) leftLabel { 
	return [[[self textHolder] subviews] objectAtIndex:0]; 
}
- (UILabel *) rightLabel { 
	return [[[self textHolder] subviews] objectAtIndex:1]; 
}
- (void) setLeftLabelText: (NSString *) labelText { 
	[[self leftLabel] setText:labelText]; 
}
- (void) setRightLabelText: (NSString *) labelText { 
	[[self rightLabel] setText:labelText]; 
}
@end


@interface HelloController : UIViewController
{
	UIView *contentView;
}
@end

@implementation HelloController
- (id)init
{
	if (self = [super init])
	{
		self.title = @"Switch Customizer";
	}
	return self;
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]] autorelease];
	contentView.backgroundColor = [UIColor whiteColor];
	
	// Standard switch
	UICustomSwitch *switchView = [[UICustomSwitch alloc] initWithFrame:CGRectZero];
	[switchView setCenter:CGPointMake(160.0f,170.0f)];
	[contentView addSubview:switchView];
	[switchView release];
	
	// Demonstrate alternte colors
	switchView = [[UICustomSwitch alloc] initWithFrame:CGRectZero];
	[switchView setCenter:CGPointMake(160.0f,200.0f)];
	[switchView setAlternateColors:YES]; // built in, undocumented
	[contentView addSubview:switchView];
	[switchView release];
	
	// Yes-No Custom Text
	switchView = [[UICustomSwitch alloc] initWithFrame:CGRectZero];
	[switchView setCenter:CGPointMake(160.0f,230.0f)];
	[switchView setLeftLabelText: @"YES"];
	[switchView setRightLabelText: @"NO"];
	[contentView addSubview:switchView];
	[switchView release];
	
	// Custom font, color
	switchView = [[UICustomSwitch alloc] initWithFrame:CGRectZero];
	[switchView setCenter:CGPointMake(160.0f,260.0f)];
	[switchView setLeftLabelText: @"Foo"];
	[switchView setRightLabelText: @"Bar"];
	[[switchView rightLabel] setFont:[UIFont fontWithName:@"Georgia" size:16.0f]];
	[[switchView leftLabel] setFont:[UIFont fontWithName:@"Georgia" size:16.0f]];
	[[switchView leftLabel] setTextColor:[UIColor yellowColor]]; 
	[contentView addSubview:switchView];
	[switchView release];	
	
	self.view = contentView;
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
