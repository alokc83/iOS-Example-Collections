#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

@interface UITextView (extended)
- (void)setContentToHTMLString:(NSString *) contentText;
@end

@interface HelloController : UIViewController <UITextViewDelegate>
{
	UITextView *contentView;
	BOOL readyToUndo;
}
@end

@implementation HelloController

#define FILEPATH [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/MyText.txt"]

- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Undo Button";
	return self;
}

// Reveal a done button when starting to edit
- (void) textViewDidBeginEditing: (UITextView *) textView
{
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Done" 
											  style:UIBarButtonItemStyleDone
											  target:self 
											  action:@selector(doneEditing:)] autorelease];

	readyToUndo = YES;
}

// Only reveal the undo after text has actually been typed or deleted
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
	if (readyToUndo)
		self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc]
												 initWithTitle:@"Undo" 
												 style:UIBarButtonItemStylePlain
												 target:self 
												 action:@selector(undoEditing:)] autorelease];
	readyToUndo = NO;
	return YES;
}

// The done button forces the text view to resign its first responder status and saves changes
- (void) doneEditing: (id) sender
{
	NSError *error;
	
	[contentView resignFirstResponder];
	self.navigationItem.rightBarButtonItem = NULL;
	self.navigationItem.leftBarButtonItem = NULL;
	[[contentView text] writeToFile:FILEPATH atomically: YES encoding:NSUTF8StringEncoding error: &error];
}

// Undo means revert to last saved state
- (void) undoEditing: (id) sender
{
	if ([[NSFileManager defaultManager] fileExistsAtPath:FILEPATH])
		[contentView setText:[NSString stringWithContentsOfFile:FILEPATH]];
	else
		[contentView setText:@""];
	
	readyToUndo = YES;
	self.navigationItem.leftBarButtonItem = NULL;
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setDelegate:self];
	self.view = contentView;
	[contentView release];
	
	// Preload with text if any has been saved
	if ([[NSFileManager defaultManager] fileExistsAtPath:FILEPATH])
		[contentView setText:[NSString stringWithContentsOfFile:FILEPATH]];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
