#import <UIKit/UIKit.h>

@interface HelloController : UIViewController
{
	NSMutableArray *items;
}
@end

@implementation HelloController

/*
 UISwitch:UIControl
 --_UISwitchSlider:UISlider
 ----UIImageView:UIView
 ----UIImageView:UIView
 ----UIView:UIResponder
 ------UILabel:UIView
 ------UILabel:UIView
 ----UIImageView:UIView
*/ 

#define outstring(anObject) [[anObject description] UTF8String]

- (void) explode: (id) aView level: (int) aLevel
{
	for (int i = 0;  i < aLevel; i++) printf("--", aLevel);
	printf("%s:%s\n", outstring([aView class]), outstring([aView superclass]));
	for (UIView *subview in [aView subviews])
		[self explode:subview level:(aLevel + 1)];
}

- (void)loadView
{
	[super loadView];
	UISwitch *mySwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
	[self explode:mySwitch level:0];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
