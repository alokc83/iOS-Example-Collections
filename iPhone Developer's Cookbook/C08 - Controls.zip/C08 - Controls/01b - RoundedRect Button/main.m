#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

@interface HelloController : UIViewController
{
	UIImageView *contentView;
	SystemSoundID beep;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Button";
	return self;
}

- (void) playSound: (id) sender
{
	AudioServicesPlaySystemSound (beep);
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	[contentView setUserInteractionEnabled:YES]; // Must allow for subviews to interact!
	self.view = contentView;
	[contentView release];
	
	// Load the sound
    id sndpath = [[NSBundle mainBundle] pathForResource:@"beep" ofType:@"wav"];
	CFURLRef baseURL = (CFURLRef)[[NSURL alloc] initFileURLWithPath:sndpath];
	AudioServicesCreateSystemSoundID (baseURL, &beep);
	
	UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[button setFrame:CGRectMake(0.0f, 0.0f, 80.0f, 30.0f)];
	[button setCenter:CGPointMake(160.0f, 208.0f)];
	[button setTitle:@"Beep" forState:UIControlStateNormal];
	[button addTarget:self action:@selector(playSound:) forControlEvents:UIControlEventTouchUpInside];
	
	[contentView addSubview:button];
}

-(void) dealloc
{
	if (beep) AudioServicesDisposeSystemSoundID(beep);
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
