#import <UIKit/UIKit.h>


@interface UIView (extended)
- (void) setOrigin: (CGPoint) anOrigin;
@end

@interface SplodeView : NSObject
{
	UIView		*mainView;
	int			nestingLevel;
}
@property (nonatomic, retain) UIView *mainView;
@property int nestingLevel;
@end

@implementation SplodeView
@synthesize mainView;
@synthesize nestingLevel;
@end

/* @implementation UIControl (extended)

+ (BOOL)instancesRespondToSelector:(SEL)aSelector {
	printf("SELECTOR %s: %s\n", [[[self class] description] UTF8String], [NSStringFromSelector(aSelector) UTF8String]);
	return [super respondsToSelector:aSelector];
}

-(BOOL) respondsToSelector:(SEL)aSelector {
	printf("SELECTOR %s: %s\n", [[[self class] description] UTF8String], [NSStringFromSelector(aSelector) UTF8String]);
	return [super respondsToSelector:aSelector];
}
@end */


@interface HelloController : UITableViewController
{
	NSMutableArray *items;
}
@end

@implementation HelloController
- (void) peekAt: (id) anObject
{
	printf("Peeking at %s:", [[[anObject class] description] UTF8String]);
	printf("%s", [[[anObject superclass] description] UTF8String]);
	printf("(%d)\n", [anObject retainCount]);
}
- (id)init
{
	if (self = [super init])
	{
		self.title = @"XRay";
	}
	return self;
}

// Only one section in this table
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

// Return how many rows in the table
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [items count];
}

// Return a cell for the ith row
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	int row = [indexPath row];
	SplodeView *splode = [items objectAtIndex:row];
	UIView *view = [splode mainView];
	NSString *kind = [[view class] description];
	
	UITableViewCell *cell;
	
	if (row == 0)
	{
		cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"firstCell"];
		if (!cell) {
			cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"firstCell"] autorelease];
			[cell addSubview:[splode mainView]]; 
			[[splode mainView] setOrigin:CGPointMake(200.0f, 40.0f)];
			[cell addSubview:[[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 20.0f)]];
		}
	} else // not first row
	{
		cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"any-cell"];
		if (!cell) {
			cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];		
			[cell addSubview:[[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 20.0f)]];
	
		}
	}
	
	// Set up the cell
	UILabel *label = [[cell subviews] lastObject];

	NSMutableString *outString = [[NSMutableString alloc] init];
	[outString appendString:NSStringFromCGRect([view frame])];
	[outString appendString:@" "];

	cell.text = kind;
	if ([kind hasPrefix:@"UILabel"]) [outString appendString:[(UILabel *)view text]];
	if ([kind hasPrefix:@"UIImageView"]) cell.image = [(UIImageView *)[splode mainView] image];
	
	cell.indentationLevel = splode.nestingLevel * 2;
	[label setText: outString];
	return cell;
}

#define outstring(anObject) [[anObject description] UTF8String]

- (void) explode: (id) aView level: (int) aLevel
{
	SplodeView *splode = [[SplodeView alloc] init];
	splode.mainView = aView;
	splode.nestingLevel = aLevel;
	[items addObject:splode];
	[self peekAt:aView];
	
	for (UIView *subview in [aView subviews])
		[self explode:subview level:(aLevel + 1)];
}

- (void)loadView
{
	[super loadView];
	self.tableView.rowHeight = 100;
	
	items = [[NSMutableArray alloc] init]; 
	
	UISwitch *mySwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
	[self explode:mySwitch level:0];
	
	//UISlider *mySlider = [[UISlider alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 60.0f, 20.0f)];
	//[self explode:mySlider level:0];
	
	// UIButton *myButton = [[UIButton alloc] initWithFrame:CGRectZero];
	// [self explode:myButton level:0];
	
	// UISegmentedControl *s = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"1", @"2", @"3", nil]];
	// [self explode:s level:0];
	
	// UIImagePickerController *ipc = [[UIImagePickerController alloc] init]; // no worky
	// [self explode:ipc level:0];
}

-(void) dealloc
{
	// add any further clean-up here
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> {
}
@end

@implementation SampleAppDelegate

// On launch, create a basic window
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}

- (void)applicationWillTerminate:(UIApplication *)application  {
	// handle any final state matters here
}

- (void)dealloc {
	[super dealloc];
}

@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
