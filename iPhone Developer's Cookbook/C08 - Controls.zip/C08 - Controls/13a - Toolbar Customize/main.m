#import <UIKit/UIKit.h>

@interface UIToolbar (extended)
- (void)beginCustomizingItems:(id)fp8;
- (BOOL)endCustomizingAnimated:(BOOL)fp8;
@end;

@interface HelloController : UIViewController
{
	UIImageView *contentView;
	UIToolbar *toolbar;
	NSMutableArray *allitems;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Tool Swapout";
	return self;
}

- (void) endEditing
{
	[toolbar endCustomizingAnimated:YES];
	self.navigationItem.rightBarButtonItem = NULL;
}

- (void) doAction: (id) sender
{
	[toolbar beginCustomizingItems:allitems];
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
											  initWithTitle:@"Done" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(endEditing)];
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	[contentView setUserInteractionEnabled:YES];
	self.view = contentView;
	[contentView release];
	
	toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0.0f, 416.0f - 44.0f, 320.0f, 44.0f)];
	
	allitems = [[NSMutableArray alloc] init];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemBookmarks target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCamera target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCompose target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemOrganize target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemReply target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemStop target:self action:@selector(doAction:)] autorelease]];
	[allitems addObject:[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemTrash target:self action:@selector(doAction:)] autorelease]];
	
	[toolbar setItems:allitems];
	[contentView addSubview:toolbar];
	[toolbar release];
}

-(void) dealloc
{
	[allitems release];
	[toolbar release];
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
