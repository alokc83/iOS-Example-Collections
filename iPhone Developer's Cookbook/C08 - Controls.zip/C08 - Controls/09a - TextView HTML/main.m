#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

@interface UITextView (extended)
- (void)setContentToHTMLString:(NSString *) contentText;
@end

@interface HelloController : UIViewController
{
	UITextView *contentView;
	NSString *sourceText;
}
@property (nonatomic, retain)	NSString *sourceText;
@end

@implementation HelloController
@synthesize sourceText;

- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Text Example";
	return self;
}

- (void) presentText: (id) sender
{
	// dismiss keyboard if it exists
	[contentView resignFirstResponder];
	
	// Store text only if previous editor was text-based
	if ([contentView tag]) self.sourceText = [contentView text];
	
	// Text-based Editor
	[contentView setText:self.sourceText];
	[contentView setEditable:YES]; 
	[contentView setTag:YES];
}

- (void) presentHTML: (id) sender
{
	// dismiss keyboard if it exists
	[contentView resignFirstResponder];

	// Store text only if previous editor was text-based
	if ([contentView tag]) self.sourceText = [contentView text];
	
	// HTML-based Presentation-only
	[contentView setContentToHTMLString:self.sourceText];
	[contentView setEditable:NO];
	[contentView setTag:NO];
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setAutocorrectionType:UITextAutocorrectionTypeNo];
	[contentView setTag:NO];
	[contentView setEditable:NO];
	self.view = contentView;
	[contentView release];

	// Load the HTML source
	self.sourceText = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"decl" ofType:@"html"]];
	[contentView setContentToHTMLString:self.sourceText];


	// Add Text and HTML buttons
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Text" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(presentText:)] autorelease];
	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"HTML" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											 action:@selector(presentHTML:)] autorelease];
	
}

-(void) dealloc
{
	[contentView release];
	[sourceText release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
