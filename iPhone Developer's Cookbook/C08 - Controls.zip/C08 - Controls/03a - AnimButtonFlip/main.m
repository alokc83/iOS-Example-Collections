#import <UIKit/UIKit.h>

@interface HelloController : UIViewController
{
	UIImageView			*contentView;
	UIView				*clearView;
	BOOL				isOn;
	UIButton			*onButton;
	UIButton			*offButton;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Button";
	return self;
}

- (UIButton *) buildButton: (NSString *) aTitle
{
	// Create a button sized to our art
	UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
	[button initWithFrame:CGRectMake(0.0f, 0.0f, 219.0f, 233.0f)];

	// Set up the button aligment properties
	button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
	
	// Set the title, font and color
	[button setTitle:aTitle forState:UIControlStateNormal];
	[button setTitle:aTitle forState:UIControlStateHighlighted];
	[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
	[button setFont:[UIFont boldSystemFontOfSize:24.0f]];
	
	[button setCenter:CGPointMake(160.0f, 200.0f)];	
	[button addTarget:self action:@selector(toggleButton:) forControlEvents: UIControlEventTouchUpInside];

	return button;
}

- (void) toggleButton: (UIButton *) button
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:1.0f];
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:clearView cache:YES];

	[button removeFromSuperview];
	if (isOn = !isOn) 
	{
		[clearView addSubview:onButton];
	}
	else 
	{
		[clearView addSubview:offButton];
	}
	
	[UIView commitAnimations];
	
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	[contentView setUserInteractionEnabled:YES]; // Must allow for subviews to interact!
	self.view = contentView;
	[contentView release];
	
	// create the buttons
	onButton = [[self buildButton:@"On"] retain];
	[onButton setBackgroundImage:[[UIImage imageNamed:@"green.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateNormal];
	[onButton setBackgroundImage:[[UIImage imageNamed:@"green2.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateHighlighted];
	
	offButton = [[self buildButton:@"Off"] retain];
	[offButton setBackgroundImage:[[UIImage imageNamed:@"red.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateNormal];
	[offButton setBackgroundImage:[[UIImage imageNamed:@"red2.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateHighlighted];
	
	// Create clear view for flipping buttons
	clearView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 416.0f)];
	clearView.backgroundColor = [UIColor clearColor];

	[clearView addSubview:onButton];
	
	[contentView addSubview:clearView];
	[clearView release];
	
	isOn = YES;
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
