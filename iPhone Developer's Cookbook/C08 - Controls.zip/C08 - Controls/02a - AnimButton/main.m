#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

@interface HelloController : UIViewController
{
	UIImageView *contentView;
	SystemSoundID beep;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Button";
	return self;
}

- (void) playSound: (id) sender
{
	AudioServicesPlaySystemSound (beep);
}

- (UIButton *) buildButton: (NSString *) aTitle
{
	// Create a button sized to our art
	UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 219.0f, 233.0f)];
	[button setBackgroundImage:[[UIImage imageNamed:@"green.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateNormal];
	[button setBackgroundImage:[[UIImage imageNamed:@"green2.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] forState:UIControlStateHighlighted];

	// Set up the button aligment properties
	button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
	
	// Set the title, font and color
	[button setTitle:aTitle forState:UIControlStateNormal];
	[button setTitle:aTitle forState:UIControlStateHighlighted];
	[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
	[button setFont:[UIFont boldSystemFontOfSize:24.0f]];
	
	return [button autorelease];
}


- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	[contentView setUserInteractionEnabled:YES]; // Must allow for subviews to interact!
	self.view = contentView;
	[contentView release];
	
	// Load the sound
    id sndpath = [[NSBundle mainBundle] pathForResource:@"beep" ofType:@"wav"];
	CFURLRef baseURL = (CFURLRef)[[NSURL alloc] initFileURLWithPath:sndpath];
	AudioServicesCreateSystemSoundID (baseURL, &beep);

	// load in the animtion cells for the butterfly
	NSMutableArray *bflies = [[NSMutableArray alloc] init];
	for (int i = 1; i <= 17; i++) {
		NSString *cname = [NSString stringWithFormat:@"bf_%d.png", i];
		UIImage *img = [UIImage imageNamed:cname];
		if (img) [bflies addObject:img];
	}
	
	UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 80.0f, 80.0f)];
	[imageView setAnimationImages:bflies];
	[imageView setAnimationDuration:1.2f];
	[imageView startAnimating];
	[bflies release];
	
	[imageView setCenter:CGPointMake(160.0f, 200.0f)];
	[imageView setUserInteractionEnabled:NO];

	[contentView addSubview:imageView];
	[imageView release];

	// Add the button and set it to play the sound
	UIButton *button = [self buildButton:@"PushMe"];
	[button setCenter:CGPointMake(160.0f, 200.0f)];	
	[contentView addSubview: button];
	[button addTarget:self action:@selector(playSound:) forControlEvents: UIControlEventTouchDown];
}

-(void) dealloc
{
	if (beep) AudioServicesDisposeSystemSoundID(beep);
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
