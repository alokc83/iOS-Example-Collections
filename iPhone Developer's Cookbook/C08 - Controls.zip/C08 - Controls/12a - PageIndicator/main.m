#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface SwipeView : UIView
{
	CGPoint startTouchPosition;
	NSString *dirString;
	UIViewController *host;
}
@end

@implementation SwipeView

- (void) setHost: (UIViewController *) aHost
{
	host = aHost;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event 
{ 
	UITouch *touch = [touches anyObject]; 
	startTouchPosition = [touch locationInView:self]; 
	dirString = NULL;
} 

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event 
{ 
	UITouch *touch = touches.anyObject; 
	CGPoint currentTouchPosition = [touch locationInView:self]; 
	
    #define HORIZ_SWIPE_DRAG_MIN 12 
    #define VERT_SWIPE_DRAG_MAX 4 

	if (fabsf(startTouchPosition.x - currentTouchPosition.x) >= 
		HORIZ_SWIPE_DRAG_MIN && 
		fabsf(startTouchPosition.y - currentTouchPosition.y) <= 
		VERT_SWIPE_DRAG_MAX) 
	{ 
		// Horizontal Swipe
		if (startTouchPosition.x < currentTouchPosition.x) {
			dirString = kCATransitionFromLeft;
		}
		else 
			dirString = kCATransitionFromRight;
	}
} 

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event 
{
	if (dirString) [host swipeTo:dirString];
}
@end


@interface HelloController : UIViewController
{
	SwipeView *contentView;
	int currentPage;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Page Control";
	return self;
}

- (CATransition *) getAnimation:(NSString *) direction
{
	CATransition *animation = [CATransition animation];
	[animation setDelegate:self];
	[animation setType:kCATransitionPush];
	[animation setSubtype:direction];
	[animation setDuration:1.0f];
	[animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
	return animation;
}

- (void) pageTurn: (UIPageControl *) pageControl
{
	CATransition *transition;
	int secondPage = [pageControl currentPage];
	if ((secondPage - currentPage) > 0)
		transition = [self getAnimation:@"fromRight"];
	else
		transition = [self getAnimation:@"fromLeft"];
	
	UIImageView *newView = (UIImageView *)[[contentView subviews] objectAtIndex:0];
	[newView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"f%d.png", secondPage + 1]]];
	[contentView exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
	[[contentView layer] addAnimation:transition forKey:@"transitionViewAnimation"];

	currentPage = [pageControl currentPage];
}

- (void) swipeTo: (NSString *) aDirection
{
	UIPageControl *pageControl = [[[contentView superview] subviews] lastObject];

	if ([aDirection isEqualToString:kCATransitionFromRight])
	{
		if (currentPage == 4) return;
		[pageControl setCurrentPage:currentPage + 1];
	} else {
		if (currentPage == 0) return;
		[pageControl setCurrentPage:currentPage - 1];
	}
	
	[self pageTurn:pageControl];
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	UIView *baseView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];

	// Add the content view with its two images
	contentView = [[SwipeView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setHost:self];
	[contentView addSubview:[[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]]];
	[contentView addSubview:[[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]]];
	for (UIView *view in [contentView subviews])  [view setUserInteractionEnabled:NO];
	[[[contentView subviews] lastObject] setImage:[UIImage imageNamed:@"f3.png"]];
	
	[baseView addSubview:contentView];

	UIPageControl *pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0.0f, 10.0f, 320.0f, 20.0f)];
	[pageControl setNumberOfPages:5];
	[pageControl setCurrentPage:(currentPage = 2)];
	[pageControl addTarget:self action:@selector(pageTurn:) forControlEvents:UIControlEventValueChanged];
	[baseView addSubview:pageControl];
	self.view = baseView;
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
