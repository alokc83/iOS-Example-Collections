#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

@interface UITextView (extended)
- (void)setContentToHTMLString:(NSString *) contentText;
@end

@interface HelloController : UIViewController <UITextViewDelegate>
{
	UITextView *contentView;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Text Edit";
	return self;
}

// Reveal a done button when starting to edit
- (void) textViewDidBeginEditing: (UITextView *) textView
{
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Done" 
											  style:UIBarButtonItemStyleDone
											  target:self 
											  action:@selector(doneEditing:)] autorelease];
}

// The done button forces the text view to resign its first responder status
- (void) doneEditing: (id) sender
{
	[contentView resignFirstResponder];
	self.navigationItem.rightBarButtonItem = NULL;
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setDelegate:self];
	self.view = contentView;
	[contentView release];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
