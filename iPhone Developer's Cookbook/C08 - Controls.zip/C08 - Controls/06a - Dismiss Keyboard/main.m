#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

@interface HelloController : UIViewController <UITextFieldDelegate>
{
	UIImageView *contentView;
	UITextField *namefield, *passfield;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Keyboard Dismissal";
	return self;
}

// This method catches the return action
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}

- (void)loadView
{
	// Load an application image and set it as the primary view
	contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor whiteColor];
	self.view = contentView;
	[contentView release];
	
	UILabel *nameLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 80.0f, 40.0f)] retain];
	[nameLabel setText:@"Name: "];
	[nameLabel setCenter:CGPointMake(100.0f, 55.0f)];
	[contentView addSubview:nameLabel];
	[nameLabel release];
	
	UILabel *passLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 120.0f, 40.0f)] retain];
	[passLabel setText:@"Password: "];
	[passLabel setCenter:CGPointMake(92.0f, 95.0f)];
	[contentView addSubview:passLabel];
	[passLabel release];
	
	// A normal text entry field
	namefield = [[[UITextField alloc] initWithFrame:CGRectMake(120.0f, 40.0f, 150.0f, 30.0f)] retain];
	[namefield setBorderStyle:UITextBorderStyleRoundedRect];

	namefield.placeholder = @"name";
	namefield.autocorrectionType = UITextAutocorrectionTypeNo;
	namefield.autocapitalizationType = UITextAutocapitalizationTypeNone;
	namefield.returnKeyType = UIReturnKeyDone;
	namefield.clearButtonMode = UITextFieldViewModeWhileEditing;

	namefield.delegate = self;
	[contentView addSubview:namefield];
	[namefield release];

	// A secure password field
	passfield = [[[UITextField alloc] initWithFrame:CGRectMake(120.0f, 80.0f, 150.0f, 30.0f)] retain];
	[passfield setBorderStyle:UITextBorderStyleRoundedRect];
	
	passfield.placeholder = @"password";
	passfield.secureTextEntry = YES;
	passfield.autocorrectionType = UITextAutocorrectionTypeNo;
	passfield.autocapitalizationType = UITextAutocapitalizationTypeNone;
	passfield.returnKeyType = UIReturnKeyDone;
	passfield.clearButtonMode = UITextFieldViewModeWhileEditing;

	passfield.delegate = self;
	[contentView addSubview:passfield];
	[passfield release];
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
