#import <UIKit/UIKit.h>

@interface HelloController : UIViewController <UIAlertViewDelegate>
{
	UIView *contentView;
}
@end

@implementation HelloController

- (void)willPresentAlertView:(UIAlertView *)alertView
{
	[[[alertView subviews] objectAtIndex:2] setBackgroundColor:[UIColor colorWithRed:0.5 green:0.0f blue:0.0f alpha:1.0f]];
}

- (void) presentSheet
{
	UIAlertView *baseAlert = [[UIAlertView alloc] 
							  initWithTitle:@"Alert" message:@"This alert allows the user to choose between a 'safe' and a 'deadly' choice, indicated by button color." 
							  delegate:self cancelButtonTitle:nil
							  otherButtonTitles:@"Deadly!", @"Safe", nil];
	[baseAlert show];
}

- (id) init
{
	if (self = [super init]) self.title = @"Hello World";
	return self;
}

- (void)loadView
{
	contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	contentView.backgroundColor = [UIColor whiteColor];
    [contentView release];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											 initWithTitle:@"Do It" 
											 style:UIBarButtonItemStylePlain 
											 target:self 
											 action:@selector(presentSheet)] autorelease];
	
}

-(void) dealloc
{
	[contentView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
