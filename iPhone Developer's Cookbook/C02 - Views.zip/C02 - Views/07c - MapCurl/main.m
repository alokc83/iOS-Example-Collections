#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define TOP_LAYER_VIEW		101

@interface HelloController : UIViewController
{
	BOOL			notCurled;
}
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Map Curl";
	return self;
}

- (void) doit
{
    // Curl the image up or down. This runs only on the iPhone and will not
	// produce any effect from the simulator
	CATransition *animation = [CATransition animation];
	[animation setDelegate:self];
	[animation setDuration:1.0f];
	[animation setTimingFunction:UIViewAnimationCurveEaseInOut];
    [animation setType:(notCurled ? @"mapCurl" : @"mapUnCurl")];
	[animation setRemovedOnCompletion:NO];
    [animation setFillMode: @"extended"];
    [animation setRemovedOnCompletion: NO];
    notCurled = !notCurled;
	
	[[[self.view viewWithTag:TOP_LAYER_VIEW] layer] addAnimation:animation forKey:@"pageFlipAnimation"];
}

- (void)loadView
{
	UIImageView *contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.image = [UIImage imageNamed:@"bluedots.png"];
	contentView.userInteractionEnabled = YES;
	self.view = contentView;
	[contentView release];
	
	// Learn from my mistakes: don't name a UISwitch "switch". It's a reserved word
	UISwitch *switchView = [[UISwitch alloc] init];
	[switchView setCenter:CGPointMake(160.0f, 380.0f)];
	[contentView addSubview:switchView];
	[switchView release];
	
	UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 416.0f)];
	topView.backgroundColor = [UIColor lightGrayColor];
	topView.userInteractionEnabled = NO;
	topView.tag = TOP_LAYER_VIEW;
	[contentView addSubview:topView];
	[topView release];
	
	notCurled = YES;

	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doit)] autorelease];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
