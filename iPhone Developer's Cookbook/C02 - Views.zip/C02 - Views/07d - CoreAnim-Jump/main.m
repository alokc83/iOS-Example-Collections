#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define CGAutorelease(x) (__typeof(x))[NSMakeCollectable(x) autorelease]

@interface HelloController : UIViewController
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Core Animation";
	return self;
}

#define ANIMATION_DURATION (4.0)

// Adapted from Lucas Newman's Sample at http://lucasnewman.com/animationsamples.zip
- (void) doit
{
	// create the reflection layer
    CALayer *reflectionLayer = [CALayer layer];
    reflectionLayer.contents = [self.view layer].contents; // share the contents image with the screen layer
    reflectionLayer.opacity = 0.4;
    reflectionLayer.frame = CGRectOffset([self.view layer].frame, 0.5, 416.0f + 0.5); // NSHeight(displayBounds)
    reflectionLayer.transform = CATransform3DMakeScale(1.0, -1.0, 1.0); // flip the y-axis
    reflectionLayer.sublayerTransform = reflectionLayer.transform;
    [[self.view layer] addSublayer:reflectionLayer];
	
	// create a shadow layer which lies on top of the reflection layer
    CALayer *shadowLayer = [CALayer layer];
    shadowLayer.frame = reflectionLayer.bounds;
    shadowLayer.delegate = self;
    [shadowLayer setNeedsDisplay]; 
    [reflectionLayer addSublayer:shadowLayer];
	
    [CATransaction begin];
    [CATransaction setValue:[NSNumber numberWithFloat:ANIMATION_DURATION] forKey:kCATransactionAnimationDuration];
	
    // scale it down
    CABasicAnimation *shrinkAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    shrinkAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    shrinkAnimation.toValue = [NSNumber numberWithFloat:0.0];
	[[self.view layer] addAnimation:shrinkAnimation forKey:@"shrinkAnimation"];
	
	// fade it out
    CABasicAnimation *fadeAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    fadeAnimation.toValue = [NSNumber numberWithFloat:0.0];
    fadeAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    [[self.view layer] addAnimation:fadeAnimation forKey:@"fadeAnimation"];
	
	// make it jump a couple of times
    CAKeyframeAnimation *positionAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    CGMutablePathRef positionPath = CGAutorelease(CGPathCreateMutable());
    CGPathMoveToPoint(positionPath, NULL, [self.view layer].position.x, [self.view layer].position.y);
    CGPathAddQuadCurveToPoint(positionPath, NULL, [self.view layer].position.x, - [self.view layer].position.y, [self.view layer].position.x, [self.view layer].position.y);
    CGPathAddQuadCurveToPoint(positionPath, NULL, [self.view layer].position.x, - [self.view layer].position.y * 1.5, [self.view layer].position.x, [self.view layer].position.y);
    CGPathAddQuadCurveToPoint(positionPath, NULL, [self.view layer].position.x, - [self.view layer].position.y * 2.0, [self.view layer].position.x, [self.view layer].position.y);
    positionAnimation.path = positionPath;
    positionAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    [[self.view layer] addAnimation:positionAnimation forKey:@"positionAnimation"];
    
	[CATransaction commit];
}


- (void)loadView
{
	UIImageView *contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.image = [UIImage imageNamed:@"Default.png"];
	contentView.userInteractionEnabled = YES;
	self.view = contentView;
	[contentView release];

	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doit)] autorelease];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
