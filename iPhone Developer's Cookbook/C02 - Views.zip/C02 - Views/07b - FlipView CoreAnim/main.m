#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

// Note: although Apple promised UIViewAnimationTransitionCurlUp as a transition, it's not live yet
@interface FlipView : UIImageView
@end

@implementation FlipView
- (void) touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event
{
	CATransition *animation = [CATransition animation];
	[animation setDelegate:self];
	[animation setDuration:1.0f];
	[animation setTimingFunction:UIViewAnimationCurveEaseInOut];
	[animation setType: kCATransitionPush];
	[animation setSubtype: kCATransitionFromLeft];
	
	[[self superview] exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
	[[[self superview] layer] addAnimation:animation forKey:@"transitionViewAnimation"];	
}
@end

@interface HelloController : UIViewController
@end

@implementation HelloController
- (void)loadView
{
	// Create the main view
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor blackColor];
	self.view = contentView;
    [contentView release]; 
	
	FlipView *frontView = [[FlipView alloc] initWithFrame:self.view.bounds];
	frontView.image = [UIImage imageNamed:@"frontside.png"];
	frontView.userInteractionEnabled = YES;
	
	FlipView *backView = [[FlipView alloc] initWithFrame:self.view.bounds];
	backView.image = [UIImage imageNamed:@"backside.png"];
	backView.userInteractionEnabled = YES;
	
	// Add an identifying label for front
	CGRect labelFrame = CGRectMake(40.0f, 200.0f, 240.0f, 60.0f);
	UILabel *frontLabel = [[UILabel alloc] initWithFrame:labelFrame];
	frontLabel.text = @"This is the Front View";
	frontLabel.font = [UIFont fontWithName:@"Georgia" size:24.0f];
	frontLabel.textColor = [UIColor colorWithRed:0.82f green:1.0f blue:0.286f alpha:1.0f];
	frontLabel.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.0f];
	[frontView addSubview:frontLabel];
	[frontLabel release];
	
	// Add an identifying label for back
	UILabel *backLabel = [[UILabel alloc] initWithFrame:labelFrame];
	backLabel.text = @"This is the Back View";
	backLabel.font = [UIFont fontWithName:@"Georgia" size:24.0f];
	backLabel.textColor = [UIColor colorWithRed:0.82f green:1.0f blue:0.286f alpha:1.0f];
	backLabel.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.0f];
	[backView addSubview:backLabel];
	[backLabel release];
	
	// add the views
	[self.view addSubview:backView];
	[self.view addSubview:frontView];
	
	[backView release];
	[frontView release];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	HelloController *hello = [[HelloController alloc] init];
	[window addSubview:hello.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
