#import <UIKit/UIKit.h>

@interface MultiTouchView : UIView
{
	CGPoint loc1, loc2;
}
@property (nonatomic) CGPoint loc1;
@property (nonatomic) CGPoint loc2;
@end

@implementation MultiTouchView
@synthesize loc1;
@synthesize loc2;

- (BOOL) isMultipleTouchEnabled {return YES;}

- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
	NSArray *allTouches = [touches allObjects];
	int count = [allTouches count];
	if (count > 0) self.loc1 = [[allTouches objectAtIndex:0] locationInView:self];
	if (count > 1) self.loc2 = [[allTouches objectAtIndex:1] locationInView:self];
	[self setNeedsDisplay];
}

// React to moved touches the same as to began
- (void) touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event
{
	[self touchesBegan:touches withEvent:event];
}

- (void) drawRect: (CGRect) aRect
{
	// Get the current context
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextClearRect(context, aRect);
	
	// Set up the stroke and fill characteristics
	CGContextSetLineWidth(context, 3.0f);
	CGFloat gray[4] = {0.5f, 0.5f, 0.5f, 1.0f};
	CGContextSetStrokeColor(context, gray);
	CGFloat red[4] = {0.75f, 0.25f, 0.25f, 1.0f};
	CGContextSetFillColor(context, red);

	// Draw a line between the two location points
	CGContextMoveToPoint(context, self.loc1.x, self.loc1.y);
	CGContextAddLineToPoint(context, self.loc2.x, self.loc2.y);
	CGContextStrokePath(context);
	
	CGRect p1box = CGRectMake(self.loc1.x, self.loc1.y, 0.0f, 0.0f);
	CGRect p2box = CGRectMake(self.loc2.x, self.loc2.y, 0.0f, 0.0f);
	float offset = -8.0f;

	// circle point 1
	CGMutablePathRef path = CGPathCreateMutable();
	CGPathAddEllipseInRect(path, NULL, CGRectInset(p1box, offset, offset));
	CGContextAddPath(context, path);
	CGContextFillPath(context);
	CFRelease(path);
	
	// circle point 2
	path = CGPathCreateMutable();
	CGPathAddEllipseInRect(path, NULL, CGRectInset(p2box, offset, offset));
	CGContextAddPath(context, path);
	CGContextFillPath(context);	
	CFRelease(path);
}
@end


@interface HelloController : UIViewController
@end

@implementation HelloController
- (void)loadView
{
	MultiTouchView *contentView = [[MultiTouchView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.loc1 = CGPointMake(80.0f, 240.0f);
	contentView.loc2 = CGPointMake(240.0f, 240.0f);
	self.view = contentView;
    [contentView release];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	HelloController *hello = [[HelloController alloc] init];
	[window addSubview:hello.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
