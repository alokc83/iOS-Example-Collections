#import <UIKit/UIKit.h>

@interface HelloController : UIViewController
@end

@implementation HelloController
- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)orientation duration:(NSTimeInterval)duration  {

	CGRect apprect;
	apprect.origin = CGPointMake(0.0f, 0.0f);
	
	if ((orientation == UIInterfaceOrientationLandscapeLeft) || (orientation == UIInterfaceOrientationLandscapeRight))
		apprect.size = CGSizeMake(480.0f, 300.0f);
	else
		apprect.size = CGSizeMake(320.0f, 460.0f);

	// Iterate through the subviews and inset each item
	float offset = 32.0f;
	for (UIView *subview in [self.view subviews])	
	{
		CGRect frame = CGRectInset(apprect, offset, offset);
		[subview setFrame:frame];
		offset += 32.0f;
	}
}

- (void)loadView
{
	// Create the main view
	UIView *contentView = [[UIView alloc] initWithFrame: [[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor whiteColor];
	self.view = contentView;
    [contentView release];

	// Get the view bounds as our starting point
	CGRect apprect = [contentView bounds];
	
	// Add each inset subview
	UIView *subview = [[UIView alloc] initWithFrame:CGRectInset(apprect, 32.0f, 32.0f)];
	subview.backgroundColor = [UIColor lightGrayColor];
	[contentView addSubview:subview];
	[subview release];
	
	subview = [[UIView alloc] initWithFrame:CGRectInset(apprect, 64.0f, 64.0f)];
	subview.backgroundColor = [UIColor darkGrayColor];
	[contentView addSubview:subview];
	[subview release];
	
	subview = [[UIView alloc] initWithFrame:CGRectInset(apprect, 96.0f, 96.0f)];
	subview.backgroundColor = [UIColor blackColor];
	[contentView addSubview:subview];
	[subview release];
}

// Allow the view to respond to all iPhone Orientation changes
-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	HelloController *hello = [[HelloController alloc] init];
	[window addSubview:hello.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
