#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define kAnimationKey @"transitionViewAnimation"

@interface FlipView : UIImageView
{
	CGPoint startTouchPosition;
	NSString *dirString;
}
@end

@implementation FlipView
- (FlipView *) init
{
	self = [super init];
	[self setMultipleTouchEnabled:YES];
	return self;
}

- (CATransition *) getAnimation:(NSString *) direction
{
	CATransition *animation = [CATransition animation];
	[animation setDelegate:self];
	// [animation setType:@"oglFlip"]; 
	[animation setType:kCATransitionPush];
	[animation setSubtype:direction];
	[animation setDuration:1.0f];
	[animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
	return animation;
}

#define HORIZ_SWIPE_DRAG_MIN 12 
#define VERT_SWIPE_DRAG_MAX 4 

// The following swipe code derives from Apple Sample Code
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event 
{ 
	UITouch *touch = [touches anyObject]; 
	startTouchPosition = [touch locationInView:self]; 
	dirString = NULL;
} 

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event 
{ 
	UITouch *touch = touches.anyObject; 
	CGPoint currentTouchPosition = [touch locationInView:self]; 
	
	if (fabsf(startTouchPosition.x - currentTouchPosition.x) >= 
		HORIZ_SWIPE_DRAG_MIN && 
		fabsf(startTouchPosition.y - currentTouchPosition.y) <= 
		VERT_SWIPE_DRAG_MAX) 
	{ 
		// Horizontal Swipe
		if (startTouchPosition.x < currentTouchPosition.x) {
			dirString = kCATransitionFromLeft;
		}
		else 
			dirString = kCATransitionFromRight;
	} 
	else if (fabsf(startTouchPosition.y - currentTouchPosition.y) >= 
		  HORIZ_SWIPE_DRAG_MIN && 
		  fabsf(startTouchPosition.x - currentTouchPosition.x) <= 
		  VERT_SWIPE_DRAG_MAX)
	{ 
		// Vertical Swipe
		if (startTouchPosition.y < currentTouchPosition.y) 
			dirString = kCATransitionFromBottom;
		else 
			dirString = kCATransitionFromTop;
	} else 
	{
		// Process a non-swipe event. 
		// dirString = NULL;
	}
} 

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event 
{
	if (dirString) 
	{
		CATransition *animation = [self getAnimation:dirString];
		[[self superview] exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
		[[[self superview] layer] addAnimation:animation forKey:kAnimationKey];
		
	}
}
@end

@interface HelloController : UIViewController
@end

@implementation HelloController
- (void)loadView
{
	// Create the main view
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor blackColor];
	self.view = contentView;
    [contentView release];
	
	UIImageView *backView = [[FlipView alloc] initWithFrame:self.view.bounds];
	[backView setImage:[UIImage imageNamed:@"backside.png"]];
	[backView setUserInteractionEnabled:YES];
	[self.view addSubview:backView];
	[backView release];
	
	UIImageView *frontView = [[FlipView alloc] initWithFrame:self.view.bounds];
	[frontView setImage:[UIImage imageNamed:@"frontside.png"]];
	[frontView setUserInteractionEnabled:YES];
	[self.view addSubview:frontView];
	[frontView release];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
// On launch, create a basic window
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	HelloController *hello = [[HelloController alloc] init];
	[window addSubview:hello.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
