#import <UIKit/UIKit.h>

// Courtesy of Apple, Create Bitmap with Alpha/RGB values
CGContextRef CreateARGBBitmapContext (CGImageRef inImage, CGSize size)
{
    CGContextRef    context = NULL;
    CGColorSpaceRef colorSpace;
    void *          bitmapData;
    int             bitmapByteCount;
    int             bitmapBytesPerRow;
	
    size_t pixelsWide = size.width;
    size_t pixelsHigh = size.height;
    bitmapBytesPerRow   = (pixelsWide * 4);
    bitmapByteCount     = (bitmapBytesPerRow * pixelsHigh);
    colorSpace = CGColorSpaceCreateDeviceRGB();
	
	if (colorSpace == NULL)
    {
        fprintf(stderr, "Error allocating color space\n");
        return NULL;
    }
	
    // allocate the bitmap & create context
    bitmapData = malloc( bitmapByteCount );
    if (bitmapData == NULL)
    {
        fprintf (stderr, "Memory not allocated!");
        CGColorSpaceRelease( colorSpace );
        return NULL;
    }
	
    context = CGBitmapContextCreate (bitmapData, pixelsWide, pixelsHigh, 8,
									 bitmapBytesPerRow, colorSpace,
									 kCGImageAlphaPremultipliedFirst);
    if (context == NULL)
    {
        free (bitmapData);
        fprintf (stderr, "Context not created!");
    }

    CGColorSpaceRelease( colorSpace );
    return context;
}

// Return a C-based bitmap of the image data inside an image
unsigned char *RequestImagePixelData(UIImage *inImage)
{
	CGImageRef img = [inImage CGImage];
	CGSize size = [inImage size];
    
	CGContextRef cgctx = CreateARGBBitmapContext(img, size);
    if (cgctx == NULL) return NULL;

    CGRect rect = {{0,0},{size.width, size.height}};
    CGContextDrawImage(cgctx, rect, img);
	unsigned char *data = CGBitmapContextGetData (cgctx);
	CGContextRelease(cgctx);

	return data;
}

#define SIDELENGTH 40

// Cross hair view for touching
@interface CrossHairView : UIView
@end
@implementation CrossHairView
- (void) drawRect: (CGRect) aRect
{
	
	// Create a new path
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGMutablePathRef path = CGPathCreateMutable();
	
	// Set up the stroke characteristics
	CGContextSetLineWidth(context, 3.0f);
	CGFloat gray[4] = {0.75f, 0.75f, 0.75f, 1.0f};
	CGContextSetStrokeColor(context, gray);

	// Add circle to path
	CGRect limits = CGRectMake(2.0f, 2.0f, SIDELENGTH - 4.0f, SIDELENGTH - 4.0f);
	CGPathAddEllipseInRect(path, NULL, limits);
	CGContextAddPath(context, path);
	
	// Add cross to path, leaving an inspection point in the middle
	CGContextMoveToPoint(context, 0.0f, SIDELENGTH/2.0f);
	CGContextAddLineToPoint(context, (SIDELENGTH/2.0f) - 2.0f, SIDELENGTH/2.0f);
	CGContextMoveToPoint(context, (SIDELENGTH /2.0f) + 2.0f, SIDELENGTH/2.0f);
	CGContextAddLineToPoint(context, SIDELENGTH, SIDELENGTH/2.0f);
	CGContextMoveToPoint(context, SIDELENGTH/2.0f, 0.0f);
	CGContextAddLineToPoint(context, SIDELENGTH/2.0f, (SIDELENGTH / 2.0f) - 2.0f);
	CGContextMoveToPoint(context, SIDELENGTH/2.0f, SIDELENGTH);
	CGContextAddLineToPoint(context, SIDELENGTH/2.0f, (SIDELENGTH / 2.0f) + 2.0f);

	CGContextStrokePath(context);	
	CFRelease(path);
}
@end

#define COLOR_VIEW_TAG		999
#define CROSSHAIR_TAG		998

// Create an Image View that stores a copy of its image as an addressable bitmap
@interface BitMapView : UIImageView
{
	unsigned char *bitmap;
	CGSize size;
}
@end

@implementation BitMapView
- (id) initWithFrame: (CGRect) aFrame
{
	if (!(self = [super initWithFrame: aFrame])) return NULL;

	// initialize by adding the cross-hair
	CrossHairView *crossHair = [[CrossHairView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, SIDELENGTH, SIDELENGTH)];
	crossHair.tag = CROSSHAIR_TAG;
	crossHair.backgroundColor = [UIColor clearColor];
	crossHair.center = CGPointMake(160.0f, 240.0f);
	[self addSubview:crossHair];
	[crossHair release];
	
	return self;
}
- (BOOL) pointInside:(CGPoint)point withEvent:(UIEvent *)event 
{
	long startByte = (int)((point.y * size.width) + point.x) * 4;
	int alpha = (unsigned char) bitmap[startByte];
	return (alpha > 0.5);
}

- (void) touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event
{
	CGPoint pt = [[touches anyObject] locationInView:self];
	long startByte = (int)((pt.y * size.width) + pt.x) * 4;

	// Note these points are slightly off in the simulator
	[self viewWithTag:CROSSHAIR_TAG].center = pt;
	
	// Output RGB values. The alpha value has offset 0
	/* printf("[%3d, %3d] %3dR %3dG %3dB\n", (int)pt.x, (int)pt.y, 
			   (unsigned char) bitmap[startByte+1], 
			   (unsigned char) bitmap[startByte+2], 
			   (unsigned char) bitmap[startByte+3]); */
	
	[self viewWithTag:COLOR_VIEW_TAG].backgroundColor = [UIColor 
														 colorWithRed: (float) (bitmap[startByte+1]/255.0f)
														 green: (float) (bitmap[startByte+2]/255.0f)
														 blue:  (float) (bitmap[startByte+3]/255.0f)
														 alpha: 1.0f];
}

-(void) setImage:(UIImage *) anImage
{
	[super setImage:anImage];
	bitmap = RequestImagePixelData(anImage);
	size = [anImage size];
	UIView *colorView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 400.0f, 320.0f, 80.0f)];
	colorView.userInteractionEnabled = NO;
	colorView.backgroundColor = [UIColor blueColor];
	colorView.tag = COLOR_VIEW_TAG;
	[self addSubview:colorView];
	[colorView release];
}

-(void) dealloc
{
	if (bitmap) free(bitmap);
	[super dealloc];
}
@end


// Primary View Controller
@interface HelloController : UIViewController
@end

@implementation HelloController
- (void)loadView
{
	BitMapView *contentView = [[BitMapView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	[contentView setImage:[UIImage imageNamed:@"image2.jpg"]];
	[contentView setUserInteractionEnabled:YES];
	self.view = contentView;
    [contentView release];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end
@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	HelloController *hello = [[HelloController alloc] init];
	[window addSubview:hello.view];
	[window makeKeyAndVisible];
	[application setStatusBarHidden:YES];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
