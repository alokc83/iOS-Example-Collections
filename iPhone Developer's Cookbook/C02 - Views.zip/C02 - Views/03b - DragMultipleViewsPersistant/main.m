#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>

// Draggable View
@interface DragView : UIImageView
{
	CGPoint startLocation;
	NSString *whichFlower;
}
@property (nonatomic, retain) NSString *whichFlower;
@end

@implementation DragView
@synthesize whichFlower;
- (id) initWithFrame: (CGRect) aFrame
{
	self = [super initWithFrame: aFrame];
	if (!self) return NULL;
	self.userInteractionEnabled = YES;
	return self;
}

- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
	// Retrieve the touch point
	CGPoint pt = [[touches anyObject] locationInView:self];
	startLocation = pt;
	[[self superview] bringSubviewToFront:self];
}

- (void) touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event
{
	// Move relative to the original touch point
	CGPoint pt = [[touches anyObject] locationInView:self];
	CGRect frame = [self frame];
	frame.origin.x += pt.x - startLocation.x;
	frame.origin.y += pt.y - startLocation.y;
	[self setFrame:frame];
}

- (void) dealloc
{
	[self.whichFlower release];
	[super dealloc];
}
@end

// Primary View Controller
@interface HelloController : UIViewController
@end

@implementation HelloController
#define MAXFLOWERS 16
CGPoint randomPoint() { return CGPointMake(random() % 256, random() % 396); }

// Collect all the colors and locations and save them for the next use
- (void) updateDefaults
{
	NSMutableArray *colors =  [[NSMutableArray alloc] init];
	NSMutableArray *locs = [[NSMutableArray alloc] init];
	
	for (DragView *dv in [self.view subviews]) 
	{
		[colors addObject:[dv whichFlower]];
		[locs addObject:NSStringFromCGRect([dv frame])]; 
	}
	
	[[NSUserDefaults standardUserDefaults] setObject:colors forKey:@"colors"];
	[[NSUserDefaults standardUserDefaults] setObject:locs forKey:@"locs"];
	[[NSUserDefaults standardUserDefaults] synchronize];
	
	[colors release];
	[locs release];
}

- (void)loadView
{
	// Create the main view
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor blackColor];
	self.view = contentView;
    [contentView release];
	
	// Attempt to read in previous colors and locations
	NSMutableArray *colors, *locs;
	colors = [[NSUserDefaults standardUserDefaults] objectForKey:@"colors"];
	locs = [[NSUserDefaults standardUserDefaults] objectForKey:@"locs"];
	
	for (int i = 0; i < MAXFLOWERS; i++)
	{
		// Set the flower to a random point unless there's a previous location
		CGRect dragRect;
		if (locs && ([locs count] == MAXFLOWERS)) 
			dragRect = CGRectFromString([locs objectAtIndex:i]);
		else
		{
			dragRect = CGRectMake(0.0f, 0.0f, 64.0f, 64.0f);
			dragRect.origin = randomPoint();
		}
		
		// Create the view
		DragView *dragger = [[DragView alloc] initWithFrame:dragRect];
		
		// Use a random color unless there's a previous color
		NSString *whichFlower = [[NSArray arrayWithObjects:@"blueFlower.png", @"pinkFlower.png", @"orangeFlower.png", nil] objectAtIndex:(random() % 3)];
		if (colors && ([colors count] == MAXFLOWERS)) whichFlower = [colors objectAtIndex:i];
		[dragger setWhichFlower:whichFlower];
		[dragger setImage:[UIImage imageNamed:whichFlower]];
		
		// Add the subview
		[self.view addSubview:dragger];
		[dragger release];
	}
}
@end

// For reference. None of this really is going to work now that the SDK is further along
// than while I was writing this book
@interface UIApplication (Extended)
-(void) _writeApplicationSnapshot;
-(void) _updateDefaultImage;
-(void) createApplicationDefaultPNG;
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	HelloController *hello;
}
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	hello = [[HelloController alloc] init];
	[window addSubview:hello.view];
	[window makeKeyAndVisible];
}

- (void)applicationWillTerminate:(UIApplication *)application  {
	[hello updateDefaults]; // update the defaults on quit
	[application _writeApplicationSnapshot]; 
}

- (void)dealloc {
	[hello release];
	[super dealloc];
}

@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
