#import <UIKit/UIKit.h>

#define IMAGE_VIEW_TAG	999

@interface ToggleView: UIView
{
	BOOL isVisible;
}
@end

@implementation ToggleView
- (id) initWithFrame: (CGRect) aFrame;
{
	self = [super initWithFrame:aFrame];
	isVisible = YES;

	UIImageView *imgView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	imgView.image = [UIImage imageNamed:@"alphablend.png"];
	imgView.tag = IMAGE_VIEW_TAG;
	imgView.userInteractionEnabled = NO;
	[self addSubview:imgView];
	[imgView release];
	
	return self;
}

- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
	// only respond to mouse down events
	UITouch *touch = [touches anyObject];
	if ([touch phase] != UITouchPhaseBegan) return;

	isVisible = !isVisible;

	// perform the fade out or fade in
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:1.0];
	[[self viewWithTag:IMAGE_VIEW_TAG] setAlpha:(float)isVisible];
	[UIView commitAnimations];
}
@end

@interface HelloController : UIViewController
@end

@implementation HelloController
- (void)loadView
{
	// Load an application image and set it as the primary view
	ToggleView *contentView = [[ToggleView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor whiteColor];
	self.view = contentView;
    [contentView release];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> {
}
@end

@implementation SampleAppDelegate

- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	HelloController *hello = [[HelloController alloc] init];
	[window addSubview:hello.view];
	[window makeKeyAndVisible];
}
- (void)dealloc {[super dealloc];}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
