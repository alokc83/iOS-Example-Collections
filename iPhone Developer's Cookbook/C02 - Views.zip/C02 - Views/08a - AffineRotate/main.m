#import <UIKit/UIKit.h>
#import "math.h"

#define PI 3.14159265

#define ROTATE_VIEW_TAG	999

@interface HelloController : UIViewController
{
	int theta;
}
@end

@implementation HelloController
- (id)init
{
	if (self = [super init]) self.title = @"Affine Demo";
	return self;
}

- (void) handleTimer: (NSTimer *) timer
{
	// Rotate each iteration by 1% of PI
	float angle = theta * (PI / 100);
	CGAffineTransform transform = CGAffineTransformMakeRotation(angle);
	theta = (theta + 1) % 200;
	
	// For fun, scale by the absolute value of the cosine
	float degree = cos(angle);
	if (degree < 0.0) degree *= -1.0f;
	degree += 0.5f;
	CGAffineTransform scaled = CGAffineTransformScale(transform, degree, degree);
	
	// Apply the affine transform
	[[self.view viewWithTag:ROTATE_VIEW_TAG] setTransform:scaled];
}

- (void)loadView
{
	theta = 0;
	
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	[contentView release];
	
	UIImageView *rotateView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 240.0f, 240.0f)];
	rotateView.center = CGPointMake(160.0f, 208.0f);
	rotateView.image = [UIImage imageNamed:@"rotateart.png"];
	rotateView.tag = ROTATE_VIEW_TAG;
	[contentView addSubview:rotateView];
	[rotateView release];

	[NSTimer scheduledTimerWithTimeInterval: 0.03f target: self selector: @selector(handleTimer:)
								   userInfo: nil repeats: YES];	
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	HelloController *hello = [[HelloController alloc] init];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:hello];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
