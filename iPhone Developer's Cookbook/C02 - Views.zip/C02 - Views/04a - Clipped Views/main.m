#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import <time.h>

#define LOGO		[UIImage imageNamed:@"Icon.png"]

// These calls which extend UIView are partly not needed any more in 
// recent versions of the SDK, which is why parts are commented out
@interface UIView (Extended)
// +(void) beginAnimations:(id)sender;
// +(void) endAnimations;
-(void) setOrigin: (CGPoint) aPoint;
@end

// Random point support
CGPoint randomPoint() { return CGPointMake(random() % 256, random() % 352); }

@interface DragClipView : UIView
{
	CGPoint startLocation;
}
@end

@implementation DragClipView

#define MAXCLIPS 16
#define SIDELENGTH 57

- (void) drawRect: (CGRect) aRect
{
	CGRect bounds = CGRectMake(0.0f, 0.0f, SIDELENGTH, SIDELENGTH);

	// Create a new path
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGMutablePathRef path = CGPathCreateMutable();
	
	// Add circle to path
	CGPathAddEllipseInRect(path, NULL, bounds);
	CGContextAddPath(context, path);

	// Clip to the circle and draw the logo
	CGContextClip(context);
	[LOGO drawInRect:bounds];
	CFRelease(path);
}

// Detect whether the touch "hits" the view
- (BOOL) pointInside:(CGPoint)point withEvent:(UIEvent *)event 
{
	CGPoint pt;
	float HALFSIDE = SIDELENGTH / 2.0f;

	// normalize with centered origin
	pt.x = (point.x - HALFSIDE) / HALFSIDE;
	pt.y = (point.y - HALFSIDE) / HALFSIDE;
	
	// x^2 + y^2 = radius
	float xsquared = pt.x * pt.x;
	float ysquared = pt.y * pt.y;
	
	// If the radius < 1, the point is within the clipped circle
	if ((xsquared + ysquared) < 1.0) return YES;
	return NO;
}

- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
	// Establish the touch point
	CGPoint pt = [[touches anyObject] locationInView:self];
	startLocation = pt;
	[[self superview] bringSubviewToFront:self];
}

- (void) touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event
{
	// Move with respect to the touch point
	CGPoint pt = [[touches anyObject] locationInView:self];
	CGRect frame = [self frame];
	frame.origin.x += pt.x - startLocation.x;
	frame.origin.y += pt.y - startLocation.y;
	[self setFrame:frame];
}

@end

// Primary View Controller
@interface HelloController : UIViewController
@end

@implementation HelloController
- (HelloController *) init
{
	if (self = [super init]) self.title = @"Drag Clips";
	return self;
}

// Randomize on request
- (void) randomize
{
	for (DragClipView *dv in [self.view subviews]) 
		[dv setOrigin:randomPoint()];
}

// Update persistence
- (void) updateDefaults
{
	NSMutableArray *clipLocs = [[NSMutableArray alloc] init];
	
	for (DragClipView *dv in [self.view subviews]) {
		[clipLocs addObject:NSStringFromCGRect([dv frame])]; }
	
	[[NSUserDefaults standardUserDefaults] setObject:clipLocs forKey:@"clipLocs"];
	[[NSUserDefaults standardUserDefaults] synchronize];
	
	[clipLocs release];
}

- (void)loadView
{
	// Create the main view
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor darkGrayColor];
	self.view = contentView;
    [contentView release];
	
	// Retrieve any previous locations
	NSMutableArray *clipLocs = [[NSUserDefaults standardUserDefaults] objectForKey:@"clipLocs"];

	for (int i = 0; i < MAXCLIPS; i++)
	{
		// Use a random point unless there's a previous location
		CGRect dragRect;
		if (clipLocs && ([clipLocs count] == MAXCLIPS)) 
			dragRect = CGRectFromString([clipLocs objectAtIndex:i]);
		else
		{
			dragRect = CGRectMake(0.0f, 0.0f, SIDELENGTH, SIDELENGTH);
			dragRect.origin = randomPoint();
		}
		
		// Build the dragger
		DragClipView *dragger = [[DragClipView alloc] initWithFrame:dragRect];
		dragger.backgroundColor = [UIColor clearColor];
		dragger.userInteractionEnabled = YES;

		// Add the subview
		[self.view addSubview:dragger];
		[dragger release];
	}

	// Add a randomize button
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											   initWithTitle:@"Randomize" 
											   style:UIBarButtonItemStylePlain 
											   target:self 
											   action:@selector(randomize)] autorelease];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> {
	HelloController *hello;
}
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	
    srandom(time(0));
	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	hello = [[HelloController alloc] init];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:hello];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}

- (void)applicationWillTerminate:(UIApplication *)application  {
	[hello updateDefaults];
}

- (void)dealloc {
	[hello release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
