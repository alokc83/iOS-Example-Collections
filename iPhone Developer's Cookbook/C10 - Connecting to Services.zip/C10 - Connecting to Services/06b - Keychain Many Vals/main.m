#import <UIKit/UIKit.h>
#import <Security/Security.h>

// This code works on the device but not in the simulator

// Password Keeper securely saves a password dictionary
@interface PasswordKeeper: NSObject
+ (PasswordKeeper *) sharedInstance;
- (void) setObject: (id) anObject forKey: (NSString *) aKey;
- (void) removeObjectForKey: (NSString *) aKey;
- (id) objectForKey: (NSString *) aKey;
- (NSMutableDictionary *) passwordDict;
@end

@implementation PasswordKeeper

static PasswordKeeper *sharedInstance = nil;

+(PasswordKeeper *) sharedInstance {
    if(!sharedInstance) {
		sharedInstance = [[self alloc] init];
    }
    return sharedInstance;
}

// Translate status messages into return strings
- (NSString *) fetchStatus : (OSStatus) status
{
	if		(status == 0) return(@"Success!");
	else if (status == errSecNotAvailable) return(@"No trust results are available.");
	else if (status == errSecItemNotFound) return(@"The item cannot be found.");
	else if (status == errSecParam) return(@"Parameter error.");
	else if (status == errSecAllocate) return(@"Memory allocation error. Failed to allocate memory.");
	else if (status == errSecInteractionNotAllowed) return(@"User interaction is not allowed.");
	else if (status == errSecUnimplemented ) return(@"Function is not implemented");
	else if (status == errSecDuplicateItem) return(@"The item already exists.");
	else if (status == errSecDecode) return(@"Unable to decode the provided data.");
	else 
		return([NSString stringWithFormat:@"Function returned: %d", status]);
}

#define	ACCOUNT	@"iPhone Developer Cookbook Test Account 2"
#define	SERVICE	@"iPhone Developer Cookbook Test Service 2"
#define PWKEY	@"iPhone Developer Cookbook Test Password Data 2"
#define DEBUG	YES

// Return a base dictionary
- (NSMutableDictionary *) baseDictionary
{
	NSMutableDictionary *md = [[NSMutableDictionary alloc] init];
	
	// Password identification keys
	NSData *identifier = [PWKEY dataUsingEncoding:NSUTF8StringEncoding];
	[md setObject:identifier forKey:(id)kSecAttrGeneric];
	[md setObject:ACCOUNT forKey:(id)kSecAttrAccount];
    [md setObject:SERVICE forKey:(id)kSecAttrService];
	
	// Mandatory Key
	[md setObject:(id)kSecClassGenericPassword forKey:(id)kSecClass];
	
	return [md autorelease];
}

// Build a search query based
- (NSMutableDictionary *) buildSearchQuery
{
	NSMutableDictionary *genericPasswordQuery = [self baseDictionary];
	
	// Add the search constraints
	[genericPasswordQuery setObject:(id)kSecMatchLimitOne forKey:(id)kSecMatchLimit];
	[genericPasswordQuery setObject:(id)kCFBooleanTrue
							 forKey:(id)kSecReturnAttributes];
	[genericPasswordQuery setObject:(id)kCFBooleanTrue
							 forKey:(id)kSecReturnData];
	
	return genericPasswordQuery;
}

// retrieve data dictionary from the keychain
- (NSMutableDictionary *) fetchDictionary
{
	NSMutableDictionary *genericPasswordQuery = [self buildSearchQuery];
	
	NSMutableDictionary *outDictionary = nil;
	OSStatus status = SecItemCopyMatching((CFDictionaryRef)genericPasswordQuery, (CFTypeRef *)&outDictionary);
	if (DEBUG) printf("FETCH: %s\n", [[self fetchStatus:status] UTF8String]);
	
	if (status == errSecItemNotFound) return NULL;
	return outDictionary;
}

// Deserialize from data
- (NSMutableDictionary *) dictionaryFromData: (NSData *) data
{
	NSString *errorString;
	NSMutableDictionary *outDict = [NSPropertyListSerialization propertyListFromData:data mutabilityOption:kCFPropertyListMutableContainersAndLeaves format:NULL errorDescription:&errorString];
	return outDict;
}

// Serialize to data
- (NSData *) dataFromDictionary: (NSMutableDictionary *) dict
{
	
	NSString *errorString;
	NSData *outData = [NSPropertyListSerialization dataFromPropertyList:dict format:NSPropertyListBinaryFormat_v1_0 errorDescription:&errorString];
	return outData;
}

// fetch the keychain value
- (NSMutableDictionary *) fetchKeychainValue
{
	NSMutableDictionary *outDictionary = [self fetchDictionary];
	
	if (outDictionary)
	{
		NSMutableDictionary *dict = [self dictionaryFromData:[outDictionary objectForKey:(id)kSecValueData]];
		[outDictionary release];
		return dict;
	} else return NULL;
}

// remove a keychain entry
- (void) clearKeychain
{
	NSMutableDictionary *genericPasswordQuery = [self baseDictionary];
	
	OSStatus status = SecItemDelete((CFDictionaryRef) genericPasswordQuery);
	if (DEBUG) printf("DELETE: %s\n", [[self fetchStatus:status] UTF8String]);
}

// Return a keychain-style dictionary populated with the password dictionary
- (NSMutableDictionary *) buildDictForPasswordDict:(NSMutableDictionary *) dict
{
	NSData *passwordData = [self dataFromDictionary:dict];
	NSMutableDictionary *passwordDict = [self baseDictionary];
    [passwordDict setObject:passwordData forKey:(id)kSecValueData]; // password 
	
	return passwordDict;
}

// create a new keychain entry
- (BOOL) createKeychainValue:(NSMutableDictionary *) passwordDict
{
	NSMutableDictionary *md = [self buildDictForPasswordDict:passwordDict];
	OSStatus status = SecItemAdd((CFDictionaryRef)md, NULL);
	if (DEBUG) printf("CREATE: %s\n", [[self fetchStatus:status] UTF8String]);
	
	if (status == noErr) return YES; else return NO;
}

// update a keychaing entry
- (BOOL) updateKeychainValue:(NSMutableDictionary *)passwordDict
{
	NSMutableDictionary *genericPasswordQuery = [self baseDictionary];
	NSMutableDictionary *attributesToUpdate = [[NSMutableDictionary alloc] init];
	NSData *passwordData = [self dataFromDictionary:passwordDict];
	[attributesToUpdate setObject:passwordData forKey:(id)kSecValueData];
	
	OSStatus status = SecItemUpdate((CFDictionaryRef)genericPasswordQuery, (CFDictionaryRef)attributesToUpdate);
	if (DEBUG) printf("UPDATE: %s\n", [[self fetchStatus:status] UTF8String]);
	
	if (status == 0) return YES; else return NO;
}

/*
 *  Simple Keychain Access Protocol Methods
 */

- (void) setObject: (id) anObject forKey: (NSString *) aKey
{
	NSMutableDictionary *dict = [self fetchKeychainValue];
	if (dict)
	{
		// Keychain already has object
		[dict setObject:anObject forKey:aKey];
		[self updateKeychainValue:dict];
		return;
	}

	// Dictionary not found so create it
	dict = [[NSMutableDictionary alloc] init];
	[dict setObject:anObject forKey:aKey];
	if (![self createKeychainValue:dict]) [self updateKeychainValue:dict];
}

- (void) removeObjectForKey: (NSString *) aKey
{
	NSMutableDictionary *dict = [self fetchKeychainValue];
	if (dict) 
	{
		// Keychain has object
		[dict removeObjectForKey:aKey];
		[self updateKeychainValue:dict];
		return;
	}
}

- (id) objectForKey: (NSString *) aKey
{
	NSMutableDictionary *dict = [self fetchKeychainValue];
	return [dict objectForKey:aKey];
}

- (NSMutableDictionary *) passwordDict
{
	return [self fetchKeychainValue];
}

@end

#define NAMEFIELD_TAG		9999
#define PASSFIELD_TAG		9998

@interface HelloController : UIViewController <UITextFieldDelegate>
@end

@implementation HelloController

- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Multivalue Keychain";
	return self;
}

// This method catches the return action
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}

// Respond to "Load" button press by loading password
- (void) loadText: (id) sender
{
	NSString *password = [[PasswordKeeper sharedInstance] objectForKey:@"Password Field"];
	NSString *name = [[PasswordKeeper sharedInstance] objectForKey:@"Name Field"];
	if (password) [(UITextField *)[self.view viewWithTag:PASSFIELD_TAG] setText:password];
	if (name) [(UITextField *)[self.view viewWithTag:NAMEFIELD_TAG] setText:name];

	CFShow([[PasswordKeeper sharedInstance] passwordDict]);
}

// Respond to "Save" button press by saving password
- (void)saveText: (id) sender
{
	NSString *password = [(UITextField *)[self.view viewWithTag:PASSFIELD_TAG] text];
	NSString *name = [(UITextField *)[self.view viewWithTag:NAMEFIELD_TAG] text];
	
	if (password) [[PasswordKeeper sharedInstance] setObject:password forKey:@"Password Field"];
	if (name) [[PasswordKeeper sharedInstance] setObject:name forKey:@"Name Field"];
	
	CFShow([[PasswordKeeper sharedInstance] passwordDict]);
}

- (void)loadView
{
	UIImageView *contentView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setImage:[UIImage imageNamed:@"bluedots.png"]];
	[contentView setUserInteractionEnabled:YES];
	self.view = contentView;
	[contentView release];

	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Save" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(saveText:)] autorelease];

	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Load" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(loadText:)] autorelease];
	
	// Add the labels for name and password
	UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 80.0f, 40.0f)];
	[nameLabel setText:@"Name: "];
	[nameLabel setCenter:CGPointMake(100.0f, 55.0f)];
	[nameLabel setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:nameLabel];
	[nameLabel release];
	
	UILabel *passLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 120.0f, 40.0f)];
	[passLabel setText:@"Password: "];
	[passLabel setCenter:CGPointMake(92.0f, 95.0f)];
	[passLabel setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:passLabel];
	[passLabel release];
	
	// Create the field for the name
	UITextField *namefield = [[UITextField alloc] initWithFrame:CGRectMake(120.0f, 40.0f, 150.0f, 30.0f)];
	[namefield setBorderStyle:UITextBorderStyleRoundedRect];
	namefield.autocorrectionType = UITextAutocorrectionTypeNo;
	[namefield addTarget:self action:@selector(doneEditing:) forControlEvents:UIControlEventEditingDidEndOnExit];
	namefield.returnKeyType = UIReturnKeyDone;
	namefield.clearButtonMode = UITextFieldViewModeWhileEditing;
	namefield.delegate = self;
	namefield.tag = NAMEFIELD_TAG;
	[self.view addSubview:namefield];
	[namefield release];
	
	// Create the field for the password
	UITextField *passfield = [[UITextField alloc] initWithFrame:CGRectMake(120.0f, 80.0f, 150.0f, 30.0f)];
	[passfield setBorderStyle:UITextBorderStyleRoundedRect];
	// passfield.secureTextEntry = YES;
	passfield.autocorrectionType = UITextAutocorrectionTypeNo;
	[passfield addTarget:self action:@selector(doneEditing:) forControlEvents:UIControlEventEditingDidEndOnExit];
	passfield.returnKeyType = UIReturnKeyDone;
	passfield.clearButtonMode = UITextFieldViewModeWhileEditing;
	passfield.delegate = self;
	passfield.tag = PASSFIELD_TAG;
	[self.view addSubview:passfield];
	[passfield release];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
