#import <UIKit/UIKit.h>

@interface TreeNode : NSObject
{
	TreeNode		*parent;
	NSMutableArray	*children;
	NSString		*key;
	NSString		*leafvalue;
}
@property (nonatomic, retain) 	TreeNode		*parent;
@property (nonatomic, retain) 	NSMutableArray	*children;
@property (nonatomic, retain) 	NSString		*key;
@property (nonatomic, retain) 	NSString		*leafvalue;

- (BOOL) isLeaf;
- (TreeNode *) objectForKey: (NSString *) aKey;
- (NSString *) leafForKey: (NSString *) aKey;
- (void) dump;
@end

@interface XMLParser : NSObject
{
	NSMutableArray		*stack;
	TreeNode			*root;
}

@property (nonatomic, retain)	NSMutableArray *stack;
@property (nonatomic, retain)	TreeNode *root;
- (TreeNode *)parseXMLFile: (NSURL *) url;
@end

@implementation TreeNode
@synthesize parent;
@synthesize children;
@synthesize key;
@synthesize leafvalue;

// Initialize all nodes as branches
- (TreeNode *) init
{
	if (self = [super init]) self.leafvalue = NULL;
	return self;
}

// Determine whether the node is a leaf or a branch
- (BOOL) isLeaf
{
	return (self.leafvalue != NULL);
}

// Return the first child that matches the key
- (TreeNode *) objectForKey: (NSString *) aKey
{
	for (TreeNode *node in self.children) 
		if ([[node key] isEqualToString: aKey]) return node;
	return NULL;
}

// Return the last child leaf value that matches the key
- (NSString *) leafForKey: (NSString *) aKey
{
	for (TreeNode *node in self.children) 
		if ([[node key] isEqualToString: aKey]) return node.leafvalue;
	return NULL;
}

// Print the tree to standard out
- (void) dumpAtIndent: (int) indent
{
	for (int i = 0; i < indent; i++) printf("--");
	
	printf("[%2d] Key: %s ", indent, [self.key UTF8String]);
	if (leafvalue) printf("(%s)", [self.leafvalue UTF8String]);
	printf("\n");
	
	for (TreeNode *node in self.children) [node dumpAtIndent:indent + 1];
}

- (void) dump
{
	[self dumpAtIndent:0];
}

- (void) dealloc
{
	if (self.parent) [self.parent release];
	if (self.key) [self.key release];
	if (self.leafvalue) [self.leafvalue release];
	if (self.children) [self.children release];
	[super dealloc];
}

@end


@implementation XMLParser
@synthesize root;
@synthesize stack;

// Public parser returns the tree root
- (TreeNode *)parseXMLFile: (NSURL *) url
{
	// Create a new clean stack
	self.stack = [[[NSMutableArray alloc] init] autorelease];

	// Initialize the root
	self.root = [[[TreeNode alloc] init] autorelease];
	self.root.parent = NULL;
	self.root.leafvalue = NULL;
	self.root.children = [[[NSMutableArray alloc] init] autorelease];
	[self.stack addObject:self.root];
	
	// Parse the incoming data
    NSXMLParser *parser = [[[NSXMLParser alloc] initWithContentsOfURL:url] autorelease];
    [parser setDelegate:self];
	[parser parse];
	
	// pop down to real root
	return [self.root.children lastObject];
}

- (void) dealloc
{
	if (self.stack) [self.stack release];
	if (self.root) [self.root release];
	[super dealloc];
}

// Descend to a new element
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	TreeNode *leaf = [[[TreeNode alloc] init] autorelease];
	leaf.parent = [stack lastObject];
	[leaf.parent.children addObject:leaf];
	[self.stack addObject:leaf];
	
	leaf.key = qName ? qName : elementName;
	[qName ? qName : elementName release];
	leaf.leafvalue = NULL;
	leaf.children = [[[NSMutableArray alloc] init] autorelease];
	
}

// Pop after finishing element
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
	[self.stack removeLastObject];
}

// Reached a leaf
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if (![[self.stack lastObject] leafvalue])
	{
		[[self.stack lastObject] setLeafvalue:string];
		return;
	}
	[[self.stack lastObject] setLeafvalue:[NSString stringWithFormat:@"%@%@", [[self.stack lastObject] leafvalue], string]];
}
@end

@interface HelloController : UIViewController
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"XML Parsing";
	return self;
}

- (void) doit
{
	NSMutableString *contents = [[[NSMutableString alloc] init] autorelease];

	XMLParser *parser = [[XMLParser alloc] init];
	TreeNode *root = [parser parseXMLFile:[NSURL URLWithString:@"http://newsvote.bbc.co.uk/rss/newsonline_uk_edition/sci/tech/rss.xml"]];
	[root dump];
	
	// Subject to BBC's RSS feed format. This may change without notice.
	TreeNode *descriptionNode = [[root objectForKey:@"channel"] objectForKey:@"description"];
	[contents appendFormat:@"%@\n\n", [descriptionNode leafvalue]];
	
	for (TreeNode *item in [[root objectForKey:@"channel"] children])
	{
		if ([[item key] isEqualToString:@"item"])
			[contents appendFormat:@"* %@\n\n", [[item objectForKey:@"title"] leafvalue]];
	}
	
	[(UITextView *)self.view setText:contents];
	[parser release];
}

- (void)loadView
{
	UITextView *contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setEditable:NO];
	[contentView setFont:[UIFont fontWithName:@"Helvetica" size:14.0f]];
	self.view = contentView;
	[contentView release];

	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doit)] autorelease];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
