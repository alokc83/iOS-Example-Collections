#import "WebServer.h"

#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]
#define PICS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"../../Media/DCIM/100APPLE/"]

@interface UITextView (extended)
- (void)setContentToHTMLString:(NSString *) contentText;
@end

@interface NSDate (extended)
-(NSDate *) dateWithCalendarFormat:(NSString *)format timeZone: (NSTimeZone *) timeZone;
@end

@implementation WebShareController
static WebShareController *sharedInstance = nil;

+(WebShareController *) sharedInstance {
    if(!sharedInstance) {
		sharedInstance = [[self alloc] init];
    }
    return sharedInstance;
}

- (WebShareController *) init
{
	if (!(self = [super init])) return self;
	self.title = @"Web Server";
	serverStatus = STATUS_OFFLINE;
	return self;
}

// Return the hostname.local address for the iPhone
- (NSString *) localAddress
{
	char baseHostName[255];
	gethostname(baseHostName, 255);
	
	// The simulator has the .local suffix already so check if one is there and add one if it is not
	NSString *hn = [NSString stringWithCString:baseHostName];
	return [NSString stringWithFormat:@"http://%@%@:%d", hn, [hn hasSuffix:@".local"] ? @"" : @".local", chosenPort];
}

// Return the iPhone's IP address
- (NSString *) localIPAddress
{
	char baseHostName[255];
	gethostname(baseHostName, 255);
	
	char hn[255];
	sprintf(hn, "%s.local", baseHostName);
	struct hostent *host = gethostbyname(hn);
    if (host == NULL)
	{
        herror("resolv");
		return NULL;
	}
    else {
        struct in_addr **list = (struct in_addr **)host->h_addr_list;
        return [NSString stringWithFormat:@"<br /><i>or</i><br />http://%@:%d", [NSString stringWithCString:inet_ntoa(*list[0])], chosenPort];
    }

	return NULL;
}

// Return the full host address
- (NSString *) hostAddy
{
	return [NSString stringWithFormat:@"http://%@:%d/", [self localIPAddress], chosenPort];
}

- (NSString *) createindex
{
	// Return a custom Index.html populated with camera roll images
	NSArray *array = [[[NSFileManager defaultManager] directoryContentsAtPath:PICS_FOLDER]
					  pathsMatchingExtensions:[NSArray arrayWithObject:@"JPG"]];
	char baseHostName[255];
	gethostname(baseHostName, 255);
	NSString *hostname = [NSString stringWithCString:baseHostName];
	
	NSMutableString *outdata = [[NSMutableString alloc] init];
	[outdata appendString:@"<style>html {background-color:#eeeeee} body { background-color:#FFFFFF; font-family:Tahoma,Arial,Helvetica,sans-serif; font-size:18x; margin-left:15%; margin-right:15%; border:3px groove #006600; padding:15px; } </style>"];
	[outdata appendFormat:@"<h1>Pictures from %@</h1>", hostname];
	[outdata appendString:@"<bq>The following images are hosted live from the iPhone's DCIM folder.</bq"];
	[outdata appendString:@"<p>"];
	for (NSString *fname in array)
	{
		NSDictionary *picDict = [[NSFileManager defaultManager] fileAttributesAtPath:[PICS_FOLDER stringByAppendingPathComponent:fname] traverseLink:NO];
		NSString *modDate = [[[picDict objectForKey:NSFileModificationDate] dateWithCalendarFormat:@"%Y-%m-%d at %H:%M:%S" timeZone:nil] description];
		[outdata appendFormat:@"* <a href=\"%@\">%@</a> [%8d bytes, %@]<br />\n", fname, fname, [picDict objectForKey:NSFileSize], modDate];
	}
	[outdata appendString:@"</p>"];
	[array release];
	
	return [outdata autorelease];
}

// Expand this mime lookup method if you want to host other file types
- (NSString *) mimeForExt: (NSString *) ext
{
	NSString *uc = [ext uppercaseString];
	if ([uc isEqualToString:@"JPG"]) return @"image/jpeg";
	if ([uc isEqualToString:@"HTM"]) return @"text/html";
	if ([uc isEqualToString:@"HTML"]) return @"text/html";
	return NULL;
}

// Serve files to GET requests
- (void) handleWebRequest:(NSNumber *)fdNum
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int fd = [fdNum intValue];
	static char buffer[BUFSIZE+1];
	
	int len = read(fd, buffer, BUFSIZE); 	
	buffer[len] = '\0';
	
	NSString *request = [NSString stringWithCString:buffer];
	NSArray *reqs = [request componentsSeparatedByString:@"\n"];
	NSString *getreq = [[reqs objectAtIndex:0] substringFromIndex:4];
	NSRange range = [getreq rangeOfString:@"HTTP/"];
	if (range.location == NSNotFound)
	{
		printf("Error: GET request was improperly formed\n");
		close(fd);
		return;
	}
	
	NSString *filereq = [[getreq substringToIndex:range.location] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
	
	if ([filereq isEqualToString:@"/"]) 
	{
		NSString *outcontent = [NSString stringWithFormat:@"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n"];
		write(fd, [outcontent UTF8String], [outcontent length]);

		NSString *outdata = [self createindex];
		write(fd, [outdata UTF8String], [outdata length]);
		close(fd);
		return;
	}
	
	
	NSString *mime = [self mimeForExt:[filereq pathExtension]];
	if (!mime)
	{
		printf("Error recovering mime type.\n");
		NSString *outcontent = [NSString stringWithFormat:@"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n"];
		write (fd, [outcontent UTF8String], [outcontent length]);
		outcontent = @"<p>Sorry. This file type is not supported</p>\n";
		write (fd, [outcontent UTF8String], [outcontent length]);
		close(fd);
		return;
	}
	
	filereq = [filereq stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	NSString *fullpath = [PICS_FOLDER stringByAppendingString:filereq];
	NSData *data = [NSData dataWithContentsOfFile:fullpath];
	
	if (!data || (![[NSFileManager defaultManager] fileExistsAtPath:fullpath]))
	{
		printf("Error: file not found.\n");
		NSString *outcontent = [NSString stringWithFormat:@"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n"];
		write (fd, [outcontent UTF8String], [outcontent length]);
		outcontent = @"<p>Sorry. File not found.</p>\n";
		write (fd, [outcontent UTF8String], [outcontent length]);
		close(fd);
		return;
	}
	
	printf("%d bytes read from file\n", [data length]);
	NSString *outcontent = [NSString stringWithFormat:@"HTTP/1.0 200 OK\r\nContent-Type: %@\r\n\r\n", mime];
	write (fd, [outcontent UTF8String], [outcontent length]);
	write(fd, [data bytes], [data length]);
	close(fd);
	
	[pool release];
}

// Begin serving data -- this is a private method called by startService
- (void) startServer
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
	int socketfd;
	socklen_t length;
	static struct sockaddr_in cli_addr; 
	static struct sockaddr_in serv_addr;
	
	// Set up socket
	if((listenfd = socket(AF_INET, SOCK_STREAM,0)) <0)	
	{
		isServing = NO;
		return;
	}
	
    // Serve to a random port
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = 0;
	
	// Bind
	if(bind(listenfd, (struct sockaddr *)&serv_addr,sizeof(serv_addr)) <0)	
	{
		isServing = NO;
		return;
	}
	
	// Find out what port number was chosen.
	int namelen = sizeof(serv_addr);
	if (getsockname(listenfd, (struct sockaddr *)&serv_addr, (void *) &namelen) < 0) {
		close(listenfd);
		isServing = NO;
		return;
	}
	chosenPort = ntohs(serv_addr.sin_port);
	
	// Listen
	if(listen(listenfd, 64) < 0)	
	{
		isServing = NO;
		return;
	} 

	// Service has now succesfully started
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Stop Service" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(stopService)] autorelease];
	
	// Respond to requests until the service shuts down
	while (1 > 0) {
		length = sizeof(cli_addr);
		if((socketfd = accept(listenfd, (struct sockaddr *)&cli_addr, &length)) < 0)
		{
			isServing = NO;
			return;
		}
		[self handleWebRequest:[NSNumber numberWithInt:socketfd]];
	}
	
	[pool release];
}

- (void) serviceWasEstablished
{
	[(UITextView *)self.view setContentToHTMLString:[NSString stringWithFormat:@"<h2>Success!</h2><p>Your iPhone can now serve files over HTTP. To access this service, launch a browser from another computer on the same network and navigate to the following address(es):</p><p>%@%@</p><p>This service remains active until you tap Stop Service or until you quit from this application.</p><br /><br />",
									  [self localAddress] ? [self localAddress ]: @"", 
									  [self localIPAddress] ? [self localIPAddress] : @"" ]];
}

- (void) couldNotEstablishService
{
	[(UITextView *)self.view setContentToHTMLString:@"<h2>Service could not be established</h2><p>This application could not establish the HTTP server at this time. Please try again later.</p><br /><br />"];
}

- (void) serviceReattempt
{
	[(UITextView *)self.view setContentToHTMLString:@"<h2>Reattempting to Establish Service</h2><p>The last attempt to establish service failed. Retrying in 3 seconds.</p><br /><br />"];
}

- (void) tryingToEstablishService
{
	[(UITextView *)self.view setContentToHTMLString:@"<h2>Attempting to Establish Service</h2><p>Please wait.</p><br /><br />"];
}

- (void) stoppingService
{
	[(UITextView *)self.view setContentToHTMLString:@"<h2>You stopped service.</h2><p>The HTTP server is no longer active.</p><br /><br />"];
}

- (void) youCanStartService
{
	[(UITextView *)self.view setContentToHTMLString:@"<h2>Web Server</h2><p>Press <b>Start Service</b> to begin serving files from your iPhone to web browsers on your local network.</p><br /><br/>"];
}


// The clock ticks every three seconds to try and establish service until
// exceeding the maximum number of tries set by MAXTRIES
- (void) tick: (NSTimer *) timer
{
	if (isServing) // success!
	{
		[timer invalidate];
		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
												  initWithTitle:@"Stop Service" 
												  style:UIBarButtonItemStylePlain 
												  target:self 
												  action:@selector(stopService)] autorelease];
		[self serviceWasEstablished];
		return;
	}
	
	ntries++;
	
	if (ntries >= MAXTRIES)
	{
		[timer invalidate];
		[self couldNotEstablishService];
		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
												  initWithTitle:@"Start Service" 
												  style:UIBarButtonItemStylePlain 
												  target:self 
												  action:@selector(startService)] autorelease];
		return;		
	}
	
	[self serviceReattempt];
}

- (BOOL) isServing
{
	return isServing;
}

// Shut down service
- (void) stopService
{
	printf("Shutting down service\n");
	isServing = NO;
	close(listenfd);
	[self stoppingService];
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Start Service" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(startService)] autorelease];
}

// Start service
- (void) startService
{
	if (isServing)
	{
		printf("Error: Already Serving!\n");
		return;
	}
	
	isServing = NO;
	close(listenfd);
	[self tryingToEstablishService];
	self.navigationItem.rightBarButtonItem = NULL;
	ntries = 0;
	isServing = YES;
	[NSThread detachNewThreadSelector:@selector(startServer) toTarget:self withObject:NULL];
    [NSTimer scheduledTimerWithTimeInterval: 3.0f
									 target: self
								   selector: @selector(tick:)
								   userInfo: nil
									repeats: YES];
}

// Build the simple interaction view
- (void)loadView
{
	UITextView *textView = [[[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]] autorelease];
	[textView setEditable:NO];
	self.view = textView;
	[self youCanStartService];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Start Service" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(startService)] autorelease];
	isServing = NO;
}
@end