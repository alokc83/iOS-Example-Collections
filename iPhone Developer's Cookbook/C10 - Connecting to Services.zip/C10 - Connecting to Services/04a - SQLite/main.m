#import <UIKit/UIKit.h>
#include <sqlite3.h>
#include "FMDatabase.h"
#include "FMDatabaseAdditions.h"
#include "FMResultSet.h"

@interface NSDate (extended)
-(NSDate *) dateWithCalendarFormat:(NSString *)format timeZone: (NSTimeZone *) timeZone;
@end

@interface HelloController : UIViewController
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"SQL Demo";
	return self;
}

- (void) doit
{
	// Open the iPhone call history database
	NSString *dbpath = @"/private/var/mobile/Library/CallHistory/call_history.db";
    FMDatabase* db = [FMDatabase databaseWithPath:dbpath];
    if (![db open]) {
		printf("Could not open db.\n"); 
		return;
	}
	
    FMResultSet *rs = [db executeQuery:@"select * from call"];

    int i = 1;
	NSMutableString *outstring = [[NSMutableString alloc] init];
	
    while ([rs next]) {

		// Recover the call time
        int calltime = [rs intForColumn:@"date"];
        NSDate *cdate = [NSDate dateWithTimeIntervalSince1970:calltime];
		NSString *caldate = [[cdate dateWithCalendarFormat:@"%Y-%m-%d %H:%M:%S" timeZone:nil] description];

		// Duration in seconds
        int secs = [[rs stringForColumn:@"duration"] intValue];
		int minutes = (secs / 60) + 1;
		
		// Phone number
        NSString *phoneNumber = [rs stringForColumn:@"address"];
		
		[outstring appendFormat:@"%3d: %@ %@ - %3d minutes\n", i++, caldate, phoneNumber, minutes];

    }
	
    [db close];
	
	[(UITextView *)self.view setText:outstring];
}

- (void)loadView
{
	UITextView *contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setEditable:NO];
	[contentView setFont:[UIFont systemFontOfSize:12.0f]];
	self.view = contentView;

	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Do It" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(doit)] autorelease];
}
@end



@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
