#import <UIKit/UIKit.h>

#define SETTINGS_KEY		@"url"

@interface HelloController : UIViewController
@end

@implementation HelloController
- (id)init
{
	if (!(self = [super init])) return self;
	self.title = @"Use Safari xyz://";
	return self;
}

- (void) waitThenCheck
{
	// Recover the url string and display it
	NSString *urlstring = [[NSUserDefaults standardUserDefaults] objectForKey:SETTINGS_KEY];
	if (urlstring) [(UITextView *)self.view setText:urlstring];
}

- (void)loadView
{
	// Create a text view to echo any URLs sent
	UITextView *contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[contentView setEditable:NO];
	[contentView setFont:[UIFont systemFontOfSize:24.0f]];
	self.view = contentView;
	[contentView release];
	
	// Let the view finish loading before performing the check
	[self performSelector:@selector(waitThenCheck) withObject:NULL afterDelay:1.0f];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
	if (!url) {  return NO; }
	
    NSString *URLString = [url absoluteString];
	[[NSUserDefaults standardUserDefaults] setObject:URLString forKey:SETTINGS_KEY];
	[[NSUserDefaults standardUserDefaults] synchronize];
	return YES;
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
