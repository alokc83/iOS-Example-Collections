#import <UIKit/UIKit.h>

#define PINK [UIColor colorWithRed:0.925f green:0.0f blue:0.549f alpha:1.0f]
#define LIME [UIColor colorWithRed:0.82f green:1.0f blue:0.286f alpha:1.0f]
#define ORANGE [UIColor colorWithRed:1.0f green:0.522f blue:0.03f alpha:1.0f]

@interface LimeController: UIViewController
@end

@interface PinkController: LimeController
@end

@interface OrangeController: LimeController
@end

@implementation LimeController
- (id) init
{
	if (self = [super init]) self.title = @"Lime";
	return self;
}

- (void) loadButton
{
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
											  initWithTitle:@"Orange" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(switch:)];
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] init];
	contentView.backgroundColor = LIME;
	contentView.autoresizesSubviews = YES;
	contentView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
	self.view = contentView;
	[contentView release];
	[self loadButton];
}

- (void) switch: (id) sender
{
	[[self navigationController] pushViewController:[[OrangeController alloc] init] animated:YES];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}
@end

@implementation OrangeController
- (id) init
{
	if (self = [super init]) self.title = @"Orange";
	return self;
}

- (void) loadButton
{
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
											  initWithTitle:@"Pink" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(switch:)];
}

- (void) loadView
{
	[super loadView];
	self.view.backgroundColor = ORANGE;
}

- (void) switch: (id) sender
{
	[[self navigationController] pushViewController:[[PinkController alloc] init] animated:YES];	
}
@end

@implementation PinkController
- (id) init
{
	if (self = [super init]) self.title = @"Pink";
	return self;
}

- (void) loadButton
{
	return;
}

- (void) loadView
{
	[super loadView];
	self.view.backgroundColor = PINK;
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[LimeController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
