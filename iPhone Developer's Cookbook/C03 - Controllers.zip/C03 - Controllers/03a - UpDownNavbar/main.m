#import <UIKit/UIKit.h>
@class UITextView;

@interface HelloController : UIViewController <UITabBarDelegate>
{
	int value;
}
@end

@implementation HelloController

- (id)init
{
	if (self = [super init])
	{
		self.title = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleName"];
	}
	return self;
}

- (void) goRed
{
	self.view.backgroundColor = [UIColor colorWithRed: 1.0f green:0.45f blue:0.45f alpha:1.0f];
}

- (void) goBlue
{
	self.view.backgroundColor = [UIColor colorWithRed: 0.45f green:0.45f blue:1.0f alpha:1.0f];
}

- (void)loadView
{
	// Set up the text view to show the current value
	UITextView *contentView = [[UITextView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];

	contentView.editable = NO;
	contentView.textAlignment = UITextAlignmentCenter;
	contentView.font = [UIFont fontWithName:@"American Typewriter" size:120];

	contentView.autoresizesSubviews = YES;
	contentView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);

	self.view = contentView;
    [contentView release]; 
	
	// Initialize at 50
	[(UITextView *)self.view setText:@"\n50"];
	value = 50;

	// The app style is black
	self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
	
	NSMutableArray *buttons = [[NSMutableArray alloc] initWithCapacity:4];

	UIBarButtonItem *flexibleSpaceItem;
	flexibleSpaceItem = [[[UIBarButtonItem alloc] 
						  initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
						  target:nil action:NULL] autorelease];	
	[buttons addObject:flexibleSpaceItem];
	[flexibleSpaceItem release];
	
	UIBarButtonItem *item;
	item = [[UIBarButtonItem alloc] 
			initWithImage:[UIImage imageNamed:@"down.png"]
			style:UIBarButtonItemStylePlain 
			target:self 
			action:@selector(decrement:)];
	[buttons addObject:item];
	[item release];

	item = [[UIBarButtonItem alloc] 
			initWithImage:[UIImage imageNamed:@"up.png"]
			style:UIBarButtonItemStylePlain target:self 
			action:@selector(increment:)];
	[buttons addObject:item];
	[item release];
	
	flexibleSpaceItem = [[[UIBarButtonItem alloc] 
						  initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
						  target:nil action:NULL] autorelease];	
	[buttons addObject:flexibleSpaceItem];
	[flexibleSpaceItem release];
	
	UIToolbar *toolbar = [[UIToolbar alloc] init]; 
	toolbar.barStyle = UIBarStyleBlackOpaque;
	[toolbar setItems:buttons animated:YES];
	[toolbar sizeToFit];
	
	self.navigationItem.titleView = toolbar;
	[toolbar release];
	
	// Add a left button
	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc]
											 initWithTitle:@"Red" 
											 style:UIBarButtonItemStylePlain 
											 target:self 
											 action:@selector(goRed)] autorelease];
	
	// Add a right button
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Blue" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											  action:@selector(goBlue)] autorelease];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

-(void) increment: (id) sender
{
    [(UITextView *)self.view setText:[NSString stringWithFormat:@"\n%d", ++value]];
}

-(void) decrement: (id) sender
{
    [(UITextView *)self.view setText:[NSString stringWithFormat:@"\n%d", --value]];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
@end
@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
