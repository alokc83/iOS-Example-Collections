#import <UIKit/UIKit.h>

@interface HelloController : UIViewController
@end

@implementation HelloController

- (void) goRed
{
	self.view.backgroundColor = [UIColor colorWithRed: 1.0f green:0.45f blue:0.45f alpha:1.0f];
}

- (void) goBlue
{
	self.view.backgroundColor = [UIColor colorWithRed: 0.45f green:0.45f blue:1.0f alpha:1.0f];
}

- (id) init
{
	if (self = [super init]) self.title = @"Simple Menu";
	return self;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	contentView.backgroundColor = [UIColor whiteColor];
    [contentView release];
	
	// Add a left button
	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc]
											  initWithTitle:@"Red" 
											  style:UIBarButtonItemStylePlain 
											  target:self 
											 action:@selector(goRed)] autorelease];
	
	// Add a right button
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											 initWithTitle:@"Blue" 
											 style:UIBarButtonItemStylePlain 
											 target:self 
											 action:@selector(goBlue)] autorelease];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate>
@end

@implementation SampleAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:nav.view];
	[window makeKeyAndVisible];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
