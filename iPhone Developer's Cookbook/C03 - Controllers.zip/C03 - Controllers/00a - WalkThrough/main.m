#import <UIKit/UIKit.h>

// Custom view that converts temperatures
@interface MyView : UIView {
	IBOutlet UITextField *infield;
	IBOutlet UITextField *outfield;
}
@end

@implementation MyView
- (IBAction) convert: (id) sender
{
	float invalue = [[infield text] floatValue];
	float outvalue = (invalue - 32.0f) * 5.0f / 9.0f;
	[outfield setText:[NSString stringWithFormat:@"%3.2f", outvalue]];
}
@end

// View controller that autorotates
@interface MyViewController : UIViewController
@end

@implementation MyViewController
-(void) loadView
{
	[super loadView];
	self.view.autoresizesSubviews = YES;
	self.view.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}
@end

// Application delegate that uses NIB objects
@interface WalkThroughAppDelegate : NSObject {
	IBOutlet UIWindow *window;
	IBOutlet MyView *contentView;
}
@end
@implementation WalkThroughAppDelegate
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	
	[window addSubview:contentView];
	[window makeKeyAndVisible];
	
}

- (void)dealloc {
	[contentView release];
	[window release];
	[super dealloc];
}
@end


int main(int argc, char *argv[])
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
