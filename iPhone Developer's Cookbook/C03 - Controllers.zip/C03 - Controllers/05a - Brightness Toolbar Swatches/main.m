#import <UIKit/UIKit.h>
#import "math.h"

@interface BrightnessController : UIViewController
{
	int brightness;
}
@end

@implementation BrightnessController

// MyCreateBitmapContext: Source based on Apple Sample Code
CGContextRef MyCreateBitmapContext (int pixelsWide,
									int pixelsHigh)
{
    CGContextRef    context = NULL;
    CGColorSpaceRef colorSpace;
    void *          bitmapData;
    int             bitmapByteCount;
    int             bitmapBytesPerRow;
	
    bitmapBytesPerRow   = (pixelsWide * 4);
    bitmapByteCount     = (bitmapBytesPerRow * pixelsHigh);
	
    colorSpace = CGColorSpaceCreateDeviceRGB();
    bitmapData = malloc( bitmapByteCount );
    if (bitmapData == NULL)
    {
        fprintf (stderr, "Memory not allocated!");
		CGColorSpaceRelease( colorSpace );
        return NULL;
    }
    context = CGBitmapContextCreate (bitmapData,
									 pixelsWide,
									 pixelsHigh,
									 8,
									 bitmapBytesPerRow,
									 colorSpace,
									 kCGImageAlphaPremultipliedLast);
    if (context== NULL)
    {
        free (bitmapData);
        fprintf (stderr, "Context not created!");
        return NULL;
    }
    CGColorSpaceRelease( colorSpace );
	
    return context;
}

// addRoundedRectToPath: Source based on Apple Sample Code
static void addRoundedRectToPath(CGContextRef context, CGRect rect, float ovalWidth,
								 float ovalHeight)
{
	float fw, fh;
	if (ovalWidth == 0 || ovalHeight == 0) {
		CGContextAddRect(context, rect);
		return;
	}
	
	CGContextSaveGState(context);
	CGContextTranslateCTM(context, CGRectGetMinX(rect), CGRectGetMinY(rect));
	CGContextScaleCTM(context, ovalWidth, ovalHeight);
	fw = CGRectGetWidth(rect) / ovalWidth;
	fh = CGRectGetHeight(rect) / ovalHeight;
	
	CGContextMoveToPoint(context, fw, fh/2);  // Start at lower right corner
	CGContextAddArcToPoint(context, fw, fh, fw/2, fh, 1);  // Top right corner
	CGContextAddArcToPoint(context, 0, fh, 0, fh/2, 1); // Top left corner
	CGContextAddArcToPoint(context, 0, 0, fw/2, 0, 1); // Lower left corner
	CGContextAddArcToPoint(context, fw, 0, fw, fh/2, 1); // Back to lower right
	
	CGContextClosePath(context);
	CGContextRestoreGState(context);
}

// Build an image tinted at the given percentage
id createImage(float percentage)
{
	CGContextRef context  = MyCreateBitmapContext(30, 30);
	addRoundedRectToPath(context, CGRectMake(0.0f, 0.0f, 30.0f, 30.0f), 4.0f, 4.0f);
	CGFloat gray[4] = {percentage, percentage, percentage, 1.0f};
	CGContextSetFillColor(context, gray);
	CGContextFillPath(context);
	CGImageRef myRef = CGBitmapContextCreateImage (context);
	free(CGBitmapContextGetData(context));
	CGContextRelease(context);
	return [UIImage imageWithCGImage:myRef];
}


#define MAXDEPTH 8

-(BrightnessController *) initWithBrightness: (int) aBrightness
{
	self = [super init];
	brightness = aBrightness;
	self.title = [NSString stringWithFormat:@"%d%%", brightness * 10];
	[self.tabBarItem initWithTitle:self.title image:createImage(((float) brightness / 10.0f)) tag:0];
	return self;
}

- (void)loadView
{
	UIView *contentView = [[UIView alloc] init];
	float percent = brightness * 0.1;
	contentView.backgroundColor = [UIColor colorWithRed:percent green:percent blue:percent alpha:1.0];
	contentView.autoresizesSubviews = YES;
	contentView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
	self.view = contentView;
    [contentView release];
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate, UITabBarControllerDelegate>
@end

@implementation SampleAppDelegate

- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

	// Create the array of UIViewControllers
	NSMutableArray *controllers = [[NSMutableArray alloc] init];

	for (int i = 0; i < 11; i++) {
		BrightnessController *bControl = [[BrightnessController alloc] initWithBrightness:i];
		UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:bControl];
		nav.navigationBar.barStyle = UIBarStyleBlackTranslucent;
		[controllers addObject:nav];
		[bControl release];
		[nav release];
	}
	
	// Create the toolbar and add the view controllers
	UITabBarController *tbarController = [[UITabBarController alloc] init];
	tbarController.viewControllers = controllers;
	tbarController.customizableViewControllers = controllers;
	tbarController.delegate = self;
	
	// Set up the window
	[window addSubview:tbarController.view];
	[window makeKeyAndVisible];
	
	[controllers release];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
