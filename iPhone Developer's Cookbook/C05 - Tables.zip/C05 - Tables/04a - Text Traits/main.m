#import <UIKit/UIKit.h>

@interface HelloController : UITableViewController 
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Cell Styles";
	return self;
}

#pragma mark UITableViewDataSource Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
	}

	// Set up the cell
	cell.text = [NSString stringWithFormat:@"Cell Number #%d", [indexPath row] + 1];
	cell.font = [UIFont fontWithName:[[NSArray arrayWithObjects:@"Georgia", @"Helvetica", @"Courier", nil]
									  objectAtIndex:[indexPath row]] size:16];
	cell.textColor = [[NSArray arrayWithObjects:
					   [UIColor redColor],
					   [UIColor lightGrayColor],
					   [UIColor blueColor], nil] objectAtIndex: [indexPath row]];
	
	return cell;
}

#pragma mark UITableViewDelegateMethods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath 
{
	printf("User selected row %d\n", [newIndexPath row] + 1);
}
@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
