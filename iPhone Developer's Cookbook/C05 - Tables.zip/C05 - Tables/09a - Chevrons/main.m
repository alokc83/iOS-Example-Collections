#import <UIKit/UIKit.h>

#define NCELLS 4

@interface ImageController : UIViewController
@end
@implementation ImageController
- (void) loadView {
	// Load an application image and set it as the primary view
	UIImageView *contentView = [[[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]] autorelease];
	[contentView setImage:[UIImage imageNamed:@"Default.png"]];
	self.view = contentView;
	[contentView release]; 
}
@end


@interface HelloController : UITableViewController 
{
	NSMutableArray *tableTitles;
	int ithTitle;
}
@end

@implementation HelloController

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Table Edits";
	return self;
}

#pragma mark Data Source methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [tableTitles count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (!cell) cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];

	cell.text = [tableTitles objectAtIndex:[indexPath row]];
	cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
	cell.hidesAccessoryWhenEditing = YES;

	return cell;
}

#pragma mark Delegate Methods

// Add a new item
- (void) add
{
	[tableTitles addObject:[NSString stringWithFormat:@"Table Cell #%d", ++ithTitle]];	
	[self.tableView reloadData];
}

/*
 * Accessory Button Handler: This simply opens an image controller with the Hello World image.
 */

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
	[[self navigationController] pushViewController:[[ImageController alloc] init]  animated:YES];
}

- (void) deselect
{	
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

// Respond to a user tap
- (void)tableView:(UITableView *)tableView selectionDidChangeToIndexPath:(NSIndexPath *)newIndexPath fromIndexPath:(NSIndexPath *)oldIndexPath 
{
	printf("User selected row %d\n", [newIndexPath row] + 1);
	[self performSelector:@selector(deselect) withObject:nil afterDelay:0.5f];
}

// Respond to deletion
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle 
forRowAtIndexPath:(NSIndexPath *)indexPath 
{
	printf("About to delete item %d\n", [indexPath row]);
	[tableTitles removeObjectAtIndex:[indexPath row]];
	[self.tableView reloadData];
}	 

- (void)loadView
{
	[super loadView];

	self.navigationItem.rightBarButtonItem = self.editButtonItem;
	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc]
											 initWithTitle:@"Add" 
											 style:UIBarButtonItemStylePlain 
											 target:self 
											 action:@selector(add)] autorelease];
	
	// Initialize the titles
	tableTitles = [[NSMutableArray alloc] init];
	ithTitle = NCELLS;
	for (int i = 1; i <= NCELLS; i++) 
		[tableTitles addObject:[[NSString stringWithFormat:@"Table Cell #%d", i] retain]];
}

-(void) dealloc
{
	[tableTitles release];
	[super dealloc];
}
@end



@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}

