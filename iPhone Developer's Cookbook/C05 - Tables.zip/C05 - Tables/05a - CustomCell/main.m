#import <UIKit/UIKit.h>

@interface HelloController : UITableViewController 
@end

#define URLSTRING_TAG		999
@implementation HelloController

- (HelloController *) init
{
	if (self = [super init]) self.title = @"Complex Cells";
	return self;
}

#pragma mark UITableViewDataSource Methods

// Only one section in this table
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

// Return how many rows in the table
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return 3;
}

- (void) modCell:(UITableViewCell *)aCell withTitle:(NSString *)title
						  url: (NSString *) url note: (NSString *) comment
{
	// Title
	CGRect tRect1 = CGRectMake(0.0f, 5.0f, 320.0f, 40.0f);
	UILabel *title1 = [[UILabel alloc] initWithFrame:tRect1];
	[title1 setText:title];
	[title1 setTextAlignment:UITextAlignmentCenter];
	[title1 setFont: [UIFont fontWithName:@"American Typewriter" size:36.0f]];
	[title1 setBackgroundColor:[UIColor clearColor]];
	
	// URL
	CGRect tRect2 = CGRectMake(0.0f, 45.0f, 320.0f, 20.0f);
	UILabel *title2 = [[UILabel alloc] initWithFrame:tRect2];
	title2.tag = URLSTRING_TAG;
	[title2 setText:url];
	[title2 setTextAlignment:UITextAlignmentCenter];
	[title2 setFont: [UIFont fontWithName:@"Helvetica" size:18.0f]];
	[title2 setBackgroundColor:[UIColor clearColor]];	
	
	// Comment
	CGRect tRect3 = CGRectMake(0.0f, 70.0f, 320.0f, 20.0f);
	UILabel *title3 = [[UILabel alloc] initWithFrame:tRect3];
	[title3 setText:comment];
	[title3 setTextAlignment:UITextAlignmentCenter];
	[title3 setFont: [UIFont fontWithName:@"Helvetica" size:18.0f]];
	[title3 setBackgroundColor:[UIColor clearColor]];
	
	// Add to cell
	[aCell addSubview:title1];
	[aCell addSubview:title2];
	[aCell addSubview:title3];
	
	[title1 release];
	[title2 release];
	[title3 release];
}

// Return a cell for the ith row
- (UITableViewCell *)tableView:(UITableView *)tView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
	
	// Set up the cell
	int row = [indexPath row];
	switch (row)
	{
		case 0:
			[self modCell:cell withTitle:@"Addison Wesley" 
					  url: @"http://www.pearsonhighered.com"
					 note: @"Publisher"];
			break;
		case 1:
			[self modCell:cell withTitle:@"Apple" 
					  url: @"http://apple.com/"
					 note: @"Apple"];
			break;
			
		case 2:
			[self modCell:cell withTitle:@"Erica Sadun" 
					  url: @"http://ericasadun.com"
					 note: @"Software Updates"];
			break;
	}
	return cell;
}

#pragma mark UITableViewDelegateMethods

// Respond to user selection
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	printf("User selected row %d\n", [newIndexPath row] + 1);
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:[(UILabel *)[[tableView cellForRowAtIndexPath:newIndexPath] viewWithTag:URLSTRING_TAG] text]]];
}


- (void)loadView
{
	[super loadView];
	self.tableView.rowHeight = 100.0f;
}

@end

@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
