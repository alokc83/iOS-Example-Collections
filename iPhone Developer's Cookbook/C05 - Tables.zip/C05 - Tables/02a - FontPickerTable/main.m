#import <UIKit/UIKit.h>

UIColor *sysBlueColor(float percent) {
	float red = percent * 255.0f;
	float green = (red + 20.0f) / 255.0f;
	float blue = (red + 45.0f) / 255.0f;
	if (green > 1.0) green = 1.0f;
	if (blue > 1.0f) blue = 1.0f;
	
	return [UIColor colorWithRed:percent green:green blue:blue alpha:1.0f];
}

#define TABLE_VIEW_TAG			999

// Font Picker Sheet Class allows users to pick a font from a scrolling table in a "drop down" menu
@interface FontPickerSheet : UIView <UITableViewDataSource, UITableViewDelegate>
{
	NSString *selection;
}
@property (nonatomic, retain)	NSString *selection;
@end

@implementation FontPickerSheet
@synthesize selection;

/*
 *   Table Data Source
 */

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section 
{
	return [[UIFont	familyNames] count];
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:@"any-cell"];
	if (!cell)	cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"any-cell"] autorelease];
	cell.text = [[UIFont familyNames] objectAtIndex:[indexPath row]];
	return cell;
}

/*
 *   Table Delegate
 */

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)newIndexPath
{
	selection = [[[UIFont familyNames] objectAtIndex:[newIndexPath row]] retain];
}

/*
 *   Window initialization
 */

- (FontPickerSheet *) initWithFrame: (CGRect) rect
{
	rect.origin.y = 0.0f - rect.size.height; // Place above status bar
	self = [super initWithFrame:rect];
	[self setAlpha:0.9];
	[self setBackgroundColor:sysBlueColor(0.4f)];
	
	// Add button
	UIButton *button = [[UIButton buttonWithType:UIButtonTypeRoundedRect] initWithFrame:CGRectMake(220.0f, 200.0f, 80.0f, 32.0f)];
	[button setTitle:@"Okay" forState: UIControlStateHighlighted];
	[button setTitle:@"Okay" forState: UIControlStateNormal];	
	[button setFont:[UIFont boldSystemFontOfSize:14.0f]];
	[button addTarget:self action:@selector(removeView) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:button];
	
	// Add title
	UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 8.0f, 320.0f, 32.0f)];
	title.text = @"Please Select a Font";
	title.textAlignment = UITextAlignmentCenter;
	title.textColor = [UIColor whiteColor];
	title.backgroundColor = [UIColor clearColor];
	title.font = [UIFont boldSystemFontOfSize:20.0f];
	[self addSubview:title];
	[title release];
	
	// Add border for the table
	CGRect bounds = CGRectMake(20.0f, 40.0f, 280.0f, 200.0f - 48.0f);
	UIView *borderView = [[UIView alloc] initWithFrame:bounds];
	[borderView setBackgroundColor:sysBlueColor(0.55f)];
	[self addSubview:borderView];
	[borderView release];
	
	// Add table
	UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectInset(bounds, 4.0f, 4.0f) style:UITableViewStylePlain];
	tableView.backgroundColor = [UIColor whiteColor];
	tableView.delegate = self;
	tableView.dataSource = self;
	tableView.tag = TABLE_VIEW_TAG;
	[tableView reloadData];
	[self addSubview:tableView];
	[tableView release];
	
	return self;
}

/*
 *   Window presentation utilities
 */

- (void) removeView
{
	UITableView *tableView = (UITableView *)[self viewWithTag:TABLE_VIEW_TAG];
	[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:NO];

	// Scroll away the overlay
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:0.5];
	
	CGRect rect = [self frame];
	rect.origin.y = 0.0f - rect.size.height;
	[self setFrame:rect];
	
	// Complete the animation
	[UIView commitAnimations];
}

- (void) presentView
{
	selection = NULL;
	
	// Scroll in the overlay
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:0.5];
	
	CGRect rect = [self frame];
	rect.origin.y = 0.0f;
	[self setFrame:rect];
	
	// Complete the animation
	[UIView commitAnimations];
}

- (void) dealloc
{
	if (self.selection) [self.selection release];
	[super dealloc];
}
@end


@interface HelloController : UIViewController
{
	FontPickerSheet *alertView;
}
@end

@implementation HelloController 
- (id) init
{
	if (self = [super init]) self.title = @"Hello World";
	return self;
}

- (void) presentSheet
{
	if (alertView) [alertView presentView];
}

- (void) doNotify
{
	NSString *message, *fontSelected = [alertView selection];

	if (fontSelected) 
		message = [NSString stringWithFormat:@"User selected the %@ font family.", fontSelected];
	else
		message = @"User did not select a font.";

	UIAlertView *alert = [[UIAlertView alloc] 
						  initWithTitle:@"Selected Font"
						  message: message
						  delegate: self
						  cancelButtonTitle:nil
						  otherButtonTitles:@"OK", nil];
	[alert show];
}


- (void)loadView
{
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	contentView.backgroundColor = [UIColor whiteColor];
	self.view = contentView;
    [contentView release]; 
	
	// Add right button
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											 initWithTitle:@"Do It" 
											 style:UIBarButtonItemStylePlain 
											 target:self 
											 action:@selector(presentSheet)] autorelease];
	
	// Add left button
	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc]
											 initWithTitle:@"Check" 
											 style:UIBarButtonItemStylePlain 
											 target:self 
											 action:@selector(doNotify)] autorelease];
	// Create the alert view
	alertView = [[[FontPickerSheet alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 240.0f)] retain];
	[alertView setCenter:CGPointMake(160.0f, -240.0f)];
	[self.view addSubview:alertView];
	[alertView release];
}

-(void) dealloc
{
	[alertView release];
	[super dealloc];
}
@end


@interface SampleAppDelegate : NSObject <UIApplicationDelegate> 
{
	UINavigationController *nav;
}
@property (nonatomic, retain)		UINavigationController *nav;
@end

@implementation SampleAppDelegate
@synthesize nav;
- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self.nav = [[UINavigationController alloc] initWithRootViewController:[[HelloController alloc] init]];
	[window addSubview:self.nav.view];
	[window makeKeyAndVisible];
}

- (void) dealloc
{
	[self.nav release];
	[super dealloc];
}
@end

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"SampleAppDelegate");
	[pool release];
	return retVal;
}
