//
//  ALTAppDelegate.h
//  AutoLayoutTestbed
//
//  Created by Jim Dovey on 12-07-08.
//  Copyright (c) 2012 Apress Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ALTAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
