//
//  APCustomView.h
//  Drawing
//
//  Created by Jim Dovey on 2012-07-14.
//  Copyright (c) 2012 Apress Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface APCustomView : NSView
@property (nonatomic, assign, getter=isLinear) BOOL linear;
@end
