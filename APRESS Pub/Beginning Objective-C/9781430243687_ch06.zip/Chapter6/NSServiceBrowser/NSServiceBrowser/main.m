//
//  main.m
//  NSServiceBrowser
//
//  Created by Jim Dovey on 12-06-14.
//  Copyright (c) 2012 Apress. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
