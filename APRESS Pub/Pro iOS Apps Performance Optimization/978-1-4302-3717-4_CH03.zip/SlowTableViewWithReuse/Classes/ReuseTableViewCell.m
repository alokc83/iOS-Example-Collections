//
//  TableCellViewController.m
//  UITableViewPerformance
//
//  Created by Vo Khang on 20/03/11.
//  Copyright 2011 KDLab. All rights reserved.
//

#import "ReuseTableViewCell.h"


@implementation ReuseTableViewCell
@synthesize avatar;
@synthesize imageNew;
@synthesize userName;



@end