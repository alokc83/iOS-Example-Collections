//
//  RootViewController.h
//  LeaksViewController
//
//  Created by Vo Khang on 10/04/11.
//  Copyright 2011 KDLab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
}

@end
