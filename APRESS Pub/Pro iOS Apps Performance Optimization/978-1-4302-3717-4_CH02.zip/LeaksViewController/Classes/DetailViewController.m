//
//  DetailViewController.m
//  LeaksViewController
//
//  Created by Vo Khang on 10/04/11.
//  Copyright 2011 KDLab. All rights reserved.
//

#import "DetailViewController.h"


@implementation DetailViewController

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.hidesBackButton = NO;
}


- (void)dealloc {
    [super dealloc];
}


@end
