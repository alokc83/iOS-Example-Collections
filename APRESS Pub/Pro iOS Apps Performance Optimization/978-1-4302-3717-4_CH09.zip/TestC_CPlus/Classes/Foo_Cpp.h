
 
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

class Foo_Cpp
{
public:

  ~Foo_Cpp();
   int compute() 
    {
        return 3.0;
	}
};
