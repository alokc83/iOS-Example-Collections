//
//  TestC_CPlusViewController.h
//  TestC_CPlus
//
//  Created by vodkhang on 11/07/11.
//  Copyright 2011 KDLab. All rights reserved.
//

#import <UIKit/UIKit.h>
//#include "Foo_Cpp.h"

@interface TestC_CPlusViewController : UIViewController {
//    Foo_Cpp	*foo_cpp;

}
@property (nonatomic, strong) IBOutlet UILabel *resultLabel;
@end

