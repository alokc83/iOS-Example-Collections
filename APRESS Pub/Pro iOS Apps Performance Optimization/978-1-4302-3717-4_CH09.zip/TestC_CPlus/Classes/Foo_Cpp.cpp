#include "Foo_Cpp.h"

int compute()
{
	return 3;
}

Foo_Cpp::~Foo_Cpp()
{
}
