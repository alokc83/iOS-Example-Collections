//
//  ImageCacheCell.m
//  ImageCachingLibrary
//
//  Created by Vo Khang on 24/04/11.
//  Copyright 2011 KDLab. All rights reserved.
//

#import "ImageCell.h"


@implementation ImageCell
@synthesize contentLabel;
@synthesize contentImage;


@end