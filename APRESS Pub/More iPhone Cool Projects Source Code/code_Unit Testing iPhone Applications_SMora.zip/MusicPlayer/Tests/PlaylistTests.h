//
//  PlaylistTests.h
//  MusicPlayer
//
//  Created by Saul Mora on 4/22/10.
//  Copyright 2010 Magical Panda Software, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GHUnit.h"

@interface PlaylistTests : GHTestCase {

}

@end
