#import "_Song.h"

@interface Song : _Song {}
// Custom logic goes here.
@end
