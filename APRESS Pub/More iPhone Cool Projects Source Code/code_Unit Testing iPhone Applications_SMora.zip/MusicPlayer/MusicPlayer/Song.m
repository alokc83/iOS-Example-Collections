#import "Song.h"

@implementation Song

// Custom logic goes here.

@end
