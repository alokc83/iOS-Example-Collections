#import "_Playlist.h"

@interface Playlist : _Playlist {}

- (NSTimeInterval) duration;

@end
