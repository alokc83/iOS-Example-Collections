//
//  MusicPlayerViewController.h
//  MusicPlayer
//
//  Created by Saul Mora on 4/22/10.
//  Copyright Magical Panda Software, LLC 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicPlayerViewController : UIViewController {

}

@end

