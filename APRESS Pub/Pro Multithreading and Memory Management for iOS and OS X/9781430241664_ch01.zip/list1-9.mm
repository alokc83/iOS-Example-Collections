- (id) autorelease
{
	[NSAutoreleasePool addObject:self];
}