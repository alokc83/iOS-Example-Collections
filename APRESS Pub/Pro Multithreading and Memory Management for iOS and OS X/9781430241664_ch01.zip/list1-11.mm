- (void) addObject: (id)anObj
{
	[array addObject:anObj];
}