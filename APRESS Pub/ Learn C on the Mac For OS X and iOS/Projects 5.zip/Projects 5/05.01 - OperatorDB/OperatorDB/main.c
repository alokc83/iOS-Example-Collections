//
//  main.c
//  OperatorDB
//
//  Created by James Bucanek and Dave Mark on 6/23/12.
//  Copyright (c) 2012 Apress. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{
    int myInt;
    
    myInt = 3 * 2;
    
    myInt += 1;
    
    myInt -= 5;
    
    myInt *= 10;
    
    myInt /= 4;
    
    myInt /= 2;
    
    return 0;
}
