//
//  main.c
//  Hello
//
//  Created by James Bucanek and Dave Mark on 5/30/12.
//  Copyright (c) 2012 Apress. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    // insert code here...
    printf("Hello, World!\n");
    return 0;
}

