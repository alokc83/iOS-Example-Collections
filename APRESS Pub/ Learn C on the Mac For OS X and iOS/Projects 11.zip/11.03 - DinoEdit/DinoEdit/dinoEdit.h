//
//  dinoEdit.h
//  DinoEdit
//
//  Created by James Bucanek on 8/13/12.
//  Copyright (c) 2012 Apress, Inc. All rights reserved.
//

#ifndef DinoEdit_dinoEdit_h
#define DinoEdit_dinoEdit_h

/***********/
/* Defines */
/***********/
#define kDinoRecordSize		20
#define kMaxLineLength		100
#define kDinoFileName		"My Dinos.data"

#endif
