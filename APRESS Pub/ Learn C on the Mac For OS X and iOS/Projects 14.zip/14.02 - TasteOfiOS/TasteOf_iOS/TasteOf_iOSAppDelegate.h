//
//  TasteOf_iOSAppDelegate.h
//  TasteOf_iOS
//
//  Created by Dave Mark on 7/4/11.
//  Copyright 2011 Dave Mark. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TasteOf_iOSAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
