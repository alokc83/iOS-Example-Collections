//
//  TasteOfCocoaAppDelegate.m
//  TasteOfCocoa
//
//  Created by Dave Mark on 7/4/11.
//  Copyright 2011 Dave Mark. All rights reserved.
//

#import "TasteOfCocoaAppDelegate.h"

@implementation TasteOfCocoaAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
