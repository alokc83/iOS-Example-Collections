//
//  DVDFile.h
//  DVDFiler2
//
//  Created by James Bucanek and David Mark on 8/12/12.
//  Copyright (c) 2012 Apress, Inc. All rights reserved.
//

#ifndef DVDFiler_DVDFile_h
#define DVDFiler_DVDFile_h

/* Public Functions */
extern void WriteFile( void );
extern void ReadFile( void );

#endif
