//
//  main.c
//  SignedUnsigned
//
//  Created by James Bucanek and David Mark on 7/19/12.
//  Copyright (c) 2012 Apress. All rights reserved.
//

#include <stdio.h>
#include <stdint.h>

int main(int argc, const char * argv[])
{
	uint16_t t;
	unsigned int neverNegNum;
	neverNegNum = -2;
	
	int anyNum;
	anyNum = neverNegNum;
	
    return 0;
}

