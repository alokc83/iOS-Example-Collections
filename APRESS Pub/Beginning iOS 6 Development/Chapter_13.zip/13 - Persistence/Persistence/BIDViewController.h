//
//  BIDViewController.h
//  Persistence
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@property (strong, nonatomic) IBOutletCollection(UITextField) NSArray *lineFields;

@end
