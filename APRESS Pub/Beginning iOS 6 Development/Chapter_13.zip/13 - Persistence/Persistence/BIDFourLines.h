//
//  BIDFourLines.h
//  Persistence
//

#import <Foundation/Foundation.h>

@interface BIDFourLines : NSObject <NSCoding, NSCopying>

@property (copy, nonatomic) NSArray *lines;

@end
