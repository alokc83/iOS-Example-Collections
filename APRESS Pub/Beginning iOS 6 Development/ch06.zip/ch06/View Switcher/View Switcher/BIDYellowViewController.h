//
//  BIDYellowViewController.h
//  View Switcher
//

#import <UIKit/UIKit.h>

@interface BIDYellowViewController : UIViewController
- (IBAction)yellowButtonPressed;
@end
