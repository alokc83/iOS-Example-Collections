//
//  BIDBlueViewController.h
//  View Switcher
//

#import <UIKit/UIKit.h>

@interface BIDBlueViewController : UIViewController
- (IBAction)blueButtonPressed;
@end
