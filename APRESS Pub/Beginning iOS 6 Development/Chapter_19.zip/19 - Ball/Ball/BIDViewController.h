//
//  BIDViewController.h
//  Ball
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@end
