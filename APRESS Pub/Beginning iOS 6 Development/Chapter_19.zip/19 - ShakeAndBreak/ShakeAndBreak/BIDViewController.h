//
//  BIDViewController.h
//  ShakeAndBreak
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
