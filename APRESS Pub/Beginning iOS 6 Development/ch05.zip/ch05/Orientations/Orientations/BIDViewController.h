//
//  BIDViewController.h
//  Orientations
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@end
