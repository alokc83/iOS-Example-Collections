//
//  BIDViewController.h
//  Autosize
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@end
