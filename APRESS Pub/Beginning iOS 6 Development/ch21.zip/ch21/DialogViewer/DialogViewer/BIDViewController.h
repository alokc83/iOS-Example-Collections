//
//  BIDViewController.h
//  DialogViewer
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UICollectionViewController

@end
