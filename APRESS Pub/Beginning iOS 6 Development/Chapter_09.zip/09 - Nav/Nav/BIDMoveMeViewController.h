//
//  BIDMoveMeViewController.h
//  Nav
//

#import "BIDSecondLevelViewController.h"

@interface BIDMoveMeViewController : BIDSecondLevelViewController

@property (strong, nonatomic) NSMutableArray *words;

@end
