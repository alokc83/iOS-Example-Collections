//
//  BIDFirstLevelControllerViewController.h
//  Nav
//

#import <UIKit/UIKit.h>

@interface BIDFirstLevelViewController : UITableViewController

@property (copy, nonatomic) NSArray *controllers;

@end
