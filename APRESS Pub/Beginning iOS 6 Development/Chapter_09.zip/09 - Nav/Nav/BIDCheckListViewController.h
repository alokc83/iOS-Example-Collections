//
//  BIDCheckListViewController.h
//  Nav
//

#import "BIDSecondLevelViewController.h"

@interface BIDCheckListViewController : BIDSecondLevelViewController

@property (copy, nonatomic) NSArray *snacks;
@property (assign, nonatomic) NSUInteger selectedSnack;

@end
