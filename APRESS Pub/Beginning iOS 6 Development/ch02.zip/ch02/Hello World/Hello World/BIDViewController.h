//
//  BIDViewController.h
//  Hello World
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@end
