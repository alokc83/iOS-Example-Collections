//
//  BIDTaskListController.h
//  Simple Storyboard
//

#import <UIKit/UIKit.h>

@interface BIDTaskListController : UITableViewController

@end
