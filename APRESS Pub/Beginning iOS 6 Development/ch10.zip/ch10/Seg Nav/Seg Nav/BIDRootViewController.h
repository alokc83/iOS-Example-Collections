//
//  BIDRootViewController.h
//  Seg Nav
//

#import <UIKit/UIKit.h>

@interface BIDRootViewController : UITableViewController

@end
