//
//  BIDStaticCellsController.h
//  Simple Storyboard
//

#import <UIKit/UIKit.h>

@interface BIDStaticCellsController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@end
