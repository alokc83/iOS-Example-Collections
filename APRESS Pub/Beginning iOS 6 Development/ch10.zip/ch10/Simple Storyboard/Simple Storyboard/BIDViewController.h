//
//  BIDViewController.h
//  Simple Storyboard
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@end
