//
//  BIDPlace
//  WhereAmI
//

#import "BIDPlace.h"

@implementation BIDPlace

@end
