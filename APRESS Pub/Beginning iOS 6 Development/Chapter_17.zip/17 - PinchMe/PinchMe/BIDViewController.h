//
//  BIDViewController.h
//  PinchMe
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController <UIGestureRecognizerDelegate>

@property (strong, nonatomic) UIImageView *imageView;

@end
