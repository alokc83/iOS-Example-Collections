//
//  BIDViewController.h
//  CheckPlease
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *label;

@end
