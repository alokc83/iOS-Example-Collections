//
//  BIDCheckMarkRecognizer.h
//  CheckPlease
//

#import <UIKit/UIKit.h>

@interface BIDCheckMarkRecognizer : UIGestureRecognizer

@end
