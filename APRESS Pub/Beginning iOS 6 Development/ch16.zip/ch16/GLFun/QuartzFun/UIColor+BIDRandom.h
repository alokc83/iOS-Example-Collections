//
//  UIColor+BIDRandom.h
//  QuartzFun
//

#import <UIKit/UIKit.h>

@interface UIColor (BIDRandom)
+ (UIColor *)randomColor;
@end
