//
//  main.m
//  PerformanceTuning
//
//  Created by Michael Privat on 8/1/11.
//  Copyright 2011 Majorspot, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PerformanceTuningAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([PerformanceTuningAppDelegate class]));
  }
}
