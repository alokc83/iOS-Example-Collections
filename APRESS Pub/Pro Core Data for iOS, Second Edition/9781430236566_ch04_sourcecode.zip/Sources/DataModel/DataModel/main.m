//
//  main.m
//  DataModel
//
//  Created by Rob Warner on 7/31/11.
//  Copyright 2011 Grailbox. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DataModelAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([DataModelAppDelegate class]));
  }
}
