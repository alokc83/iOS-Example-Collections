//
//  DataModelAppDelegate.h
//  DataModel
//
//  Created by Rob Warner on 7/31/11.
//  Copyright 2011 Grailbox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DataModelAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
