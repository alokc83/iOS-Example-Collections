//
//  main.m
//  DemoApp
//
//  Created by Michael Privat on 7/30/11.
//  Copyright 2011 Majorspot, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DemoAppAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([DemoAppAppDelegate class]));
  }
}
