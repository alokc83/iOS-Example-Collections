//
//  UIColorTransformer.h
//  Shapes
//
//  Created by Michael Privat on 7/31/11.
//  Copyright 2011 Majorspot, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIColorTransformer : NSValueTransformer

@end
