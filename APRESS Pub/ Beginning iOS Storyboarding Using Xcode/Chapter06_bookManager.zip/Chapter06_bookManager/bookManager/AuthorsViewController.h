//
//  AuthorsViewController.h
//  bookManager
//
//  Created by Yulia McCarthy on 4/28/12.
//  Copyright (c) 2012 InspireSmart Solutions, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AuthorsViewController : UIViewController

@end
