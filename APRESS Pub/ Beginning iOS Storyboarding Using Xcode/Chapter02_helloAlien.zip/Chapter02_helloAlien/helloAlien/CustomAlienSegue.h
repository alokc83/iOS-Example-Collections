//
//  CustomAlienSegue.h
//  helloAlien
//
//  Created by Rory Lewis on 12/26/11.
//  Copyright (c) 2011 University of Colorado at Colorado Springs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomAlienSegue : UIStoryboardSegue

@end
