//
//  BookAppDelegate.m
//  Chapter2
//
//  Created by Peter Clark on 4/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BookAppDelegate.h"

@implementation BookAppDelegate

@synthesize window = _window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
