//
//  Chapter2Tests.m
//  Chapter2Tests
//
//  Created by Peter Clark on 4/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Chapter2Tests.h"

@implementation Chapter2Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Chapter2Tests");
}

@end
