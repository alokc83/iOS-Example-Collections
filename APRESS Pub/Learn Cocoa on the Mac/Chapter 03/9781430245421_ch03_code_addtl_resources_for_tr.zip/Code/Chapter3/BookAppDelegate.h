//
//  BookAppDelegate.h
//  Chapter3
//
//  Created by Peter Clark on 5/1/12.
//  Copyright (c) 2012 Learn Cocoa. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface BookAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
