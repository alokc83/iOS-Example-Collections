//
//  BookAppDelegate.m
//  Chapter3
//
//  Created by Peter Clark on 5/1/12.
//  Copyright (c) 2012 Learn Cocoa. All rights reserved.
//

#import "BookAppDelegate.h"

@implementation BookAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
