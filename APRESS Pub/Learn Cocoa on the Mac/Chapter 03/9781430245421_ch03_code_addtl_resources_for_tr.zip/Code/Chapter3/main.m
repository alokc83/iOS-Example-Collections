//
//  main.m
//  Chapter3
//
//  Created by Peter Clark on 5/1/12.
//  Copyright (c) 2012 Learn Cocoa. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
