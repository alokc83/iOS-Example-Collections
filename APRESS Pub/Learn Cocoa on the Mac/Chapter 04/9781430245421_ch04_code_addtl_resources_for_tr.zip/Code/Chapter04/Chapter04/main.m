//
//  main.m
//  Chapter04
//
//  Created by Peter Clark on 5/31/12.
//  Copyright (c) 2012 Learn Cocoa. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
