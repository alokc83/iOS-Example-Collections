//
//  Example02Controller_iPhone.h
//  Sample 05
//
//  Created by Lucas Jordan on 5/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Example02Controller.h"

@interface Example02Controller_iPhone : Example02Controller {
    
}

@end
