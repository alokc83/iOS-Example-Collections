//
//  Example01Controller_iPhone.h
//  Sample 05
//
//  Created by Lucas Jordan on 4/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Example01Controller.h"

@interface Example01Controller_iPhone : Example01Controller {
    
}

@end
