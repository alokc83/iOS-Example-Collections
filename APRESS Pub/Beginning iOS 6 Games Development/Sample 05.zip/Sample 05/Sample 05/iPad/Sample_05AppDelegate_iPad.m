//
//  Sample_05AppDelegate_iPad.m
//  Sample 05
//
//  Created by Lucas Jordan on 4/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Sample_05AppDelegate_iPad.h"

@implementation Sample_05AppDelegate_iPad


@end
