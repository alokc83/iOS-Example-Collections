//
//  AppDelegate.h
//  Sample 11
//
//  Created by Lucas Jordan on 8/29/12.
//  Copyright (c) 2012 Lucas Jordan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;

@end
