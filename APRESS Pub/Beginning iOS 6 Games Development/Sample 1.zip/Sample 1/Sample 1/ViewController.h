//
//  ViewController.h
//  Sample 1
//
//  Created by Lucas Jordan on 9/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
